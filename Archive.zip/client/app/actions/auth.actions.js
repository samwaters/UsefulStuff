import {ajaxCall} from './ajax.actions';
import {push} from 'react-router-redux';

export const ACTIONS = {
	SET_STEP: 'SET_STEP',
	STORE_TOKEN: 'STORE_TOKEN',
	VERIFY: 'VERIFY',
	VERIFY_COMPLETE: 'VERIFY_COMPLETE',
	VERIFY_FAILED: 'VERIFY_FAILED',
	LOGOUT: 'LOGOUT',
	LOGOUT_COMPLETE: 'LOGOUT_COMPLETE'
};

const storeToken = token => {
	return {
		type: ACTIONS.STORE_TOKEN,
		payload: token
	}
};

const verify = () => {
	return ajaxCall(
		'/api/auth/verify',
		'POST',
		{},
		verifyComplete()
	);
};

const verifyComplete = () => {
	return (dispatch, res) => {
		if(res.ok) {
			dispatch({
				type: ACTIONS.VERIFY_COMPLETE,
				payload: {
					name: res.name,
					policy: res.policy,
					step: res.step,
					token: res.token,
				}
			});
			dispatch(push('/home'));
		} else {
			dispatch({
				type: ACTIONS.VERIFY_FAILED,
				payload: {
					error: res.error
				}
			});
			dispatch(push('/landing'));
		}
	}
};

const logout = token => {
	return ajaxCall(
		'/api/auth/logout',
		'POST',
		{token: token},
		logoutComplete()
	);
};

const logoutComplete = () => {
	return (dispatch, res) => {
		if(res.ok) {
			dispatch({
				type: ACTIONS.LOGOUT_COMPLETE,
				payload: {
					message: res.message
				}
			});
			dispatch(push('/landing'));
		}
	}
};

export {logout, storeToken, verify};
