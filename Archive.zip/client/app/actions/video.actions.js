import {ajaxCall} from './ajax.actions';
import {push} from 'react-router-redux';

export const ACTIONS = {
    CREATE_VIDEO: 'CREATE_VIDEO',
    CREATE_COMPLETE: 'CREATE_COMPLETE',
    GET_VIDEO_STATUS: 'GET_VIDEO_STATUS',
    STORE_VIDEO_STATUS: 'STORE_VIDEO_STATUS',
	SUBMIT_VIDEO: 'SUBMIT_VIDEO',
	SUBMIT_VIDEO_COMPLETE: 'SUBMIT_VIDEO_COMPLETE'
};

const createVideo = (name, description) => {
    return ajaxCall(
        '/api/video/create',
        'POST',
        {name: name, description: description},
        createComplete()
    );
};

const createComplete = () => {
    return (dispatch, res) => {
        if(res.ok) {
            dispatch({
                type: 'SET_STEP',
                payload: 1
            });
        } else {
			dispatch({
				type: ACTIONS.VERIFY_FAILED,
				payload: {
					error: res.error
				}
			});
			dispatch(push('/landing'));
        }
    }
};

const getVideoStatus = () => {
    return ajaxCall(
        '/api/video/status',
        'GET',
        '',
        storeVideoStatus()
    )
};

const storeVideoStatus = () => {
    return (dispatch, res) => {
        if(res.ok) {
            dispatch({
                type: ACTIONS.STORE_VIDEO_STATUS,
                payload: {
                    created: res.created,
                    processed: res.processed,
                    uploaded: res.uploaded
                }
            });
        } else {
			dispatch({
				type: 'VERIFY_FAILED',
				payload: {
					error: res.error
				}
			});
			dispatch(push('/landing'));
        }
    }
};

const submitVideo = () => {
	return ajaxCall(
		'/api/video/submit',
		'POST',
		{},
		submitVideoComplete()
	);
};

const submitVideoComplete = () => {
	return (dispatch, res) => {
		if(res.ok) {
			dispatch({type: ACTIONS.SUBMIT_VIDEO_COMPLETE});
			dispatch({
				type: 'SET_STEP',
				payload: 3
			});
		} else {
			dispatch({
				type: 'VERIFY_FAILED',
				payload: {
					error: res.error
				}
			});
			dispatch(push('/landing'));
		}
	}
};

export {createVideo, getVideoStatus, submitVideo};
