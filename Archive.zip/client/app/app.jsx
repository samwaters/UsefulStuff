// React
import React from 'react';
import {connect} from 'react-redux';
import * as authActions from './actions/auth.actions';
import {AppBar, Layout, Panel, Navigation} from 'react-toolbox';

class App extends React.Component {
    constructor() {
        super();
        this.state = {
            sidebarActive: false
        }
    }

    render() {
        const {main} = this.props;
        return (
            <Layout>
                <Panel>
                    <AppBar leftIcon="menu" title="Video Upload">
                        <Navigation type="horizontal">
                            {
                                this.props.loggedIn &&
                                <span>{this.props.name} | {this.props.policy}</span>
                            }
                        </Navigation>
                    </AppBar>
                    <div style={{display:'flex', flexDirection:'column', flex:1}}>
                        {main}
                    </div>
                </Panel>
            </Layout>
        );
    }
}

const AppComponent = connect(
    state => {
        return {
            loggedIn: state.authReducer.loggedIn,
            name: state.authReducer.name,
            policy: state.authReducer.policy,
            token: state.authReducer.token
        }
    },
    dispatch => {
        return {
            logOut: (token) => {
                dispatch(authActions.logout(token))
            }
        }
    }
)(App);

export default AppComponent;
