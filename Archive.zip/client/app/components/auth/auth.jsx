import React from 'react';
import {connect} from 'react-redux';
import * as authActions from '../../actions/auth.actions';
import {FlexContainer, FlexItem} from '../common/flex';

class Auth extends React.Component {
    constructor() {
        super();
        this.state = {};
    }

    componentDidMount() {
        this.props.storeToken(this.props.params.token);
        this.props.verify();
    }

    render() {
        return <FlexContainer direction="row">
            <FlexItem width="15%"/>
            <FlexItem width="70%">
                <p>Verifying your account, please wait</p>
            </FlexItem>
            <FlexItem width="15%"/>
        </FlexContainer>
    }
}

const mapStateToProps = () => {
    return {}
};

const mapDispatchToProps = dispatch => {
    return {
        storeToken: token => dispatch(authActions.storeToken(token)),
        verify: () => dispatch(authActions.verify())
    }
};

const AuthComponent = connect(mapStateToProps, mapDispatchToProps)(Auth);

export default AuthComponent;
