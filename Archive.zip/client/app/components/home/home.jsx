import React from 'react';
import {connect} from 'react-redux';
import {FlexContainer, FlexItem} from '../common/flex';
import Step1Component from '../steps/step1';
import Step2Component from '../steps/step2';
import Step3Component from '../steps/step3';
import Step4Component from '../steps/step4';
import * as styles from './home.styles';

class Home extends React.Component {

	constructor() {
		super();
		this.state = {}
	}

	render() {
		return <FlexContainer className={styles.homeContainer} direction="row">
			<FlexItem width="15%"/>
			<FlexItem width="70%">
				{
					this.props.step === 0 && <Step1Component />
				}
				{
					this.props.step === 1 && <Step2Component />
				}
				{
					this.props.step === 2 && <Step3Component />
				}
				{
					this.props.step === 3 && <Step4Component />
				}
			</FlexItem>
			<FlexItem width="15%"/>
		</FlexContainer>
	}
}

const HomeComponent = connect(
	state => {
		return {
			step: state.authReducer.step
		}
	},
	() => {
		return {}
	}
)(Home);

export default HomeComponent;
