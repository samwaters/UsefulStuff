import React from 'react';
import {connect} from 'react-redux';
import {FlexContainer, FlexItem} from './common/flex';
import {Error, Information} from './common/messages';

const Landing = (props) => {
    return (
        <FlexContainer direction="row">
            <FlexItem width="15%" />
            <FlexItem width="70%">
                {
                    props.error && <Error>{props.error}</Error>
                }
                {
                    props.message && <Information>{props.message}</Information>
                }
                <h3>Video Upload Service</h3>
                <p>This is the video upload service</p>
            </FlexItem>
            <FlexItem width="15%" />
        </FlexContainer>
    );
};

const LandingComponent = connect(
    state => {
        return {
            error: state.authReducer.errorMessage,
            message: state.authReducer.message
        }
    },
    () => {
        return {}
    }
)(Landing);
export default LandingComponent;
