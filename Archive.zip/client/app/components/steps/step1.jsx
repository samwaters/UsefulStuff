import React from 'react';
import {connect} from 'react-redux';
import * as videoActions from '../../actions/video.actions';
import {Button, Input} from 'react-toolbox';

class Step1 extends React.Component {
	constructor() {
		super();
		this.state = {
			name: '',
			description: ''
		};
	}

	handleChange(el, val) {
		this.setState({[el]: val})
	}

	render() {
		return <div>
			<h3>Step 1: Video Information</h3>
			<p>Please give us some information about the video</p>
			<Input label="Video Name" name="name" onChange={e => this.handleChange('name', e)} value={this.state.name} />
			<Input label="Video Description" onChange={e => this.handleChange('description', e)} value={this.state.description} />
			<p style={{textAlign:'center'}}>
				<Button
					disabled={this.state.name.length === 0 || this.state.description.length === 0}
					onClick={() => this.props.createVideo(this.state.name, this.state.description)}
					primary
					raised
				>Proceed</Button>
			</p>
		</div>
	}
}

const Step1Component = connect(
	() => {
		return {}
	},
	dispatch => {
		return {
			createVideo: (name, description) => dispatch(videoActions.createVideo(name, description))
		}
	}
)(Step1);

export default Step1Component;
