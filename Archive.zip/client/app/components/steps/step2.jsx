import React from 'react';
import {connect} from 'react-redux';
import {ProgressBar} from 'react-toolbox';
import DropTarget from '../uploader/droptarget';
import {Error} from '../common/messages';

class Step2 extends React.Component {
	constructor() {
		super();
		this.state = {
			lastError: '',
			uploading: false,
			uploadDone: 0,
			uploadPercent: 0,
			uploadTotal: 0
		};
	}

	dropError(err) {
		this.setState({lastError: err, uploading: false});
	}

	filesDropped(files) {
		this.setState({lastError: '', uploading: true});
		this.upload(files[0]);
	}

	render() {
		return <div>
			<h3>Step 2: Upload Video</h3>
			{
				this.state.lastError !== '' && <Error>{this.state.lastError}</Error>
			}
			{
				!this.state.uploading && <DropTarget
					allowedFileTypes={['avi', 'mkv', 'mov', 'mpg', 'mpeg', 'mp4', 'webm']}
					onDropError={err => this.dropError(err)}
					onFileDropped={files => this.filesDropped(files)}
					maxFileCount={1}
					maxFileSize={25 * 1024 * 1024}
					text="Drop your video here to upload it"
				/>
			}
			{
				this.state.uploading && <div>
					<ProgressBar mode="determinate" value={this.state.uploadPercent} />
					<p style={{textAlign:'center'}}>Uploading, please wait ({this.state.uploadDone} of {this.state.uploadTotal} bytes)</p>
				</div>
			}
		</div>
	}

	upload(file) {
		this.setState({uploadTotal: file.size});
		let xhr = new XMLHttpRequest();
		xhr.open('POST', '/api/upload', true);
		xhr.setRequestHeader('X-File-Name', file.name);
		xhr.setRequestHeader('token', this.props.token);
		xhr.addEventListener('progress', e => {
			if(e.lengthComputable) {
				this.setState({
					uploadDone: e.loaded,
					uploadPercent: Math.floor((e.loaded / e.total) * 100),
					uploadTotal: e.total
				});
			} else {
				this.setState({
					uploadDone: 'Unknown',
					uploadPercent: 50,
					uploadTotal: 'Unknown'
				});
			}
		});
		xhr.addEventListener('load', e => {
			let response = JSON.parse(e.currentTarget.responseText);
			if(!response || !response.ok) {
				this.setState({
					lastError: response ? response.error : 'No response from server',
					uploading:false
				})
			} else {
				this.props.uploadComplete();
			}
		});
		xhr.addEventListener('error', e => {this.setState({lastError: e.message})});
		xhr.send(file);
	}
}

const Step2Component = connect(
	state => {
		return {
			token: state.authReducer.token
		}
	},
	dispatch => {
		return {
			uploadComplete: () => {
				dispatch({type: 'SET_STEP', payload: 2});
				dispatch({
					type: 'STORE_VIDEO_STATUS',
					payload: {
						created: true,
						processed: false,
						uploaded: true
					}
				});
			}
		}
	}
)(Step2);
export default Step2Component;
