import React from 'react';
import {connect} from 'react-redux';
import {Information} from '../common/messages';
import * as videoActions from '../../actions/video.actions';
import {Button, Card, CardActions, CardText, CardTitle, Checkbox} from 'react-toolbox';

class Step3 extends React.Component {
	constructor() {
		super();
		this.state = {
			cropEnd: 0,
			cropStart: 0,
			cropVideo: false,
			currentVideoTime: 0,
			intervalId: 0,
			removeAudio: false,
			videoDuration: 0,
			videoLoaded: false
		}
	}

	componentDidMount() {
		let intervalId = setInterval(() => {
			if(this.props.videoProcessed) {
				clearInterval(this.state.intervalId);
			} else {
				this.props.getVideoStatus();
			}
		}, 10000);
		this.setState({intervalId: intervalId});
		this.props.getVideoStatus();
	}

	cropTime(which, e) {
		e.preventDefault();
		if(which === 'start') {
			this.setState({cropStart: this.state.currentVideoTime})
		} else {
			this.setState({cropEnd: this.state.currentVideoTime});
		}
	}

	render() {
		return <div>
			<h3>Step 3: Edit Your Video</h3>
			{
				!this.props.videoProcessed && <Information>Your video is currently being processed and will be available shortly</Information>
			}
			{
				this.props.videoProcessed && <div>
					<Card style={{marginBottom:'10px'}}>
						<CardTitle>Video Preview</CardTitle>
						<CardText>
							<div style={{textAlign:'center'}}>
								<video controls muted style={{height:'480px', width:'640px'}} onLoadedData={e => this.videoLoaded(e)} onSeeked={e => this.setState({currentVideoTime: e.currentTarget.currentTime})}>
									<source
										src={`/api/video/watch?token=${this.props.token}`}
										type="video/mp4"
									/>
									Your browser does not support the &lt;video&gt; tag
								</video>
							</div>
						</CardText>
					</Card>
					<Card style={{marginBottom:'10px'}}>
						<CardTitle title="Editing Options" />
						<CardText>
							<Checkbox checked={this.state.cropVideo} label="Crop Video" name="cropVideo" onChange={() => this.setState({cropVideo: !this.state.cropVideo})} />
							{
								this.state.cropVideo && <div>
									<p>To set the start and end crop times, seek to the required time in the video and click "Set to current video time"</p>
									<p>Start: {this.state.cropStart} <a href="#" onClick={e => this.cropTime('start', e)}>Set to current video time</a></p>
									<p>End: {this.state.cropEnd} <a href="#" onClick={e => this.cropTime('end', e)}>Set to current video time</a></p>
								</div>
							}
							<Checkbox checked={this.state.removeAudio} label="Remove Audio" name="removeAudio" onChange={() => this.setState({removeAudio: !this.state.removeAudio})} />
						</CardText>
						<CardActions>
							<Button raised accent>Process Changes</Button>
						</CardActions>
					</Card>
					<Card style={{marginBottom:'10px'}}>
						<CardTitle title="Submit" />
						<CardText>
							<p>If you're done making changes, or don't need to make any, click Submit Video below to send your video to us</p>
							<p>Please be sure, though, as you can't un-submit it</p>
						</CardText>
						<CardActions>
							<Button raised primary>Submit Video</Button>
						</CardActions>
					</Card>
				</div>
			}
		</div>
	}

	videoLoaded(e) {
		this.setState({
			cropEnd: e.currentTarget.duration,
			videoDuration: e.currentTarget.duration,
			videoLoaded: true
		});
	}
}

const Step3Component = connect(
	state => {
		return {
			token: state.authReducer.token,
			videoProcessed: state.videoReducer.processed
		}
	},
	dispatch => {
		return {
			getVideoStatus: () => dispatch(videoActions.getVideoStatus()),
			submitVideo: () => dispatch(videoActions.submitVideo())
		}
	}
)(Step3);

export default Step3Component;
