import React from 'react';
import {connect} from 'react-redux';

class Step4 extends React.Component {
	constructor() {
		super();
		this.state = {};
	}

	render() {
		return <div>
			<h3>Step 4: Completed</h3>
			<p>Thank you, {this.props.name}, we have received your video related to your policy with reference number {this.props.policy}</p>
			<p>You may now close this window.</p>
		</div>
	}
}

const Step4Component = connect(
	state => {
		return {
			name: state.authReducer.name,
			policy: state.authReducer.policy
		}
	},
	() => {
		return {}
	}
)(Step4);

export default Step4Component;
