import * as actions from '../actions/auth.actions';

const initialState = {
    errorMessage: '',
    loggedIn: false,
    message: '',
	name: '',
    policy: '',
    step: 0,
    token: ''
};

const authReducer = (state = initialState, action) => {
    let mutatedState = Object.assign({}, state);
    switch(action.type) {
        case actions.ACTIONS.SET_STEP:
            mutatedState.step = action.payload;
            return mutatedState;
        case actions.ACTIONS.STORE_TOKEN:
            mutatedState.token = action.payload;
            return mutatedState;
        case actions.ACTIONS.VERIFY_COMPLETE:
            mutatedState.loggedIn = true;
            mutatedState.name = action.payload.name;
            mutatedState.policy = action.payload.policy;
            mutatedState.step = action.payload.step;
            return mutatedState;
        case actions.ACTIONS.VERIFY_FAILED:
            mutatedState.errorMessage = action.payload.error;
            mutatedState.loggedIn = false;
            mutatedState.name = '';
            mutatedState.policy = '';
			mutatedState.step = 0;
            mutatedState.token = '';
            return mutatedState;
        case actions.ACTIONS.LOGOUT_COMPLETE:
            mutatedState.loggedIn = false;
			mutatedState.message = action.payload.message;
			mutatedState.name = '';
			mutatedState.policy = '';
			mutatedState.step = 0;
			mutatedState.token = '';
            return mutatedState;
        default:
            return state;
    }
};

export default authReducer;
