import {combineReducers} from 'redux';
import authReducer from './auth';
import videoReducer from './video';
import {routerReducer} from 'react-router-redux';

const appReducers = combineReducers({authReducer:authReducer, routing:routerReducer, videoReducer:videoReducer});
export default appReducers;