import * as video from '../actions/video.actions';

const initialState = {
    created: false,
    processed: false,
    uploaded: false
};

const videoReducer = (state = initialState, action) => {
    switch(action.type) {
        case video.ACTIONS.STORE_VIDEO_STATUS:
            return Object.assign({}, state, action.payload);
        default:
            return state;
    }
};

export default videoReducer;
