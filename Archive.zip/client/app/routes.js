import React from 'react';
import {IndexRedirect, Route} from 'react-router';
import App from './app';
import HomeComponent from './components/home/home';
import AuthComponent from './components/auth/auth';
import LandingComponent from './components/landing';
import * as s from './selectors/auth';

export const getRoutes = store => {
    const requireAuth = (nextState, replace) => {
        const state = store.getState();
        if(!s.selectIsLoggedIn(state)) {
            replace({
                pathname: '/landing',
                state: {}
            });
        }
    };
    const requireNoAuth = (nextState, replace) => {
        const state = store.getState();
        if(s.selectIsLoggedIn(state)) {
            replace({
                pathname: '/home',
                state: {}
            });
        }
    };

    return <Route path="/" component={App}>
        <IndexRedirect to="/home" />
        <Route path="/home" components={{main: HomeComponent}} onEnter={(n, r) => requireAuth(n, r)} />
        <Route path="/auth/:token" components={{main: AuthComponent}} onEnter={(n, r) => requireNoAuth(n, r)} />
        <Route path="*" components={{main: LandingComponent}} />
    </Route>
};
