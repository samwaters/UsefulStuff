const selectIsLoggedIn = state => state.authReducer.loggedIn;
export {selectIsLoggedIn};