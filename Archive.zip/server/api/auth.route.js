const server = require('../server');
const validator = require('validator');

server.post('/api/auth/verify', (req, res) => {
	if(!req.headers.token) {
		res.status(400);
		res.send(JSON.stringify({ok: false, error: 'Incomplete payload'}));
		res.end();
		return;
	}
	server.db.verifyUser(req.headers.token).then(
		user => {
			res.send(JSON.stringify({
				name: user.name,
				ok: true,
				policy: user.policy,
				step: user.step
			}));
			res.end();
		},
		err => {
			res.status(401);
			res.send(JSON.stringify({ok: false, error: err}));
			res.end();
		}
	)
});

server.get('/api/auth/currentstep', (req, res) => {
	if(!req.headers.token) {
		res.status(400);
		res.send(JSON.stringify({ok: false, error: 'Incomplete payload'}));
		res.end();
		return;
	}
	server.db.verifyUser(req.headers.token).then(
		user => {
			res.send(JSON.stringify({
				step: user.step
			}));
			res.end();
		},
		err => {
			res.status(401);
			res.send(JSON.stringify({ok: false, error: err}));
			res.end();
		}
	)
});

server.post('/api/auth/logout', (req, res) => {
	res.send(JSON.stringify({ok: true}));
});
