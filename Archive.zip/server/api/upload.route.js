const fs = require('fs');
const path = require('path');
const server = require('../server');
const config = require('../server.config');

server.post('/api/upload', function(req, res) {
	if(!req.headers.token) {
		res.status(403);
		res.send(JSON.stringify({ok: false, error: 'Not Authorised'}));
		return;
	}
	server.db.verifyUser(req.headers.token).then(
		data => {
			server.db.videoStatus(req.headers.token).then(
				video => {
					if(video.created && !video.uploaded) {
						fs.writeFile(path.join(config.upload, req.headers.token), req.body, "binary", function(e) {
							if(e) {
								res.status(500);
								res.send(JSON.stringify({ok: false, error:e}));
								res.end();
							} else {
								server.db.setVideoUploaded(req.headers.token).then(
									() => {
										res.send(JSON.stringify({ok: true, size: req.body.length}));
										res.end();
									},
									err => {
										res.status(500);
										res.send(JSON.stringify({ok: false, error:err}));
										res.end();
									}
								);
							}
						});
					} else {
						res.status(400);
						res.send(JSON.stringify({ok: false, error: 'Video cannot be uploaded'}));
						res.end();
					}
				},
				err => {
					res.status(400);
					res.send(JSON.stringify({ok: false, error: err}));
					res.end();
				}
			);
		},
		err => {
			res.status(401);
			res.send(JSON.stringify({ok: false, error: 'Not Authorised'}));
			res.end();
		}
	)
});
