const b64 = require('base-64');
const fs = require('fs');
const path = require('path');
const send = require('send');
const server = require('../server');
const config = require('../server.config');

server.post('/api/video/create', (req, res) => {
    if(!req.headers.token || !req.body.name || !req.body.description) {
		res.status(401);
		res.send(JSON.stringify({ok:false, error:'Incomplete Payload'}));
		res.end();
		return;
    }
    server.db.verifyUser(req.headers.token).then(
        user => {
            server.db.createVideo(req.headers.token, req.body.name, req.body.description).then(
                () => {
					res.send(JSON.stringify({ok: true}));
					res.end();
                },
                err => {
                    res.status(500);
                    res.send(JSON.stringify({ok: false, error: err}));
                    res.end();
                }
            );
        },
        err => {
			res.status(403);
			res.send(JSON.stringify({ok:false, error:'Not Authorised'}));
			res.end();
        }
    );
});

server.get('/api/video/status', (req, res) => {
    if(!req.headers.token) {
        res.status(403);
        res.send(JSON.stringify({ok:false, error:'Not Authorised'}));
        res.end();
        return;
    }
    server.db.verifyUser(req.headers.token).then(
        user => {
            server.db.videoStatus(req.headers.token).then(
                status => {
                    res.send(JSON.stringify(Object.assign({}, status, {ok: true})));
                    res.end();
                },
                err => {
					res.status(404);
					res.send(JSON.stringify({ok:false, error:'Video Not Found'}));
					res.end();
                }
            )
        },
        err => {
			res.status(401);
			res.send(JSON.stringify({ok:false, error:'Not Authorised'}));
			res.end();
        }
    );
});

server.post('/api/video/submit', (req, res) => {
	server.db.verifyUser(req.headers.token).then(
		user => {
			server.db.videoStatus(req.headers.token).then(
				status => {
					if(status.uploaded) {
						server.db.submitVideo().then(
							() => {
								res.send(JSON.stringify({ok: true}));
								res.end();
							},
							err => {
								res.status(404);
								res.send(JSON.stringify({ok:false, error:'Video Not Found'}));
								res.end();
							}
						)
					} else {
						res.status(400);
						res.send(JSON.stringify({ok: false, error: 'Video Not Uploaded'}));
						res.end();
					}
					res.send(JSON.stringify(Object.assign({}, status, {ok: true})));
					res.end();
				},
				err => {
					res.status(404);
					res.send(JSON.stringify({ok:false, error:'Video Not Found'}));
					res.end();
				}
			)
		},
		err => {
			res.status(401);
			res.send(JSON.stringify({ok:false, error:'Not Authorised'}));
			res.end();
		}
	);
});

server.get('/api/video/watch', (req, res) => {
    if(!req.query.token) {
        res.status(403);
        res.send(JSON.stringify({ok:false, error:'Not Authorised'}));
        res.end();
        return;
    }
    server.db.verifyUser(req.query.token).then(
        user => {
            server.db.videoStatus(req.query.token).then(
                status => {
                    if(status.uploaded && status.processed) {
						let videoPath = path.join(config.processed, req.query.token);
						if(fs.existsSync(videoPath)) {
							res.header('Content-type', 'video/mp4');
							if(req.header('Range')) {
								sendVideoRange(videoPath, parseRangeHeader(req.header('Range')), res);
							} else {
								res.send(fs.readFileSync(videoPath));
							}
						} else {
							res.status(404);
							res.send(JSON.stringify({error: 'Video Not Found', ok: false}));
						}
                    } else {
						res.status(400);
						res.send(JSON.stringify({ok:false, error:'Video Not Ready'}));
                    }
					res.end();
                },
                err => {
					res.status(404);
					res.send(JSON.stringify({ok:false, error:'Video Not Found'}));
					res.end();
                }
            )
        },
        err => {
			res.status(401);
			res.send(JSON.stringify({ok:false, error:'Not Authorised'}));
			res.end();
        }
    );
});

function parseRangeHeader(header) {
    let headerData = header.split('=');
    if(headerData[0] === 'bytes') {
        if(!headerData[1]) {
            return null;
        }
        let byteRange = headerData[1].split('-');
        return {
            start: parseInt(byteRange[0]),
            end: byteRange[1] ? parseInt(byteRange[1]) : Infinity
        }
    } else {
        return null; // No idea what to do with this one
    }
}

function sendVideoRange(videoPath, range, res) {
    if(!range) {
        res.status(416);
    } else {
        try {
            // Check the length
            let completeVideo = fs.readFileSync(videoPath);
            if(range.start > completeVideo.length || (range.end < Infinity && range.end > completeVideo.length)) {
                res.status(416); // Unsatisfiable range
                return;
            }
            res.status(206); // Partial content
            res.header('Accept-Ranges', 'bytes');
            if(range.end === Infinity) {
                res.header('Content-Length', completeVideo.length - range.start);
                res.header('Content-Range', 'bytes ' + range.start + '-' + (completeVideo.length-1) + '/' + completeVideo.length);
                let buf = new Buffer(completeVideo.length - range.start);
                completeVideo.copy(buf, 0, range.start, completeVideo.length);
                res.send(buf);
            } else {
                res.header('Content-Length', range.end - range.start);
                res.header('Content-Range', 'bytes ' + range.start + '-' + range.end + '/' + completeVideo.length);
                let buf = new Buffer(range.end - range.start + 1);
                completeVideo.copy(buf, 0, range.start, range.end + 1);
                res.send(buf);
            }
        } catch(e) {
            console.log('File read error', e);
            res.status(416);
        }
    }
}
