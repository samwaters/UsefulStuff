const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const sql = require('sqlite3');
const dbPath = path.join(__dirname, 'db.sql');
const salt = 'agVideo';

class Db {
	constructor() {
		let _this = this;
		this._db = new sql.Database(dbPath);
		this._db.get('SELECT name FROM sqlite_master WHERE type="table" AND name="users"', (err, row) => {
			if(!row) {
				_this.initialiseDb();
			}
		});
	}

	initialiseDb() {
		console.log('Initialising DB');
		this._db.run('CREATE TABLE users(id integer primary key, token string(64) unique not null, name string(255) not null, policy string(32) not null, expires datetime not null, used boolean not null');
		this._db.run('CREATE TABLE videos(id integer primary key, owner integer references users(id) unique, name string(50), description text, uploaded integer(1) default 0, options string(255), processed integer(1) default 0, lockedBy string(32))');
	}

	createVideo(token, name, description) {
		let _this = this;
		return new Promise((resolve, reject) => {
			_this.getUserId(token).then(
				userId => {
					_this._db.run(
						'INSERT INTO videos VALUES(null, ?, ?, ?, ?, 0, 0, null)',
						userId,
						name,
						description,
						JSON.stringify({
							initial: true
						}),
						err => {
							if(err) {
								reject('Could not create video')
							} else {
								_this._db.run('UPDATE users SET step=1 WHERE id=?', userId);
								resolve();
							}
						}
					);
				},
				err => {
					reject(err);
				}
			);
		});
	}

	getUserId(token) {
		let _this = this;
		return new Promise((resolve, reject) => {
			_this._db.get('SELECT id FROM users WHERE token=?', token, (err, row) => {
				if(err || !row) {
					reject('User not found');
				} else {
					resolve(row.id);
				}
			});
		})
	}

	setVideoUploaded(token) {
		let _this = this;
		return new Promise((resolve, reject) => {
			_this.getUserId(token).then(
				userId => {
					_this._db.run('UPDATE videos SET uploaded=1 WHERE owner=?', userId, err => {
						if(err) {
							reject('Video not found');
						} else {
							_this._db.run('UPDATE users SET step=2 WHERE id=?', userId);
							resolve();
						}
					});
				},
				err => {
					reject('User not found');
				}
			);
		});
	}

	submitVideo(token) {
		let _this = this;
		return new Promise((resolve, reject) => {
			_this.getUserId(token).then(
				id => {
					_this._db.run('UPDATE users SET step=3 WHERE id=?', id, err => {
						if(err) {
							reject('Could not submit video');
						} else {
							resolve();
						}
					})
				},
				err => {
					reject('User not found');
				}
			)
		})
	}

	verifyUser(token) {
		let _this = this;
		return new Promise((resolve, reject) => {
			_this._db.get('SELECT name,policy,expires,step FROM users WHERE token=? AND step<4', token, (err, row) => {
				if(err || !row) {
					console.log(err, row);
					reject('User not found');
				} else {
					resolve({name: row.name, policy: row.policy, step: row.step, token: token});
				}
			});
		});
	}

	videoStatus(token) {
		let _this = this;
		return new Promise((resolve, reject) => {
			_this.getUserId(token).then(
				id => {
					_this._db.get('SELECT uploaded, processed FROM videos WHERE owner=?', id, (err, row) => {
						if(err) {
							reject(err);
							return;
						}
						if(!row) {
							resolve({created: false, processed: false, uploaded: false});
						} else {
							resolve({created: true, processed: !!row.processed, uploaded: !!row.uploaded});
						}
					});
				},
				err => {
					reject('User not found');
				}
			);
		});
	}
}

module.exports = Db;
