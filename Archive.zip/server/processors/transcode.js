const child = require('child_process');
const config = require('../server.config');
const fs = require('fs');
const path = require('path');
const sql = require('sqlite-sync');
const sleep = require('thread-sleep');

/*
 * Transcode processor
 * Requires ffmpeg and h264/aac codecs (usually shipped with ffmpeg)
 * ffmpeg path must be set in server config
 * Will process the queue table and convert all uploaded videos to mp4 (h264/aac)
 * To run:
 * node transcode.js --name <process name>
 * If --name is ommitted, the current timestamp will be used
 */

let nameArg = process.argv.indexOf('--name');
let processName;
if(nameArg >= 0 && process.argv.length > nameArg) {
	processName = process.argv[nameArg + 1];
} else {
	processName = "proc-" + new Date().getTime();
}
console.log('---Transcode Processor---');
console.log('Process name:', processName);
console.log('ffmpeg binary is located at', config.ffmpeg);
while(true) {
	sql.connect(path.join(__dirname, '..', 'db.sql'));
	console.log('[', new Date(), '] Trying to find a job locked by this process');
	let lockedJob = sql.run('SELECT videos.id as id, users.token as token FROM videos INNER JOIN users ON videos.owner = users.id WHERE uploaded=1 AND processed=0 AND lockedBy=? LIMIT 1', [processName]);
	if(lockedJob.length > 0) {
		// Start processing
		console.log('[', new Date(), '] Processing video id', lockedJob[0].id, lockedJob[0].token);
		let result = child.spawnSync(config.ffmpeg, [
			'-i', path.join(config.upload, lockedJob[0].token),
			'-vcodec', 'h264',
			'-acodec', 'aac',
			'-strict',
			'-2',
			'-f', 'mp4', // ffmpeg requires this for files with no extension
			'-y', // Overwrite
			path.join(config.processed, lockedJob[0].token)
		]);
		if(result.error) {
			// Error here indicates an error with the spawn
			console.warn('[', new Date(), '] Error processing video', lockedJob[0].id, 'Error code', result.error.code, 'Command', result.error.syscall);
			// -1 to indicate failure
			sql.run('UPDATE videos SET processed=-1 WHERE id=?', [lockedJob[0].id]);
		} else {
			if(result.status !== 0) {
				// Non-zero exit indicates an error from ffmpeg
				console.warn('[', new Date(), '] Error processing video', lockedJob[0].id, lockedJob[0].token);
				console.warn(result.stderr.toString('utf8'));
				// -1 to indicate failure
				sql.run('UPDATE queue SET processed=-1 WHERE id=?', [lockedJob[0].id]);
			} else {
				// Success
				console.log('[', new Date(), '] Successfully processed video', lockedJob[0].id, lockedJob[0].token);
				sql.run('UPDATE videos SET processed=1 WHERE id=?', [lockedJob[0].id]);
				// Remove the original
				// fs.unlinkSync(path.join(config.upload, lockedJob[0].key));
			}
		}
	} else {
		console.log('[', new Date(), '] Trying to find a new job to process');
		// Try and get a job that's not been processed at all yet
		let newJob = sql.run('SELECT id FROM videos WHERE uploaded=1 AND processed=0 AND lockedBy is null LIMIT 1');
		if(newJob.length === 1) {
			console.log('[', new Date(), '] Found and locking video with id', newJob[0].id);
			// Lock the job to this processor
			sql.run('UPDATE videos SET lockedBy=? WHERE id=? AND lockedBy is null', [processName, newJob[0].id]);
		} else {
			console.log('[', new Date(), '] Nothing to do, sleeping');
			sleep(10000);
		}
	}
	// Close the DB to force refreshing
	sql.close();
}
