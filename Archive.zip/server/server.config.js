const path = require('path');
module.exports = {
	ffmpeg: path.join('/', 'usr', 'local', 'Cellar', 'ffmpeg', '3.2.4', 'bin', 'ffmpeg'),
	processed: path.join(__dirname, 'upload', 'processed'),
	thumbnails: path.join(__dirname, 'upload', 'thumbnails'),
	upload: path.join(__dirname, 'upload')
};
