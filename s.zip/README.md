## Configure NPM and Yarn to route through Nexus proxy.

### Remove any existing proxy settings.
  
 1. npm config delete proxy –global
 2. npm config delete https-proxy –global
 3. yarn config delete proxy
 4. yarn config delete https-proxy
 
### Configure Yarn binaries
 
 1. yarn config set node_sqlite3_binary_host_mirror http://findevsubv01.fortis-uk.fortis.com:8082/nexus/repository/mapbox-node-binary/
 2. yarn config set sass_binary_site http://findevsubv01.fortis-uk.fortis.com:8082/nexus/repository/node-sass-download/
 
### Register Nexus

 1. npm config --global set registry "http://findevsubv01.fortis-uk.fortis.com:8082/nexus/repository/npm/"
 2. yarn config set registry http://findevsubv01.fortis-uk.fortis.com:8082/nexus/repository/yarnpkg/
 
## Clone and Run
 
 1. Clone the project
 2. Run `yarn install`
 3. Refer to package.json scripts.
 
## Generating RSA Keys
These are needed for the server to generate login tokens.  
They should be placed under `server/keys`  
To generate:  
```
mkdir -p server/keys
cd server/keys
openssl genrsa -out server.key 4096
openssl rsa -pubout -in server.key -out server.key.pub
```

For speed, 4096 can be replaced with a lower number such as 2048 or 1024 (not recommended outside of local development)
 