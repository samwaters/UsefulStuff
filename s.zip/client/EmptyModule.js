/**
 * @providesModule EmptyModule
 */
module.exports = '';
