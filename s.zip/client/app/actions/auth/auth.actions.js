import {ajaxCall} from '../ajax/ajax.actions';
import {push} from 'react-router-redux';

export const ACTIONS = {
	LOGIN: 'LOGIN',
	LOGIN_COMPLETE: 'LOGIN_COMPLETE',
	LOGIN_FAILED: 'LOGIN_FAILED',
	VERIFY: 'VERIFY',
	VERIFY_COMPLETE: 'VERIFY_COMPLETE',
	VERIFY_FAILED: 'VERIFY_FAILED'
};

const login = (username, password, redirect) => {
	return ajaxCall(
		'/api/auth/login',
		'POST',
		{username:username, password:password},
		loginComplete(redirect),
		ACTIONS.LOGIN
	);
};

const loginComplete = redirect => {
	return (dispatch, res) => {
		if(res.ok) {
			dispatch({type: ACTIONS.LOGIN_COMPLETE, payload: res.data});
			dispatch(push(redirect || '/home'));
		} else {
			dispatch({type: ACTIONS.LOGIN_FAILED, payload: res.error});
		}
	}
};

const verify = (username, redirect) => {
	return ajaxCall(
		'/api/auth/verify',
		'POST',
		{username:username},
		verifyComplete(redirect),
		ACTIONS.VERIFY
	)
};

const verifyComplete = redirect => {
	return (dispatch, res) => {
		if(res.ok) {
			dispatch({type: ACTIONS.VERIFY_COMPLETE, payload: res.data});
			dispatch(push(redirect || '/home'));
		} else {
			dispatch({type: ACTIONS.VERIFY_FAILED, payload: res.error});
		}
	}
};

export {login, verify}