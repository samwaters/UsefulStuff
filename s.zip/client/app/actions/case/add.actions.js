import {ajaxCall} from 'actions/ajax/ajax.actions';
import {push} from 'react-router-redux';

export const ACTIONS = {
	ADD_CASE_PHONE_SAVE: 'ADD_CASE_PHONE_SAVE',
	ADD_CASE_PHONE_DELETE: 'ADD_CASE_PHONE_DELETE',
	ADD_CASE_PERSON_SAVE: 'ADD_CASE_PERSON_SAVE',
	ADD_CASE_PERSON_DELETE: 'ADD_CASE_PERSON_DELETE',
	ADD_CASE_DELETE_PERSON: 'ADD_CASE_DELETE_PERSON',
	ADD_CASE_DELETE_PHONE: 'ADD_CASE_DELETE_PHONE',
	ADD_CASE_VEHICLE_SAVE: 'ADD_CASE_VEHICLE_SAVE',
	ADD_CASE_VEHICLE_DELETE: 'ADD_CASE_VEHICLE_DELETE',
	ADD_CASE_ADDRESS_SAVE: 'ADD_CASE_ADDRESS_SAVE',
	ADD_CASE_ADDRESS_DELETE: 'ADD_CASE_ADDRESS_DELETE',
	ADD_CASE_EMAIL_SAVE: 'ADD_CASE_EMAIL_SAVE',
	ADD_CASE_EMAIL_DELETE: 'ADD_CASE_EMAIL_DELETE',
	ADD_CASE_COMPANY_SAVE: 'ADD_CASE_COMPANY_SAVE',
	ADD_CASE_COMPANY_SAVE_COMPLETE: 'ADD_CASE_COMPANY_SAVE_COMPLETE',
	ADD_CASE_COMPANY_SAVE_FAILED: 'ADD_CASE_COMPANY_SAVE_FAILED',
	ADD_CASE_COMPANY_DELETE: 'ADD_CASE_COMPANY_DELETE',
	ADD_CASE_CUSTOM_SAVE: 'ADD_CASE_CUSTOM_SAVE',
	ADD_CASE_CUSTOM_DELETE: 'ADD_CASE_CUSTOM_DELETE',
	ADD_CASE_SAVE: 'ADD_CASE_SAVE',
	ADD_CASE_SAVE_COMPLETE: 'ADD_CASE_SAVE_COMPLETE',
	ADD_CASE_SAVE_FAILED: 'ADD_CASE_SAVE_FAILED',
	ADD_CASE_CANCEL: 'ADD_CASE_CANCEL',
	ADD_CASE_SET_DETAILS: 'ADD_CASE_SET_DETAILS'
};

const cancelCase = () => ({type: ACTIONS.ADD_CASE_CANCEL});

const deleteAddress = (id) => ({type: ACTIONS.ADD_CASE_ADDRESS_DELETE, id: id});
const deleteCompany = (id) => ({type: ACTIONS.ADD_CASE_COMPANY_DELETE, id: id});
const deleteCustom = (id) => ({type: ACTIONS.ADD_CASE_CUSTOM_DELETE, id: id});
const deleteEmail = (id) => ({type: ACTIONS.ADD_CASE_EMAIL_DELETE, id: id});
const deletePerson = (id) => ({type: ACTIONS.ADD_CASE_PERSON_DELETE, id: id});
const deletePhone = (id) => ({type: ACTIONS.ADD_CASE_PHONE_DELETE, id: id});
const deleteVehicle = (id) => ({type: ACTIONS.ADD_CASE_VEHICLE_DELETE, id: id});

const saveAddress = (values) => {
	return {
		type: ACTIONS.ADD_CASE_ADDRESS_SAVE,
		formValues: {...values, id: values.id ? values.id : new Date().getTime()}
	}
};

const saveCase = caseData => {
	return ajaxCall(
		'/api/case',
		'POST',
		caseData,
		saveComplete(),
		ACTIONS.ADD_CASE_SAVE
	)
};

const saveCompany = (values) => {
	return {
		type: ACTIONS.ADD_CASE_COMPANY_SAVE,
		formValues: {...values, id: values.id ? values.id : new Date().getTime()}
	}
};

const saveComplete = () => {
	return (dispatch, res) => {
		if(res.ok) {
			dispatch({type: ACTIONS.ADD_CASE_SAVE_COMPLETE, payload:res.data.caseId});
			dispatch(push('/case/' + res.data.caseId + '/view'));
		} else {
			dispatch({type: ACTIONS.ADD_CASE_SAVE_FAILED, payload: res.error});
		}
	}
};

const saveCustom = (values) => {
    return {
		type: ACTIONS.ADD_CASE_CUSTOM_SAVE,
		formValues: {...values, id: values.id ? values.id : new Date().getTime()}
    }
};

const saveEmail = (values) => {
	return {
		type: ACTIONS.ADD_CASE_EMAIL_SAVE,
		formValues: {...values, id: values.id ? values.id : new Date().getTime()}
	}
};

const savePerson = (values) => {
	return {
		type: ACTIONS.ADD_CASE_PERSON_SAVE,
		formValues: {...values, id: values.id ? values.id : new Date().getTime()}
	}
};

const savePhone = (values) => {
    return {
		type: ACTIONS.ADD_CASE_PHONE_SAVE,
		formValues: {...values, id: values.id ? values.id : new Date().getTime()}
    }
};
const saveVehicle = (values) => {
	return {
		type: ACTIONS.ADD_CASE_VEHICLE_SAVE,
		formValues: {...values, id: values.id ? values.id : new Date().getTime()}
    }
};

const setCaseDetails = details => ({type: ACTIONS.ADD_CASE_SET_DETAILS, payload: details});

export {
	cancelCase,
	deleteAddress,
	deleteCompany,
	deleteCustom,
	deleteEmail,
	deletePerson,
	deletePhone,
	deleteVehicle,
	saveAddress,
	saveCase,
	saveCompany,
	saveCustom,
	saveEmail,
	savePerson,
	savePhone,
	saveVehicle,
	setCaseDetails
}
