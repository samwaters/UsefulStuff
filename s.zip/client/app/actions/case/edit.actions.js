import {ajaxCall} from 'actions/ajax/ajax.actions';
import * as viewActions from 'actions/case/view.actions';

export const ACTIONS = {
	UPDATE_CASE_DETAILS: 'UPDATE_CASE_DETAILS',
	UPDATE_CASE_DETAILS_COMPLETE: 'UPDATE_CASE_DETAILS_COMPLETE',
	UPDATE_CASE_DETAILS_FAILED: 'UPDATE_CASE_DETAILS_FAILED'
};

const updateCaseDetails = (id, field, value, reason) => {
	return ajaxCall(
		'/api/case/' + id,
		'PATCH',
		{details: {[field]: value, reason: reason}},
		updateCaseComplete(),
		ACTIONS.UPDATE_CASE_DETAILS
	)
};

const updateCaseComplete = () => {
	return (dispatch, res) => {
		if(res.ok) {
			dispatch({type: ACTIONS.UPDATE_CASE_DETAILS_COMPLETE});
			dispatch(viewActions.loadCase(res.data.caseId));
		} else {
			dispatch({type: ACTIONS.UPDATE_CASE_DETAILS_FAILED, payload: res.error});
		}
	}
};

export {updateCaseDetails}