export const FIND_CASE = 'FIND_CASE';
export const FIND_CASE_RESET = 'FIND_CASE_RESET';
export const PREVIEW_CASE = 'PREVIEW_CASE';
export const CLOSE_PREVIEW_CASE = 'CLOSE_PREVIEW_CASE';
export const ACTIVE_FORM_CRITERIA = 'ACTIVE_FORM_CRITERIA';

export const ADD_CRITERIA_PEOPLE = 'ADD_CRITERIA_PEOPLE';
export const DELETE_CRITERIA_PEOPLE = 'DELETE_CRITERIA_PEOPLE';
export const UPDATE_CRITERIA_PEOPLE = 'UPDATE_CRITERIA_PEOPLE';

export const ADD_CRITERIA_ADDRESS = 'ADD_CRITERIA_ADDRESS';
export const DELETE_CRITERIA_ADDRESS = 'DELETE_CRITERIA_ADDRESS';
export const UPDATE_CRITERIA_ADDRESS = 'UPDATE_CRITERIA_ADDRESS';

export const ADD_CRITERIA_PHONE = 'ADD_CRITERIA_PHONE';
export const DELETE_CRITERIA_PHONE = 'DELETE_CRITERIA_PHONE';
export const UPDATE_CRITERIA_PHONE = 'UPDATE_CRITERIA_PHONE';

export const ADD_CRITERIA_EMAIL = 'ADD_CRITERIA_EMAIL';
export const DELETE_CRITERIA_EMAIL = 'DELETE_CRITERIA_EMAIL';
export const UPDATE_CRITERIA_EMAIL = 'UPDATE_CRITERIA_EMAIL';

export const ADD_CRITERIA_VEHICLE = 'ADD_CRITERIA_VEHICLE';
export const DELETE_CRITERIA_VEHICLE = 'DELETE_CRITERIA_VEHICLE';
export const UPDATE_CRITERIA_VEHICLE = 'UPDATE_CRITERIA_VEHICLE';

export const ADD_CRITERIA_COMPANY = 'ADD_CRITERIA_COMPANY';
export const DELETE_CRITERIA_COMPANY = 'DELETE_CRITERIA_COMPANY';
export const UPDATE_CRITERIA_COMPANY = 'UPDATE_CRITERIA_COMPANY';

export const setActiveFormCriteria = (id) => ({type: ACTIVE_FORM_CRITERIA, id: id});
export const findCaseReset = () => ({type: FIND_CASE_RESET});
export const findCase = () => ({type: FIND_CASE});
export const previewCase = (id) => ({type: PREVIEW_CASE, id: id});
export const closePreviewCase = () => ({type: CLOSE_PREVIEW_CASE});



export const addCriteriaCompany = () => ({type: ADD_CRITERIA_COMPANY, id: new Date().getTime()});
export const updateCriteriaCompany = (values, id) => ({
    type: UPDATE_CRITERIA_COMPANY,
    values: values,
    id: id
});
export const deleteCriteriaCompany = (id) => ({type: DELETE_CRITERIA_COMPANY, id: id});


export const addCriteriaVehicle = () => ({type: ADD_CRITERIA_VEHICLE, id: new Date().getTime()});
export const updateCriteriaVehicle = (values, id) => ({
    type: UPDATE_CRITERIA_VEHICLE,
    values: values,
    id: id
});
export const deleteCriteriaVehicle = (id) => ({type: DELETE_CRITERIA_VEHICLE, id: id});


export const addCriteriaPeople = () => ({type: ADD_CRITERIA_PEOPLE, id: new Date().getTime()});
export const updateCriteriaPeople = (values, id) => ({
    type: UPDATE_CRITERIA_PEOPLE,
    values: values,
    id: id
});
export const deleteCriteriaPeople = (id) => ({type: DELETE_CRITERIA_PEOPLE, id: id});


export const addCriteriaAddress = () => ({type: ADD_CRITERIA_ADDRESS, id: new Date().getTime()});
export const updateCriteriaAddress = (values, id) => ({
    type: UPDATE_CRITERIA_ADDRESS,
    values: values,
    id: id
});
export const deleteCriteriaAddress = (id) => ({type: DELETE_CRITERIA_ADDRESS, id: id});


export const addCriteriaPhone = () => ({type: ADD_CRITERIA_PHONE, id: new Date().getTime()});
export const updateCriteriaPhone = (values, id) => ({
    type: UPDATE_CRITERIA_PHONE,
    values: values,
    id: id
});
export const deleteCriteriaPhone = (id) => ({type: DELETE_CRITERIA_PHONE, id: id});

export const addCriteriaEmail = () => ({type: ADD_CRITERIA_EMAIL, id: new Date().getTime()});
export const updateCriteriaEmail = (values, id) => ({
    type: UPDATE_CRITERIA_EMAIL,
    values: values,
    id: id
});
export const deleteCriteriaEmail = (id) => ({type: DELETE_CRITERIA_EMAIL, id: id});







