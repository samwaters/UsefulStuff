import {ajaxCall} from 'actions/ajax/ajax.actions';

export const ACTIONS = {
	CLOSE_CASE: 'CLOSE_CASE',
	LOAD_CASE: 'LOAD_CASE',
	LOAD_CASE_COMPLETE: 'LOAD_CASE_COMPLETE',
	LOAD_CASE_FAILED: 'LOAD_CASE_FAILED',
	VIEW_CASE: 'VIEW_CASE'
};

const closeCase = () => ({type: ACTIONS.CLOSE_CASE});
const loadCase = id => {
	return ajaxCall(
		'/api/case/' + id,
		'GET',
		'',
		loadedCase(),
		ACTIONS.LOAD_CASE
	)
};
const loadedCase = () => {
	return (dispatch, res) => {
		if(res.ok) {
			dispatch({type: ACTIONS.LOAD_CASE_COMPLETE, payload: res.data});
		} else {
			dispatch({type: ACTIONS.LOAD_CASE_FAILED, error: res.error});
		}
	}
};
const viewCase = id => ({type: ACTIONS.VIEW_CASE, id: id});

export {closeCase, loadCase, viewCase}