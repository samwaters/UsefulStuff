export const UPDATE_NAVIGATION_TAB = 'UPDATE_NAVIGATION_TAB';

export const updateNavigationTab = (activeTab) => ({type: UPDATE_NAVIGATION_TAB, activeTab: activeTab});
