import React from 'react';
import {Layout, Panel} from 'react-toolbox';
import '../theme/theme';
import HeaderBar from 'components/home/headerbar.component';

class AppComponent extends React.Component {
    constructor() {
        super();
        this.state = {};
    }

    render() {
        const {main} = this.props;
        return <Layout>
            <Panel style={{display: 'flex', flexDirection: 'column', height: '100vh'}}>
                <HeaderBar />
                 <div style={{flex: 1, overflowY: 'auto', marginTop: '10px', marginBottom: '10px', padding: '0 10px'}}>
                    {main}
                </div>
            </Panel>
        </Layout>
    }
}

export default AppComponent;
