import React from 'react';
import CaseDetailsFormComponent from 'components/forms/casedetails.form';
import {connect} from 'react-redux';
import {updateNavigationTab} from 'actions/home/headerbar.actions';
import {hashHistory} from 'react-router';
import {bindActionCreators} from "redux";
import {viewCase} from 'actions/case/view.actions';
import {
    saveCase,
    cancelCase,
    savePerson,
    deletePerson,
    saveEmail,
    deleteEmail,
    saveAddress,
    deleteAddress,
    saveVehicle,
    deleteVehicle,
    savePhone,
    deletePhone,
    saveCompany,
    deleteCompany,
    saveCustom,
    deleteCustom

} from 'actions/case/add.actions';

import {Button, Card, CardTitle, CardText} from 'react-toolbox';
import {Row, Col} from 'components/common/grid';
import {Error} from 'components/common/messages';
import * as styles from 'components/case/add/addcase.styles';

import PeopleList from 'components/lists/peoplelist.component';
import PersonForm from 'components/forms/person.form';
import EmailList from 'components/lists/emaillist.component';
import EmailForm from 'components/forms/email.form';
import AddressList from 'components/lists/addresslist.component';
import AddressForm from 'components/forms/address.form';
import VehicleList from 'components/lists/vehiclelist.component';
import VehicleForm from 'components/forms/vehicle.form';
import PhoneList from 'components/lists/phonelist.component';
import PhoneForm from 'components/forms/phone.form';
import CustomList from 'components/lists/customlist.component';
import CustomForm from 'components/forms/custom.form';
import CompanyList from 'components/lists/companylist.component';
import CompanyForm from 'components/forms/companies.form';

import AddCaseItem from "./addcase.item.component";

class AddCase extends React.Component {

    constructor() {
        super();
        this.saveCase = this.saveCase.bind(this);
        this.cancelCase = this.cancelCase.bind(this);
    }

    componentDidMount() {
        this.props.updateNavigationTab(2);
    }

    cancelCase() {
        this.props.cancelCase();
        hashHistory.push('/find');
    }

    saveCase() {
        this.props.saveCase({
            details: this.props.details,
            people: this.props.people,
            addresses: this.props.addresses,
            vehicles: this.props.vehicles,
            phones: this.props.phones,
            emails: this.props.emails,
            companies: this.props.companies
        });
    }

    render() {
        return <div>
            <h3>Add Case</h3>
            {
                this.props.error && <Error>{this.props.error}</Error>
            }
            <Row>
                <Col xs={12} md={8} mdOffset={2}>
                    <Card>
                        <CardTitle title="Case Details"/>
                        <CardText>
                            <CaseDetailsFormComponent/>
                        </CardText>
                    </Card>

                    <AddCaseItem
                        items={this.props.people}
                        save={this.props.savePerson}
                        delete={this.props.deletePerson}
                        title="Person"
                        ListComponent={PeopleList}
                        FormComponent={PersonForm}
                    />

                    <AddCaseItem
                        items={this.props.addresses}
                        save={this.props.saveAddress}
                        delete={this.props.deleteAddress}
                        title="Addresses"
                        ListComponent={AddressList}
                        FormComponent={AddressForm}
                    />

                    <AddCaseItem
                        items={this.props.phones}
                        save={this.props.savePhone}
                        delete={this.props.deletePhone}
                        title="Phone Numbers"
                        ListComponent={PhoneList}
                        FormComponent={PhoneForm}
                    />

                    <AddCaseItem
                        items={this.props.emails}
                        save={this.props.saveVehicle}
                        delete={this.props.deleteVehicle}
                        title="Vehicles"
                        ListComponent={VehicleList}
                        FormComponent={VehicleForm}
                    />

                    <AddCaseItem
                        items={this.props.emails}
                        save={this.props.saveEmail}
                        delete={this.props.deleteEmail}
                        title="Email"
                        ListComponent={EmailList}
                        FormComponent={EmailForm}
                    />

                    <AddCaseItem
                        items={this.props.companies}
                        save={this.props.saveCompany}
                        delete={this.props.deleteCompany}
                        title="Companies"
                        ListComponent={CompanyList}
                        FormComponent={CompanyForm}
                    />

                    <AddCaseItem
                        items={this.props.custom}
                        save={this.props.saveCustom}
                        delete={this.props.deleteCustom}
                        title="Companies"
                        ListComponent={CustomList}
                        FormComponent={CustomForm}
                    />

                </Col>
            </Row>
            <Row>
                <Col xs={12} md={8} mdOffset={2}>
                    <div className={styles.buttonContainer}>
                        <Button accent label='Cancel' onClick={this.cancelCase} raised/>
                        <Button label='Save' onClick={this.saveCase} primary raised/>
                    </div>
                </Col>
            </Row>
        </div>
    }

}

const mapStateToProps = state => {
    return {
        details: state.caseadd.details,
        error: state.caseadd.error,
        people: state.caseadd.people,
        addresses: state.caseadd.addresses,
        vehicles: state.caseadd.vehicles,
        phones: state.caseadd.phones,
        emails: state.caseadd.emails,
        companies: state.caseadd.companies,
        custom: state.caseadd.custom
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators({
        updateNavigationTab,
        viewCase,
        saveCase,
        cancelCase,
        savePerson,
        deletePerson,
        saveEmail,
        deleteEmail,
        saveAddress,
        deleteAddress,
        saveVehicle,
        deleteVehicle,
        savePhone,
        deletePhone,
        saveCompany,
        deleteCompany,
        saveCustom,
        deleteCustom
    }, dispatch);
};

export default connect(mapStateToProps, mapDispatchToProps)(AddCase);

