import React, {Component} from 'react';
import Dialog from 'react-toolbox/lib/dialog';
import {Button, Card, CardTitle, CardText} from 'react-toolbox';

class AddCaseItem extends Component {

    constructor(props) {

        super(props);

        this.state = {
            addModalActive: false,
            editItem: {}
        };

        this.handleFormSubmit = this.handleFormSubmit.bind(this);
        this.handleFormCancel = this.handleFormCancel.bind(this);
        this.handleListAdd = this.handleListAdd.bind(this);
        this.handleListEdit = this.handleListEdit.bind(this);
        this.handleListDelete = this.handleListDelete.bind(this);
    }

    handleModalViewToggle() {
        this.setState({addModalActive: !this.state.addModalActive});
    }

    handleFormSubmit(values) {
        this.props.save(values);
        this.handleModalViewToggle();
    }

    handleFormCancel() {
        this.handleModalViewToggle();
    }

    handleListDelete(item) {
        this.props.delete(item.id);
    }

    handleListEdit(item) {
        this.setState({editItem: item});
        this.handleModalViewToggle();
    }

    handleListAdd() {
        this.setState({editItem: {}});
        this.handleModalViewToggle();
    }

    render() {

        const {ListComponent, FormComponent} = this.props;

        return (
            <div>

                <Card style={{marginTop:'10px', position:'relative'}}>
                    <CardTitle title={this.props.title} />
                    <CardText>

                        <ListComponent
                            items={this.props.items}
                            onEditItem={this.handleListEdit}
                            onDeleteItem={this.handleListDelete}/>

                        <Button onClick={this.handleListAdd} accent floating icon="add" mini
                                style={{position: 'absolute', right: '10px', top: '10px'}}/>
                    </CardText>
                </Card>

                <Dialog
                    active={this.state.addModalActive}
                    title={`Add ${this.props.title}`}>

                    <FormComponent
                        initItem={this.state.editItem}
                        onSubmit={this.handleFormSubmit}
                        onCancel={this.handleFormCancel}
                    />

                </Dialog>

            </div>
        )
    }
}

export default AddCaseItem;

