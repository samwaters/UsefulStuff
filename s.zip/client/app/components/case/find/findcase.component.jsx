import React, {Component} from 'react'
import {connect} from "react-redux";
import {bindActionCreators} from "redux";

import {Button, Card, CardTitle, CardText} from 'react-toolbox';
import {Row, Col} from 'components/common/grid';

import {List} from 'react-toolbox/lib/list';

import ReactCSSTransitionGroup from 'react-addons-css-transition-group'
import FindResultList from 'components/case/find/findresults.component'
import {updateNavigationTab} from 'actions/home/headerbar.actions'
import CriteriaButtonBar from 'components/criteria/buttonbar.criteria.component';
import PersonCriteriaSummary from 'components/criteria/person.criteria.summary.component';
import AddressCriteriaSummary from 'components/criteria/address.criteria.summary.component';
import PhoneCriteriaSummary from 'components/criteria/phone.criteria.summary.component';
import VehicleCriteriaSummary from 'components/criteria/vehicle.criteria.summary.component';
import EmailCriteriaSummary from 'components/criteria/email.criteria.summary.component';
import CompanyCriteriaSummary from 'components/criteria/company.criteria.summary.component';
import {findCase, setActiveFormCriteria, findCaseReset} from 'actions/case/find.actions';
import * as styles from 'components/case/find/find.styles';

class FindCase extends Component {

    constructor(props) {
        super(props);
    }

    componentDidMount() {
        this.props.updateNavigationTab(0);
    }

    render() {

        const {people, addresses, phones, emails, vehicles, companies} = this.props.criteria;

        let disableButtons = false;
        if (this.props.activeFormCriteria) {
            disableButtons = this.props.activeFormCriteria > 0;
        }

        let hasCriteria = {};
        ['people', 'addresses', 'phones', 'emails', 'vehicles', 'companies', 'custom'].map((collection) => {
            hasCriteria = {...hasCriteria, [collection]: this.props.criteria[collection].length > 0};
        });

        console.log('hasCriteria', hasCriteria);

        let requiresAnd = false;

        return (

            <div>
                <div>

                    <h3>Criteria</h3>

                    <CriteriaButtonBar disableButtons={disableButtons}/>

                    <List selectable ripple={false}>

                        <ReactCSSTransitionGroup transitionName="transitionfade" transitionEnterTimeout={200}
                                                 transitionLeaveTimeout={400}>

                            {people.map((person) =>
                                <PersonCriteriaSummary key={`renderPerson${person.id}`} item={person}/>
                            )}
                            { requiresAnd = hasCriteria['people']}

                            { (hasCriteria['addresses'] && requiresAnd) && <div className={styles.divider}> And </div> }
                            {addresses.map((address) =>
                                <AddressCriteriaSummary key={`renderAddress${address.id}`} item={address}/>
                            )}
                            { requiresAnd = hasCriteria['addresses'] || requiresAnd}

                            { (hasCriteria['phones'] && requiresAnd) && <div className={styles.divider}> And </div> }
                            {phones.map((phone) =>
                                <PhoneCriteriaSummary key={`renderPhone${phone.id}`} item={phone}/>
                            )}
                            { requiresAnd = hasCriteria['phones'] || requiresAnd}

                            { (hasCriteria['emails'] && requiresAnd) && <div className={styles.divider}> And </div> }
                            {emails.map((email) =>
                                <EmailCriteriaSummary key={`renderEmail${email.id}`} item={email}/>
                            )}
                            { requiresAnd = hasCriteria['emails'] || requiresAnd}

                            { (hasCriteria['vehicles'] && requiresAnd) && <div className={styles.divider}> And </div> }
                            {vehicles.map((vehicle) =>
                                <VehicleCriteriaSummary key={`renderVehicle${vehicle.id}`} item={vehicle}/>
                            )}
                            { requiresAnd = hasCriteria['vehicles'] || requiresAnd}

                            { (hasCriteria['companies'] && requiresAnd) && <div className={styles.divider}> And </div> }
                            {companies.map((company) =>
                                <CompanyCriteriaSummary key={`renderCompany${company.id}`} item={company}/>
                            )}

                        </ReactCSSTransitionGroup>


                    </List>

                    <div className={styles.buttonContainer}>
                        <Button disabled={disableButtons} onClick={() => this.props.findCase()} label='Search'
                                primary
                                raised/>
                        <Button disabled={disableButtons} accent label='Reset' onClick={() => this.props.findCaseReset()} raised/>
                    </div>

                </div>

                { this.props.results &&
                <FindResultList cases={this.props.results}/>
                }

            </div>
        )
    }
}

const mapStateToProps = state => {
    return {
        results: state.casefind.results,
        preview: state.casefind.preview,
        criteria: state.casefind.criteria,
        activeFormCriteria: state.casefind.criteria.activeFormCriteria
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators({
        findCaseReset,
        findCase: findCase,
        updateNavigationTab: updateNavigationTab,
        setActiveFormCriteria: setActiveFormCriteria,
    }, dispatch)
};

export default connect(mapStateToProps, mapDispatchToProps)(FindCase);

