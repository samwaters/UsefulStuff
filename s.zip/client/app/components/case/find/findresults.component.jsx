import React, {Component} from "react";
import {connect} from "react-redux";
import {hashHistory} from 'react-router';
import {bindActionCreators} from "redux";

import Dialog from 'react-toolbox/lib/dialog';
import {Button, Card, CardTitle} from 'react-toolbox';

import ViewCase from 'components/case/view/previewcase.component';
import {previewCase, closePreviewCase} from 'actions/case/find.actions';
import {viewCase} from 'actions/case/view.actions';
import {Table, TableHead, TableRow, TableCell} from 'react-toolbox/lib/table';
import {Col, Row} from "../../common/grid";
import FontIcon from 'react-toolbox/lib/font_icon';
class FindResultList extends Component {

    constructor(props) {
        super(props);

        this.state = {
            previewModalActive: false
        };

        this.handleModalPreviewToggle = this.handleModalPreviewToggle.bind(this);
        this.pop = this.pop.bind(this);
        this.viewCase = this.viewCase.bind(this);

    }

    handleModalPreviewToggle() {
        this.setState({previewModalActive: !this.state.previewModalActive});
    }

    viewCase(caseId) {
        this.props.viewCase(caseId);
        hashHistory.push(`/case/${caseId}/view`);
    }

    pop(caseId) {
        this.props.closePreviewCase();
        window.open(`/#/case/${caseId}`, '_blank');
    }

    renderResult(mCase) {
        return (
            <Row key={mCase.id}>
                <Col mdOffset={1} md={10} >
                    <Card style={{marginTop: '10px', padding: '5px'}}>
                        <CardTitle
                            avatar={<FontIcon value='business'/>}
                            title={mCase.id}
                        />
                        <Row>
                            <Col style={{padding: '10px'}}>
                                Case Description sdfk jsalf jsaldjf lsakjf lksaj flsadjf ldsajf ljsa lfsadl fsa fkdsa jf
                                 ;sakf ;dsakf lsdf lksadh fkhsf khsa kfhsa kfhska hfksadhfksahdf kdsahfkjhsa fksadh fksa df
                                lkjs flsajdflkjdsafk hsadkfhsakdhf ksadhf ksadhfkdsahf khdsaf kdsah fksdkfjhsadkfh ksad
                                lkjdsa flksdafk hdsafk hdsafkhsadkjfh sakjfkdsa hfkjsa d
                            </Col>
                        </Row>
                        <Row>
                            <Col mdOffset={10} md={2}>
                                <Button raised onClick={() => this.props.previewCase(mCase.id)}>Preview</Button>
                                <Button raised onClick={() => this.viewCase(mCase.id)}>View</Button>
                            </Col>
                        </Row>
                    </Card>
                </Col>
            </Row>
        )
    }

    render() {

        let actions = [
            {label: "Close", onClick: this.props.closePreviewCase},
        ];

        return (
            <div>
                { this.props.cases.length > 0 &&
                <div>
                    <h3>Results</h3>
                    {this.props.cases.map((mCase) => this.renderResult(mCase))}
                </div>
                }

                <Dialog
                    active={this.props.mCase.id != null}
                    title='Preview Case'
                    actions={actions}>

                    <ViewCase case={this.props.mCase}/>

                </Dialog>

            </div>
        )
    }
}

const mapStateToProps = state => {
    return {
        mCase: state.casefind.preview
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators({previewCase, viewCase, closePreviewCase}, dispatch);
};

export default connect(mapStateToProps, mapDispatchToProps)(FindResultList);
