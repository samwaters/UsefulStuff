import React from "react";

/**
 * Stateless presentation component for a Market Database Case.
 *
 * @param props
 */
export default (props) => {

    const {id} = props.case;

    return (
        <div>
            <h1>{id}</h1>
        </div>
    )

};