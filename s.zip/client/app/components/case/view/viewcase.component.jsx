import React from 'react';
import {connect} from "react-redux";
import {updateNavigationTab} from 'actions/home/headerbar.actions';
import {loadCase} from 'actions/case/view.actions';
import {Row,Col} from 'components/common/grid';
import {Button,Card,CardTitle,CardText,Input} from 'react-toolbox';
// Lists
import CaseDetailsListComponent from 'components/lists/casedetailslist.component';
import PeopleListComponent from 'components/lists/peoplelist.component';
import AddressListComponent from 'components/lists/addresslist.component';
import VehicleListComponent from 'components/lists/vehiclelist.component';
import PhoneListComponent from 'components/lists/phonelist.component';
import EmailListComponent from 'components/lists/emaillist.component';
import CompanyListComponent from 'components/lists/companylist.component';
import CustomListComponent from 'components/lists/customlist.component';

class ViewCaseComponent extends React.Component {
	constructor() {
		super();
		this.state = {
			editing: false,
			editReason: ''
		}
	}

	componentDidMount() {
		this.props.updateNavigationTab(1);
		this.props.loadCase(this.props.params.id);
	}

	handleFieldChange(field, value) {
		this.setState({[field]: value});
	}

	render() {
		return (
			<div style={{position:'relative'}}>
				<h3>Review Case</h3>
				<Button
					accent floating
					icon={this.state.editing ? "save" : "edit"}
					mini
					onClick={() => this.toggleEdit()}
					style={{position:'absolute', right:'10px', top:'10px'}}
				/>
				<Row>
					<Col xs={12} md={8} mdOffset={2}>
						{
							this.state.editing && <Card style={{marginBottom:'10px'}}>
								<CardTitle title="Edit Reason" />
								<CardText>
									<p>Provide a brief description of the change(s) you are making and the reason for them</p>
									<Input label="Edit Reason" onChange={v => this.handleFieldChange('editReason', v)} type="text" value={this.state.editReason} />
								</CardText>
							</Card>
						}
						<Card>
							<CardTitle title="Case Details" />
							<CardText>
								<CaseDetailsListComponent editable={this.state.editing} editreason={this.state.editReason} items={this.props.caseDetails.details} />
							</CardText>
						</Card>
						<Card style={{marginTop:'10px'}}>
							<CardTitle title="People" />
							<CardText>
								<PeopleListComponent editable={this.state.editing} editreason={this.state.editReason} items={this.props.caseDetails.people} />
							</CardText>
						</Card>
						<Card style={{marginTop:'10px'}}>
							<CardTitle title="Addresses" />
							<CardText>
								<AddressListComponent editable={this.state.editing} editreason={this.state.editReason} items={this.props.caseDetails.addresses} />
							</CardText>
						</Card>
						<Card style={{marginTop:'10px'}}>
							<CardTitle title="Vehicles" />
							<CardText>
								<VehicleListComponent editable={this.state.editing} editreason={this.state.editReason} items={this.props.caseDetails.vehicles} />
							</CardText>
						</Card>
						<Card style={{marginTop:'10px'}}>
							<CardTitle title="Phones" />
							<CardText>
								<PhoneListComponent editable={this.state.editing} editreason={this.state.editReason} items={this.props.caseDetails.phones} />
							</CardText>
						</Card>
						<Card style={{marginTop:'10px'}}>
							<CardTitle title="Emails" />
							<CardText>
								<EmailListComponent items={this.props.caseDetails.emails} />
							</CardText>
						</Card>
						<Card style={{marginTop:'10px'}}>
							<CardTitle title="Companies" />
							<CardText>
								<CompanyListComponent editable={this.state.editing} editreason={this.state.editReason} items={this.props.caseDetails.companies} />
							</CardText>
						</Card>
						<Card style={{marginTop:'10px'}}>
							<CardTitle title="Custom" />
							<CardText>
								<CustomListComponent editable={this.state.editing} editreason={this.state.editReason} items={this.props.caseDetails.custom} />
							</CardText>
						</Card>
					</Col>
				</Row>
			</div>
		)
	}

	toggleEdit() {
		this.setState({editing: !this.state.editing});
	}
}

export default connect(
	state => {
		return {
			caseDetails: state.casereview.caseDetails,
			people: state.casereview.people,
			addresses: state.casereview.addresses,
			vehicles: state.casereview.vehicles,
			phones: state.casereview.phones,
			emails: state.casereview.emails,
			companies: state.casereview.companies,
			custom: state.casereview.custom,
			error: state.casereview.error,
			loading: state.casereview.loading
		}
	},
	dispatch => {
		return {
			loadCase: id=> dispatch(loadCase(id)),
			updateNavigationTab: id => dispatch(updateNavigationTab(id))
		}
	}
)(ViewCaseComponent);