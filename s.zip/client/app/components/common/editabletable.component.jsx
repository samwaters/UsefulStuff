import React from 'react';
import {Button, Dropdown, Input, ProgressBar} from 'react-toolbox';
import * as styles from 'components/common/editabletable.styles';

class EditableTableComponent extends React.Component {
	constructor() {
		super();
		this.state = {
			currentlyEditingRow: '',
			currentlyEditingRowValue: ''
		}
	}

	cancelEdit() {
		this.setState({currentlyEditingRow: 0});
	}

	editRow(field, value) {
		if(this.props.onEdit) {
			this.props.onEdit();
		}
		this.setState({currentlyEditingRow: field, currentlyEditingRowValue: value});
	}

	handleFieldChange(v) {
		this.setState({currentlyEditingRowValue: v});
	}

	render() {
		let rows = [];
		this.props.rows.forEach(row => {
			let tds = [];
			tds.push(<td className={styles.editableTableLabel} key="label">{row.label}</td>);
			if(this.props.editable) {
				let input;
				if(row.type === 'dropdown') {
					input = <Dropdown label={row.label} source={row.options} onChange={v => this.handleFieldChange(v)} value={this.state.currentlyEditingRowValue} />
				} else {
					input = <Input type="text" multiline={row.type==='textarea'} onChange={v => this.handleFieldChange(v)} value={this.state.currentlyEditingRowValue} />
				}
				if(this.state.currentlyEditingRow && row.id === this.state.currentlyEditingRow) {
					tds.push(<td className={styles.editableTableValue} key="value">{input}</td>);
					tds.push(<td className={styles.editableTableButtons} key="buttons">
						<Button icon="save" flat mini primary onClick={() => this.saveEdit()}/>
						<Button accent icon="cancel" flat mini onClick={() => this.cancelEdit()}/>
					</td>);
				} else {
					tds.push(<td className={styles.editableTableValue} key="value">{row.value}</td>);
					tds.push(<td className={styles.editableTableButtons} key="buttons">
						<Button
							disabled={this.state.currentlyEditingRow !== ''}
							icon="edit" flat primary
							onClick={() => this.editRow(row.id, row.value)}
						/>
					</td>);
				}
			} else {
				tds.push(<td className={styles.editableTableValue} key="value">{row.value}</td>);
			}
			rows.push(<tr className={styles.editableTableRow} key={row.id}>{tds}</tr>);
		});
		return <div className={styles.editableTableContainer}>
			{
				this.props.saving && <div className={styles.overlay}>
					<ProgressBar className={styles.overlayProgress} type="circular" mode="indeterminate" />
				</div>
			}
			<table className={styles.editableTable}>
				<tbody>{rows}</tbody>
			</table>
		</div>
	}

	saveEdit() {
		this.props.onSave(this.state.currentlyEditingRow, this.state.currentlyEditingRowValue);
		this.setState({currentlyEditingRow: '', currentlyEditingRowValue: ''});
	}
}

EditableTableComponent.propTypes = {
	editable: React.PropTypes.bool.isRequired,
	onEdit: React.PropTypes.func,
	onSave: React.PropTypes.func.isRequired,
	rows: React.PropTypes.array.isRequired,
	saving: React.PropTypes.bool.isRequired
};

export default EditableTableComponent;