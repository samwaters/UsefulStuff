import React from 'react'
import {
    reduxForm,
    isSubmitting,
    getFormSyncErrors,
    SubmissionError
} from 'redux-form'
import {connect} from 'react-redux'
import {Button} from 'react-toolbox/lib/button';
import {TextInputField, DropDownListField} from 'components/fields/MaterialUI.form.components';
import {Col, Row} from 'components/common/grid'
import * as styles from 'components/criteria/criteria.styles.scss'

let AddressCriteriaForm = (props) => {

    const {onSubmit, submitting, onCancel, handleSubmit, id, error, isNew} = props;

    const operators = [
        {value: '', label: ''},
        {value: 'equal', label: 'Equal To'},
        {value: 'start', label: 'Starts with'},
        {value: 'ends', label: 'Ends with'}

    ];

    let submitButtonLabel = 'Update';
    if (isNew) {
        submitButtonLabel = 'Add';
    }

    return (


        <form onSubmit={handleSubmit(values => {
            formLevelValidation(values);
            onSubmit(values, id);
        })}>
            <Row>
                <Col md={12}>
                    <strong>{error && error}</strong>
                </Col>
            </Row>

            <AddressRow operators={operators} fieldName={'line1'} label='Line 1'/>
            <AddressRow operators={operators} fieldName={'line2'} label='Line 2'/>
            <AddressRow operators={operators} fieldName={'line3'} label='Line 3'/>
            <AddressRow operators={operators} fieldName={'line4'} label='Line 4'/>
            <AddressRow operators={operators} fieldName={'line5'} label='Line 5'/>
            <AddressRow operators={operators} fieldName={'line6'} label='Line 6'/>

            <Row>
                <Col md={3}>
                    <div className={styles.criteriaItemHeading}>Postcode</div>
                </Col>
                <Col md={2}>
                    <DropDownListField name="postcodeOperator" label="Operator" source={operators}/>
                </Col>
                <Col md={3}>
                    <TextInputField name="postcode" label="value" required/>
                </Col>

                <Col md={4}>
                    <div className={styles.buttonContainer}>
                        <Button type="submit" label={submitButtonLabel} disabled={submitting} raised primary/>
                        <Button type="button" label='Cancel' onClick={() => onCancel(id, isNew)} raised accent/>
                    </div>
                </Col>
            </Row>
        </form>
    );

};

AddressCriteriaForm.propTypes = {
    onCancel: React.PropTypes.func.isRequired,
    id: React.PropTypes.number.isRequired,
    isNew: React.PropTypes.bool.isRequired
};

const AddressRow = (props) => {

    const {operators, fieldName, label} = props;

    return (
        <Row>
            <Col md={3}>
                <div className={styles.criteriaItemHeading}>{label}</div>
            </Col>
            <Col md={2}>
                <DropDownListField name={`${fieldName}Operator`} label="Operator" source={operators}/>
            </Col>
            <Col md={3}>
                <TextInputField name={fieldName} label="value" required/>
            </Col>
            <Col md={4}>
            </Col>
        </Row>
    )
};

AddressRow.propTypes = {
    fieldName: React.PropTypes.string.isRequired,
    operators: React.PropTypes.arrayOf(React.PropTypes.object).isRequired,
};

const hasValue = (field) => {
    return field && field.length > 0
};


const validateOperatorFieldValue = (errors, fieldname, operatorField, valueField) => {

    const hasOperator = hasValue(operatorField);
    const hasFieldValue = hasValue(valueField);

    if (hasOperator && !hasFieldValue) {
        errors[fieldname] = "required";
    }

    if (!hasOperator && hasFieldValue) {
        errors[`${fieldname}Operator`] = "required";
    }

};

const formLevelValidation = (values) => {

    if (!hasValue(values.line1)) {
        throw new SubmissionError({_error: 'Please complete at least one address criteria'});
    }
};

const fieldLevelValidation = (values) => {

    const errors = {};
    validateOperatorFieldValue(errors, 'line1', values.line1Operator, values.line1);
    validateOperatorFieldValue(errors, 'line2', values.line2Operator, values.line2);
    validateOperatorFieldValue(errors, 'line3', values.line3Operator, values.line3);
    validateOperatorFieldValue(errors, 'line4', values.line4Operator, values.line4);
    validateOperatorFieldValue(errors, 'line5', values.line5Operator, values.line5);
    validateOperatorFieldValue(errors, 'line6', values.line6Operator, values.line6);

    return errors;

};

const formName = 'addAddressCriteriaForm';

AddressCriteriaForm = reduxForm({
    form: formName,
    fieldLevelValidation
})(AddressCriteriaForm);

const mapStateToProps = (state, ownProps) => {

    let props = {
        errors: getFormSyncErrors(formName)(state),
        submitting: isSubmitting(formName)(state),
        initialValues: {}
    };

    if (ownProps.initItem) {
        props = {...props, id: ownProps.initItem.id, initialValues: ownProps.initItem};
    }

    return props;

};

export default AddressCriteriaForm = connect(mapStateToProps)(AddressCriteriaForm);