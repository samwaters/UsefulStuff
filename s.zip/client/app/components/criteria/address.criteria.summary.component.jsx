import React, {Component} from 'react';
import {connect} from "react-redux";
import {bindActionCreators} from "redux";
import {Button, Card} from 'react-toolbox';
import AddressCriteriaForm from 'components/criteria/address.criteria.form.component.jsx';
import {ListItem, ListDivider} from 'react-toolbox/lib/list';
import ReactCSSTransitionGroup from 'react-addons-css-transition-group';
import {Col, Row} from 'components/common/grid';
import {
    setActiveFormCriteria,
    deleteCriteriaAddress,
    updateCriteriaAddress
} from 'actions/case/find.actions';

import * as styles from 'components/criteria/criteria.styles';
import criteriaActions from 'components/criteria/criteria.buttons.component';
import FontIcon from 'react-toolbox/lib/font_icon';
import Chip from 'react-toolbox/lib/chip';
import operatorsMap from 'components/criteria/operators';

class AddressCriteriaSummary extends Component {

    constructor(props) {

        super(props);

        this.handleCancelAdd = this.handleCancelAdd.bind(this);
        this.handleSubmitAdd = this.handleSubmitAdd.bind(this);
    }

    handleSubmitAdd(values, id) {
        this.props.updateCriteria(values, id);
    }

    handleCancelAdd(id, isNew) {

        if (isNew) {
            this.props.deleteCriteria(id);
        }
        this.props.setActiveFormCriteria(0);

    }

    render() {

        const {item} = this.props;

        let disableButtons = false;
        if (this.props.activeFormCriteria) {
            disableButtons = this.props.activeFormCriteria > 0;
        }

        const ListItemContent = ({address}) => {

            return (
                <div className={styles.itemDescription + ' ' + styles.itemDescriptionWrapper}>
                    <div>An <em>address</em> where </div>

                    { [1, 2, 3, 4, 5, 6].map((lineNum) => {
                            return (
                                <AddressPart addressLine={address[`line${lineNum}`]}
                                             addressLineOperator={address[`line${lineNum}Operator`]}
                                             nextAddressLine={address[`line${lineNum + 1}`]}
                                             lineNum={lineNum}
                                             key={lineNum}/>
                            )
                        }
                    )}

                </div>
            )
        };

        const AddressPart = (props) => {

            const {addressLine, addressLineOperator, nextAddressLine, lineNum} = props;

            return (
                <div>
                    {addressLine && <Chip><em>line {lineNum} </em> {operatorsMap[addressLineOperator] } <em> { addressLine }</em></Chip>}
                    {(addressLine && nextAddressLine) && <div> and </div>}
                </div>
            )
        };

        return (

            <div key={`addressItem_${item.id}`}>
                <div>
                    <ListItem
                        className={styles.avatar}
                        avatar={<FontIcon className={styles.customMaterialIcon} value='location_on'/>}
                        caption='Address'
                        itemContent={<ListItemContent address={item}/>}
                        rightActions={criteriaActions(item.id, disableButtons, this.props.deleteCriteria, this.props.setActiveFormCriteria)}
                        ripple={false}>
                    </ListItem>
                    <ListDivider />
                </div>

                <Row>
                    <Col md={11} mdOffset={1}>

                        <ReactCSSTransitionGroup transitionName="transitionfade" transitionEnterTimeout={300}
                                                 transitionLeaveTimeout={300}>

                            { this.props.activeFormCriteria === item.id &&

                            <Card className={styles.shadowDiv}>

                                <AddressCriteriaForm
                                    initItem={item}
                                    isNew={item.isNew}
                                    onSubmit={this.handleSubmitAdd}
                                    onCancel={this.handleCancelAdd}
                                />

                            </Card>
                            }
                        </ReactCSSTransitionGroup>
                    </Col>
                </Row>
            </div>

        );

    }

}

const mapStateToProps = state => {
    return {
        results: state.casefind.results,
        preview: state.casefind.preview,
        criteria: state.casefind.criteria,
        activeFormCriteria: state.casefind.criteria.activeFormCriteria
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators({
        deleteCriteria: deleteCriteriaAddress,
        updateCriteria: updateCriteriaAddress,
        setActiveFormCriteria: setActiveFormCriteria
    }, dispatch)
};

export default connect(mapStateToProps, mapDispatchToProps)(AddressCriteriaSummary);