import React, {Component} from 'react';
import {Button} from 'react-toolbox/lib/button';
import {connect} from "react-redux";
import {bindActionCreators} from "redux";
import {
    addCriteriaPeople,
    addCriteriaAddress,
    addCriteriaPhone,
    addCriteriaEmail,
    addCriteriaVehicle,
    addCriteriaCompany
} from 'actions/case/find.actions';

class CriteriaButtonBar extends Component {

    render() {

        const {disableButtons} = this.props;

        return (
            <div>
                <Button icon='account_circle' label='Add Person' disabled={disableButtons} raised={true}
                        onClick={() => {
                            this.props.addCriteriaPeople();
                        }}/>
                <Button icon='location_on' label='Add Address' disabled={disableButtons} raised={true} onClick={() => {
                    this.props.addCriteriaAddress();
                }}/>
                <Button icon='local_phone' label='Add Phone' disabled={disableButtons} raised={true} onClick={() => {
                    this.props.addCriteriaPhone();
                }}/>
                <Button icon='email' label='Add E-Mail' disabled={disableButtons} raised={true} onClick={() => {
                    this.props.addCriteriaEmail();
                }}/>
                <Button icon='directions_car' label='Add Vehicle' disabled={disableButtons} raised={true}
                        onClick={() => {
                            this.props.addCriteriaVehicle();
                        }}/>
                <Button icon='business' label='Add Company' disabled={disableButtons} raised={true}
                        onClick={() => {
                            this.props.addCriteriaCompany();
                        }}/>
                <Button icon='more_horiz' label='Add Custom' disabled={disableButtons} raised={true}/>
            </div>
        )
    }
}

const mapStateToProps = state => {
    return {
        activeFormCriteria: state.casefind.criteria.activeFormCriteria
    };
};


const mapDispatchToProps = dispatch => {
    return bindActionCreators({
        addCriteriaPeople,
        addCriteriaAddress,
        addCriteriaPhone,
        addCriteriaEmail,
        addCriteriaVehicle,
        addCriteriaCompany
    }, dispatch)
};

export default connect(mapStateToProps, mapDispatchToProps)(CriteriaButtonBar);