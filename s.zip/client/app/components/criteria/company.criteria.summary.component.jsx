import React, {Component} from 'react'
import {connect} from "react-redux";
import {bindActionCreators} from "redux";
import {Button, Card, Chip} from 'react-toolbox';
import CompanyCriteriaForm from 'components/criteria/company.criteria.form.component.jsx';
import {ListItem, ListDivider} from 'react-toolbox/lib/list';
import ReactCSSTransitionGroup from 'react-addons-css-transition-group'
import {Col, Row} from 'components/common/grid'
import {
    setActiveFormCriteria,
    deleteCriteriaCompany,
    updateCriteriaCompany
} from 'actions/case/find.actions';
import * as styles from 'components/criteria/criteria.styles';
import FontIcon from 'react-toolbox/lib/font_icon';
import criteriaActions from 'components/criteria/criteria.buttons.component';
import operatorsMap from 'components/criteria/operators';

class CompanyCriteriaSummary extends Component {

    constructor(props) {

        super(props);
        this.handleCancelAdd = this.handleCancelAdd.bind(this);
        this.handleSubmitAdd = this.handleSubmitAdd.bind(this);
    }

    handleSubmitAdd(values, id) {
        this.props.updateCriteria(values, id);
    }

    handleCancelAdd(id, isNew) {

        if (isNew) {
            this.props.deleteCriteria(id);
        }
        this.props.setActiveFormCriteria(0);

    }

    render() {

        const {item} = this.props;

        let disableButtons = false;
        if (this.props.activeFormCriteria) {
            disableButtons = this.props.activeFormCriteria > 0;
        }

        const ListItemContent = ({company, companyOperator}) => {

            return (
                <div className={styles.itemDescription + ' ' + styles.itemDescriptionWrapper}>
                    <div>A <em>company</em> whose name </div>
                    { <Chip>{operatorsMap[companyOperator] } <em> { company }</em></Chip>}
                </div>
            )

        };

        return (

            <div key={`emailItem_${item.id}`}>
                <div>
                    <ListItem
                        className={styles.avatar}
                        avatar={<FontIcon className={styles.customMaterialIcon} value='business'/>}
                        caption='Company'
                        itemContent={<ListItemContent {...item}/>}
                        rightActions={criteriaActions(item.id, disableButtons, this.props.deleteCriteria, this.props.setActiveFormCriteria)}
                        ripple={false}>
                    </ListItem>
                    <ListDivider />
                </div>
                <Row>
                    <Col md={11} mdOffset={1}>
                        <ReactCSSTransitionGroup transitionName="transitionfade" transitionEnterTimeout={300}
                                                 transitionLeaveTimeout={300}>

                            { this.props.activeFormCriteria === item.id &&


                            <Card className={styles.shadowDiv}>

                                <CompanyCriteriaForm
                                    initItem={item}
                                    isNew={item.isNew}
                                    onSubmit={this.handleSubmitAdd}
                                    onCancel={this.handleCancelAdd}
                                />

                            </Card>

                            }
                        </ReactCSSTransitionGroup>
                    </Col>
                </Row>
            </div>

        );

    }

}

const mapStateToProps = state => {
    return {
        results: state.casefind.results,
        preview: state.casefind.preview,
        criteria: state.casefind.criteria,
        activeFormCriteria: state.casefind.criteria.activeFormCriteria
    };
};

const mapDispatchToProps = dispatch => {
    return bindActionCreators({
        deleteCriteria: deleteCriteriaCompany,
        updateCriteria: updateCriteriaCompany,
        setActiveFormCriteria
    }, dispatch)
};

export default connect(mapStateToProps, mapDispatchToProps)(CompanyCriteriaSummary);