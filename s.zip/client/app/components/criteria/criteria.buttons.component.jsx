import React from 'react'
import {Button} from 'react-toolbox';

const criteriaActions = (actionId, disableButtons, deleteCriteria, setActiveFormCriteria) => {
    return ([

        <Button icon='delete' label='Delete' raised disabled={disableButtons} key={`delete-${actionId}`}
                onClick={() => {
                    deleteCriteria(actionId)
                }}
        />,
        <Button icon='mode_edit' label='Edit' raised  disabled={disableButtons} key={`edit-${actionId}`}
                onClick={() => {
                    setActiveFormCriteria(actionId)
                }}
        />

    ]);
};

export default criteriaActions;