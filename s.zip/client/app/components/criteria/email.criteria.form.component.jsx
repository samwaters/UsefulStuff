import React from 'react'
import {
    reduxForm,
    isSubmitting,
    getFormSyncErrors
} from 'redux-form'
import {connect} from 'react-redux'
import {Button} from 'react-toolbox/lib/button';
import {TextInputField, DropDownListField} from 'components/fields/MaterialUI.form.components';
import {Col, Row} from 'components/common/grid'
import * as styles from 'components/criteria/criteria.styles.scss'

let EmailCriteriaForm = (props) => {

    const {onSubmit, submitting, onCancel, handleSubmit, id, error, isNew} = props;

    const operators = [
        {value: '', label: ''},
        {value: 'equal', label: 'Equal To'},
        {value: 'start', label: 'Starts with'},
        {value: 'ends', label: 'Ends with'}
    ];

    let submitButtonLabel = 'Update';
    if (isNew) {
        submitButtonLabel = 'Add';
    }

    return (
        <form onSubmit={handleSubmit(values => {
            onSubmit(values, id);
        })}>
            <Row>
                <Col md={12}>
                    <strong>{error && error}</strong>
                </Col>
            </Row>
            <Row>
                <Col md={3}>
                    <div className={styles.criteriaItemHeading}>Email Address</div>
                </Col>
                <Col md={2}>
                    <DropDownListField name="emailOperator" label="Operator" source={operators}/>
                </Col>
                <Col md={3}>
                    <TextInputField name="email" label="value" required/>
                </Col>

                <Col md={4}>
                    <div className={styles.buttonContainer}>
                        <Button type="submit" label={submitButtonLabel} disabled={submitting} raised primary/>
                        <Button type="button" label='Cancel' onClick={() => onCancel(id, isNew)} raised accent/>
                    </div>
                </Col>
            </Row>
        </form>
    );

};

EmailCriteriaForm.propTypes = {
    handleSubmit: React.PropTypes.func.isRequired,
    onCancel: React.PropTypes.func.isRequired,
    id: React.PropTypes.number.isRequired,
    isNew: React.PropTypes.bool.isRequired
};

const hasValue = (field) => {
    return field && field.length > 0
};


const validateOperatorFieldValue = (errors, fieldname, operatorField, valueField) => {

    const hasOperator = hasValue(operatorField);
    const hasFieldValue = hasValue(valueField);

    if (hasOperator && !hasFieldValue) {
        errors[fieldname] = "required";
    }

    if (!hasOperator && hasFieldValue) {
        errors[`${fieldname}Operator`] = "required";
    }

};

const fieldLevelValidation = (values) => {

    const errors = {};
    validateOperatorFieldValue(errors, 'email', values.emailOperator, values.number);
    return errors;

};

const formName = 'addEmailCriteriaForm';

EmailCriteriaForm = reduxForm({
    form: formName,
    fieldLevelValidation
})(EmailCriteriaForm);

const mapStateToProps = (state, ownProps) => {

    let props = {
        errors: getFormSyncErrors(formName)(state),
        submitting: isSubmitting(formName)(state),
        initialValues: {}
    };

    if (ownProps.initItem) {
        props = {...props, id: ownProps.initItem.id, initialValues: ownProps.initItem};
    }

    return props;

};


export default EmailCriteriaForm = connect(mapStateToProps)(EmailCriteriaForm);