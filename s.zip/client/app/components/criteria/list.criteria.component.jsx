import React, {Component} from 'react';
import {Table, TableHead, TableRow, TableCell} from 'react-toolbox/lib/table';

const data = [
    {field: 'Address Line 1', operator: 'EQUAL', value: '28 Dingwall'},
    {field: 'Address Line 1', operator: 'EQUAL', value: '28 Dingwall'},
    {field: 'Address Line 1', operator: 'EQUAL', value: '28 Dingwall'},
    {field: 'Address Line 1', operator: 'EQUAL', value: '28 Dingwall'}
];

class CriteriaList extends Component {

    constructor() {
        super();
    }

    render() {
        return (
            <section>
                <Table style={{marginTop: 10}} selectable={false}>
                    <TableHead>
                        <TableCell>Item</TableCell>
                        <TableCell>Match</TableCell>
                        <TableCell>Value</TableCell>
                        <TableCell></TableCell>
                    </TableHead>
                    {data.map((item, idx) => (
                        <TableRow key={idx}>
                            <TableCell>{item.field}</TableCell>
                            <TableCell>{item.operator}</TableCell>
                            <TableCell>{item.value}</TableCell>
                            <TableCell></TableCell>
                        </TableRow>
                    ))}
                </Table>
            </section>
        );
    }
}

export default CriteriaList;

