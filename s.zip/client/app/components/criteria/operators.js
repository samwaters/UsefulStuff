const operatorsMap = {
    'equal': 'is',
    'start': 'starts with',
    'ends': 'ends with'
};

export default operatorsMap;