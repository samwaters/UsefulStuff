import React from 'react'
import {
    reduxForm,
    isSubmitting,
    getFormSyncErrors
} from 'redux-form'
import {connect} from 'react-redux'
import {Button} from 'react-toolbox/lib/button';
import {TextInputField, DropDownListField} from 'components/fields/MaterialUI.form.components';
import {Col, Row} from 'components/common/grid'
import * as styles from 'components/criteria/criteria.styles.scss'

let VehicleCriteriaForm = (props) => {

    const {onSubmit, submitting, onCancel, handleSubmit, id, error, isNew} = props;

    const operators = [
        {value: '', label: ''},
        {value: 'equal', label: 'Equal To'},
        {value: 'start', label: 'Starts with'},
        {value: 'ends', label: 'Ends with'}
    ];

    let submitButtonLabel = 'Update';
    if (isNew) {
        submitButtonLabel = 'Add';
    }

    return (
        <form onSubmit={handleSubmit(values => {
            onSubmit(values, id);
        })}>
            <Row>
                <Col md={12}>
                    <strong>{error && error}</strong>
                </Col>
            </Row>
            <Row>
                <Col md={3}>
                    <div className={styles.criteriaItemHeading}>Registration</div>
                </Col>
                <Col md={2}>
                    <DropDownListField name="registrationOperator" label="Operator" source={operators}/>
                </Col>
                <Col md={3}>
                    <TextInputField name="registration" label="value" required/>
                </Col>
            </Row>
            <Row>
                <Col md={3}>
                    <div className={styles.criteriaItemHeading}>Make</div>
                </Col>
                <Col md={2}>
                    <DropDownListField name="makeOperator" label="Operator" source={operators}/>
                </Col>
                <Col md={3}>
                    <TextInputField name="make" label="value" required/>
                </Col>
            </Row>
            <Row>
                <Col md={3}>
                    <div className={styles.criteriaItemHeading}>Model</div>
                </Col>
                <Col md={2}>
                    <DropDownListField name="modelOperator" label="Operator" source={operators}/>
                </Col>
                <Col md={3}>
                    <TextInputField name="model" label="value" required/>
                </Col>

                <Col md={4}>
                    <div className={styles.buttonContainer}>
                        <Button type="submit" label={submitButtonLabel} disabled={submitting} raised primary/>
                        <Button type="button" label='Cancel' onClick={() => onCancel(id, isNew)} raised accent/>
                    </div>
                </Col>
            </Row>
        </form>
    );

};

VehicleCriteriaForm.propTypes = {
    handleSubmit: React.PropTypes.func.isRequired,
    onCancel: React.PropTypes.func.isRequired,
    id: React.PropTypes.number.isRequired,
    isNew: React.PropTypes.bool.isRequired
};

const hasValue = (field) => {
    return field && field.length > 0
};


const validateOperatorFieldValue = (errors, fieldname, operatorField, valueField) => {

    const hasOperator = hasValue(operatorField);
    const hasFieldValue = hasValue(valueField);

    if (hasOperator && !hasFieldValue) {
        errors[fieldname] = "required";
    }

    if (!hasOperator && hasFieldValue) {
        errors[`${fieldname}Operator`] = "required";
    }

};

const fieldLevelValidation = (values) => {

    const errors = {};
    validateOperatorFieldValue(errors, 'registration', values.registrationOperator, values.number);
    return errors;

};

const formName = 'addVehicleCriteriaForm';

VehicleCriteriaForm = reduxForm({
    form: formName,
    fieldLevelValidation
})(VehicleCriteriaForm);

const mapStateToProps = (state, ownProps) => {

    let props = {
        errors: getFormSyncErrors(formName)(state),
        submitting: isSubmitting(formName)(state),
        initialValues: {}
    };

    if (ownProps.initItem) {
        props = {...props, id: ownProps.initItem.id, initialValues: ownProps.initItem};
    }

    return props;

};


export default VehicleCriteriaForm = connect(mapStateToProps)(VehicleCriteriaForm);