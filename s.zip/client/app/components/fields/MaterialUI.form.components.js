import React from 'react';
import Input from 'react-toolbox/lib/input';
import Dropdown from 'react-toolbox/lib/dropdown';
import {Field} from 'redux-form'
import DatePicker from 'react-toolbox/lib/date_picker';

/**
 * Components to wrap react-toolbox components in redux-form controls.
 */
export const TextInputField = (props) => {
    return (
        <Field  {...props} component={ reactToolBoxInput  }/>
    )
};

const reactToolBoxInput = ({input, type, icon, label, multiline, meta: {touched, error, warning}}) => {

    return (
        <div>
            <Input {...input} type={type} label={label} multiline={multiline} icon={icon}
                   error={touched ? ((error && `${error}`) || (warning && `${warning}`)) : ''}
            />
        </div>
    )
};


export const DropDownListField = (props) => {
    return (
        <Field  {...props} component={ reactToolBoxDDL  }/>
    )
};

const reactToolBoxDDL = ({source, input, label, meta: {touched, error, warning}}) => {

    return (
        <div>
            <Dropdown
                {...input}
                label={label}
                source={source}
                error={touched ? ((error && `${error}`) || (warning && `${warning}`)) : ''}
            />
        </div>
    )
};


export const DataPickerField = (props) => {
    return (
        <Field  {...props} component={ reactToolBoxDatePicker  }/>
    )
};


const reactToolBoxDatePicker = ({input, label}) => {

    return (
        <div>
            <DatePicker
                {...input}
                label={label}
                sundayFirstDayOfWeek
            />
        </div>
    )
};

