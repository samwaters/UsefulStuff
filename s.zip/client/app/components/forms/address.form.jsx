import React from 'react'
import {Col, Row} from 'components/common/grid'
import {TextInputField} from 'components/fields/MaterialUI.form.components';

import SimpleFormRenderer, {validateMandatoryFields} from 'components/forms/simple.form.component.jsx';

const formDef = {
    formName: 'addressForm',
    fields: [
        {name: 'housenumber', label: 'House Name/Number', type: 'input', required: true},
        {name: 'line1', label: 'Line 1', type: 'input', required: true},
        {name: 'line2', label: 'Line 2', type: 'input', required: true},
        {name: 'line3', label: 'Line 3', type: 'input', required: false},
        {name: 'line4', label: 'Line 4', type: 'input', required: false},
        {name: 'line5', label: 'Line 5', type: 'input', required: false},
        {name: 'line6', label: 'Line 6', type: 'input', required: false},
        {name: 'postcode1', required: true, render: false},
        {name: 'postcode2', required: true, render: false}],
    validate: (values) => {
        return validateMandatoryFields(formDef.fields, values, {});
    }
};

let AddressForm = (props) => {
    return (
        <SimpleFormRenderer {...props} formDef={formDef}>

            <Row>
                <Col md={6}>
                    <TextInputField name="postcode1" label="Postcode1" required/>
                </Col>
                <Col md={6}>
                    <TextInputField name="postcode2" label="Postcode2" required/>
                </Col>
            </Row>

        </SimpleFormRenderer>
    )
};

export default AddressForm;