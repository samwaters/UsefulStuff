import React from 'react';
import {connect} from 'react-redux';
import {Dropdown, Input} from 'react-toolbox';
import * as actions from 'actions/case/add.actions';

class CaseDetailsForm extends React.Component {
	constructor() {
		super();
		this.state = {
			errors: {
				identifier: '',
				source: '',
				nim: '',
				document: '',
				notes: ''
			},
			touched: {
				identifier: false,
				source: false,
				nim: false,
				document: false,
				notes: false
			},
			identifier: '',
			source: '',
			nim: '',
			document: '',
			notes: ''
		};
	}

	broadcast() {
		let errors = {};
		errors.identifier = this.state.touched.identifier && this.state.identifier.length < 3 ? 'required' : '';
		errors.source = this.state.touched.source && this.state.source.length < 1 ? 'required' : '';
		errors.nim = this.state.touched.nim && this.state.nim.length < 1 ? 'required' : '';
		this.setState({errors: errors});
		this.props.setCaseDetails(
			this.state.identifier,
			this.state.source,
			this.state.nim,
			this.state.document,
			this.state.notes
		);
	}

	handleFieldChange(field, value) {
		this.setState({[field]: value});
	}

	render() {
		return <div>
			<Input
				error={this.state.errors.identifier}
				label="Case Identifier"
				onBlur={() => this.broadcast()}
				onChange={v => this.handleFieldChange('identifier', v)}
				onFocus={() => this.touch('identifier')}
				required
				type="text"
				value={this.state.identifier}
			/>
			<Dropdown
				error={this.state.errors.source}
				label="Source"
				onBlur={() => this.broadcast()}
				onChange={v => this.handleFieldChange('source', v)}
				onFocus={() => this.touch('source')}
				required
				source={[
					{label:'IFB', value:'ifb'},
					{label:'Phone', value:'phone'},
					{label:'SIRA', value:'sira'},
					{label:'Other', value:'other'}
				]}
				value={this.state.source}
			/>
			<Dropdown
				error={this.state.errors.nim}
				label="NIM Level"
				onBlur={() => this.broadcast()}
				onChange={v => this.handleFieldChange('nim', v)}
				onFocus={() => this.touch('nim')}
				required
				source={[
					{label:'None', value:'0'},
					{label:'Level 1', value:'1'},
					{label:'Level 3', value:'3'},
					{label:'Level 5', value:'5'},
					{label:'Level 10', value:'10'}
				]}
				value={this.state.nim}
			/>
			<Input
				error={this.state.errors.document}
				label="Document Link"
				onBlur={() => this.broadcast()}
				onChange={v => this.handleFieldChange('document', v)}
				onFocus={() => this.touch('document')}
				type="text"
				value={this.state.document}
			/>
			<Input
				error={this.state.errors.notes}
				label="Case Notes"
				multiline
				onBlur={() => this.broadcast()}
				onChange={v => this.handleFieldChange('notes', v)}
				onFocus={() => this.touch('notes')}
				type="text"
				value={this.state.notes}
			/>
		</div>
	}

	touch(field) {
		this.setState({
			...this.state,
			touched: {
				...this.state.touched,
				[field]: true
			}
		})
	}
}


const CaseDetailsFormComponent = connect(
	() => {
		return {}
	},
	dispatch => {
		return {
			setCaseDetails: (identifier, source, nim, document, notes) => dispatch(actions.setCaseDetails({
				identifier: identifier,
				source: source,
				nim: nim,
				document: document,
				notes: notes
			}))
		}
	}
)(CaseDetailsForm);

export default CaseDetailsFormComponent;