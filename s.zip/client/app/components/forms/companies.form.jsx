import React from 'react'
import SimpleFormRenderer, {validateMandatoryFields} from 'components/forms/simple.form.component.jsx';

const formDef = {
    formName: 'companiesForm',
    fields: [
        {name: 'value', label: 'Company Name', type: 'input', required: true}
    ],
    validate: (values) => {
        return validateMandatoryFields(formDef.fields, values, {});
    }
};

let CompanyForm = (props) => {
    return (
        <SimpleFormRenderer {...props} formDef={formDef}/>
    )
};

export default CompanyForm;