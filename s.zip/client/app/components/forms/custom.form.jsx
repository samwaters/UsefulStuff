import React from 'react'
import SimpleFormRenderer, {validateMandatoryFields} from 'components/forms/simple.form.component.jsx';

import {TextInputField, DropDownListField} from 'components/fields/MaterialUI.form.components';
import {Col, Row} from 'components/common/grid'

const validate = (values) => {

    const errors = {};
    if (!values.value || values.value.length < 1) {
        errors.title = "required";
    }
    return errors;

};


const formDef = {
    formName: 'customForm',
    fields: [
        {name: 'type', required: true, render: false},
        {name: 'value', required: true, render: false}],
    validate
};

let CustomForm = (props) => {

    return (
        <SimpleFormRenderer {...props} formDef={formDef}>

            <Row>
                <Col md={6}>
                    <DropDownListField name="type" label="Item" source={[
                        {value: 'NIN', label: 'National Insurance Number'},
                        {value: 'MPL', label: 'Motor policy'},
                        {value: 'HPL', label: 'H/hold policy'},
                        {value: 'PAS', label: 'Passport'},
                        {value: 'DLC', label: 'Driving licence'}
                    ]} required/>
                </Col>
                <Col md={6}>
                    <TextInputField name="value" label="Value" required/>
                </Col>
            </Row>

        </SimpleFormRenderer>
    )

};

export default CustomForm;

