import React from 'react'
import SimpleFormRenderer, {validateMandatoryFields} from 'components/forms/simple.form.component.jsx';

const formDef = {
    formName: 'emailForm',
    fields: [
        {name: 'value', label: 'Email Address', icon: 'email', type: 'email', required: true}
    ],
    validate: (values) => {
        return validateMandatoryFields(formDef.fields, values, {});
    }
};

let EmailForm = (props) => {
    return (
        <SimpleFormRenderer {...props} formDef={formDef}>
            {props.children}
        </SimpleFormRenderer>
    )
};

export default EmailForm;