import React from 'react';
import {Row, Col} from 'components/common/grid';
import {Button, DatePicker, Dropdown, Input} from 'react-toolbox';

class FormComponent extends React.Component {
	constructor() {
		super();
		this.state = {
			formErrors: {},
			formValues: {}
		}
	}

	handleFormSubmit() {

	}

	handleFormValueChange(field, value) {
		this.setState({
			...this.state.formErrors,
			formValues: {...this.state.formValues, [field]: value}
		});
	}

	/*
	  <FormComponent
	  	formDef={[
	  	[{label:'First Name' name:'fname' size:6, type:'text'},{label:'Last Name' name:'lname' size:6, type:'text'}],
	 	[{label:'Notes' multiline={true} name:'notes' size:12, type:'text'}]
	  	]}
	  />
	 */
	render() {
		let form = [];
		this.props.formDef.forEach(row => {
			let cols = [];
			row.forEach(col => {
				let fields = [];
				switch(col.type) {
					case 'date':
						fields.push(<DatePicker
							error={this.state.formErrors[col.name]}
							label={col.label}
							onChange={v => this.handleFormValueChange(col.name, v)}
							value={this.state.formValues[col.name]}
						/>);
						break;
					case 'dropdown':
						fields.push(
							<Dropdown
								error={this.state.formErrors[col.name]}
								icon={col.icon}
								label={col.label}
								onChange={v => this.handleFormValueChange(col.name, v)}
								source={col.options}
								value={this.state.formValues[col.name]}
							/>
						);
						break;
					case 'text':
						fields.push(<Input
							error={this.state.formErrors[col.name]}
							icon={col.icon}
							label={col.label}
							multiline={col.multiline}
							onChange={v => this.handleFormValueChange(col.name, v)}
							type="text"
							value={this.state.formValues[col.name]}
						/>);
						break;
				}
				cols.push(<Col md={col.size}>{fields}</Col>)
			});
			form.push(<Row>{cols}</Row>)
		});

		return <form onSubmit={this.handleFormSubmit}>
			{form}
			<Row>
				<Col md={3} mdOffset={9}>
					{
						this.props.onCancel && <Button accent onClick={() => this.props.onCancel} raised>Cancel</Button>
					}
					<Button onClick={() => this.handleFormSubmit()} primary raised>Submit</Button>
				</Col>
			</Row>
		</form>
	}
}

FormComponent.propTypes = {
	formDef: React.PropTypes.array.isRequired,
	onCancel: React.PropTypes.func,
	onError: React.PropTypes.func,
	onSubmit: React.PropTypes.func.isRequired
};

export default FormComponent;