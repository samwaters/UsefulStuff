import React from 'react'
import {TextInputField, DropDownListField, DataPickerField} from 'components/fields/MaterialUI.form.components';
import {Link} from 'react-router';
import {Col, Row} from 'components/common/grid'
import SimpleFormRenderer, {validateMandatoryFields} from 'components/forms/simple.form.component.jsx';


const validate = (values) => {

    const errors = {};

    if (!values.firstName || values.firstName.length < 3) {
        errors.firstName = "required";
    }

    if (!values.title || values.title.length < 1) {
        errors.title = "required";
    }

    return errors;

};

const formDef = {
    formName: 'personForm',
    fields: [
        {name: 'firstName', required: true, render: false},
        {name: 'lastName', required: true, render: false},
        {name: 'dateOfBirth', required: true, render: false},
        {name: 'sensitivity', required: true, render: false},
        {name: 'riskRating', required: true, render: false},
        {name: 'active', required: true, render: false}
    ],
    validate
};


let PersonForm = (props) => {

    return (
        <SimpleFormRenderer {...props} formDef={formDef}>
            <Row>
                <Col md={4}>
                    <DropDownListField name="title" label="Title" source={[
                        {value: '001', label: 'Mr'},
                        {value: '002', label: 'Mrs'}
                    ]} required/>
                </Col>
                <Col md={8}>
                    <TextInputField name="firstName" label="First Name" required/>
                </Col>
            </Row>
            <Row>
                <Col md={8}>
                    <TextInputField name="lastName" label="Last Name" required/>
                </Col>
                <Col md={4}>
                    <DataPickerField name="dateOfBirth" label="Date of Birth" required/>
                </Col>
            </Row>

            <Row>
                <Col md={3}>
                    <TextInputField name="sensitivity" label="Sensitivity" required/>
                </Col>
                <Col md={3}>
                    <TextInputField name="riskRating" label="Risk Rating" required/>
                </Col>
                <Col md={3}>
                    <TextInputField name="active" label="Active" required/>
                </Col>
            </Row>

            <p>The person is potentially already on the Market Database, linked to the following case</p>
            <ul>
                <li><Link to="/case/123" target="_blank">Case #123 - Bob Smith</Link></li>
            </ul>

        </SimpleFormRenderer>
    )

};

export default PersonForm

