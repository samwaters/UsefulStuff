import React from 'react'
import SimpleFormRenderer, {validateMandatoryFields} from 'components/forms/simple.form.component.jsx';

const formDef = {
    formName: 'phoneForm',
    fields: [
        {name: 'value', label: 'Number', type: 'tel', icon: 'phone', required: true}
    ],
    validate: (values) => {
        return validateMandatoryFields(formDef.fields, values, {});
    }
};

let PhoneForm = (props) => {
    return (
        <SimpleFormRenderer {...props} formDef={formDef}/>
    )
};

export default PhoneForm;
