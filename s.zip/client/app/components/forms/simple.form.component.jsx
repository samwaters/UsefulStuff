import React from 'react'
import {reduxForm} from 'redux-form'
import {connect} from 'react-redux'
import {Button} from 'react-toolbox/lib/button';
import {TextInputField} from 'components/fields/MaterialUI.form.components';
import {Col, Row} from 'components/common/grid'
import * as styles from 'components/forms/forms.styles';

const SimpleFormRenderer = (props) => {

    const {id, onSubmit, onCancel, handleSubmit, error, formDef} = props;

    const renderField = (fieldProps, idx) => {

        if (fieldProps.render === false) return;

        return (
            <Row key={idx}>
                <Col md={12}>
                    <TextInputField {...fieldProps} />
                </Col>
            </Row>
        )
    };

    return (
        <form onSubmit={handleSubmit(onSubmit)}>
            {error && <strong>{error}</strong>}

            {formDef.fields.map((fieldProps, idx) => renderField(fieldProps, idx))}

            { props.children }

            <div className={styles.buttonContainer}>
                <Button accent label='Cancel' onClick={onCancel} raised/>

                {id ? <Button type="submit" label='Update' primary raised/> :
                    <Button type="submit" label='Add' primary raised/>}

            </div>

        </form>
    )
};

// export const reduxFormFieldMapping = (fields, returnProps, selector, state) => {
//     fields.map((field) => {
//         returnProps = {...returnProps, [field.name]: selector(state, field.name)}
//     });
//     return returnProps;
// };

export const validateMandatoryFields = (fields, values, errors) => {

    fields.map((field) => {
        if (field.required && (!values[field.name] || values[field.name].length === 0)) {
            errors[field.name] = "required";
        }
    });
    return errors;

};

const mapStateToProps = (state, ownProps) => {

    let props = {
        initialValues: {},
        form: ownProps.formDef.formName,
        validate: ownProps.formDef.validate
    };
    if (ownProps.initItem) {
        props = {...props, id: ownProps.initItem.id, initialValues: ownProps.initItem}
    }
    return props;

};

export default connect(mapStateToProps)(reduxForm()(SimpleFormRenderer));

