import React from 'react'
import SimpleFormRenderer, {validateMandatoryFields} from 'components/forms/simple.form.component.jsx';

const formDef = {
    formName: 'vehicleForm',
    fields: [
        {name: 'value', label: 'Registration', type: 'input', required: true},
        {name: 'make', label: 'Make', type: 'input', required: false},
        {name: 'model', label: 'Model', type: 'input', required: false},
    ],
    validate: (values) => {
        return validateMandatoryFields(formDef.fields, values, {});
    }
};

let VehicleForm = (props) => <SimpleFormRenderer {...props} formDef={formDef}/>;

export default VehicleForm;