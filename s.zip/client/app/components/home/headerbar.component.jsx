import React, {Component} from "react";
import {AppBar, Tab, Tabs} from 'react-toolbox';
import {hashHistory} from 'react-router';
import logo from 'images/ageas_logo.png';
import {connect} from 'react-redux';
import {updateNavigationTab} from 'actions/home/headerbar.actions';
import {bindActionCreators} from "redux";
import * as styles from 'components/home/headerbar.styles';

class HeaderBar extends Component {

    constructor() {

        super();
        this.state = {
            activeTabIndex: 99
        };
        this.setActiveTabIndex = this.setActiveTabIndex.bind(this);
        this.setHome = this.setHome.bind(this);

    }

    setActiveTabIndex(activeTabIndex) {
        this.props.updateNavigationTab(activeTabIndex);
    }

    setHome() {
        this.setActiveTabIndex(99);
        hashHistory.push('home');
    }


    render() {

        const LogoImage = () => (
            <img src={logo} style={{width: '50px', height: '50px', marginTop: '1px', backgroundColor: '#fff'}}/>
        );
        const hasReviewCaseLoaded = !this.props.reviewcaseId;
        return (

            <AppBar
                className={styles.appBar}
                leftIcon={<LogoImage/>}
                title="Market Database"
                onLeftIconClick={ this.setHome }
                theme={{title:styles.appBarTitle}}
            >
                <section>
                    <Tabs
                        className={styles.appbarTabs}
                        theme={{
                            active:styles.barActive,
                            navigation:styles.navigation,
                            pointer:styles.pointer,
                            tabs:styles.tabs,
                            label:styles.label
                        }}
                        index={this.props.activetab}
                        onChange={ this.setActiveTabIndex } fixed>
                        <Tab label='Find&nbsp;Case' onClick={ () => hashHistory.push('find') }>
                        </Tab>
                        <Tab label='View&nbsp;Case' onClick={ () => hashHistory.push('case/9161/view') } disabled={hasReviewCaseLoaded}>
                        </Tab>
                        <Tab label='Add&nbsp;Case' onClick={ () => hashHistory.push('add') }>
                        </Tab>
                        <Tab label='Import' onClick={ () => hashHistory.push('import') }>
                        </Tab>
                    </Tabs>
                </section>
            </AppBar>

        )
    }
}

const mapDispatchToProps = dispatch => {
    return bindActionCreators({updateNavigationTab}, dispatch)
};

const mapStateToProps = state => {
    return {
        activetab: state.navigation.activetab,
        reviewcaseId: state.casereview.id
    }

};

export default connect(mapStateToProps, mapDispatchToProps)(HeaderBar);
