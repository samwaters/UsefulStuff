import React from 'react';
import Splash from 'images/splash.png';
import * as styles from 'components/home/home.styles';

class Home extends React.Component {

    constructor() {
        super();
    }

    render() {

        return (
            <div>

                <div>
                    <div className={styles.splash}>
                        <img src={Splash} style={{height: '350px', width: '490px'}}/>
                    </div>
                    <h1 style={{textAlign: 'center'}}><i>"Dynamically eradicating<br/> misrepresentation in
                        insurance"</i>
                    </h1>
                </div>

            </div>
        )
    }
}

export default Home;