import React from 'react';
import {Table, TableHead, TableRow, TableCell} from 'react-toolbox/lib/table';
import {ListButtons} from 'components/lists/list.component';

export default (props) => {

    const {items, onEditItem, onDeleteItem} = props;

    const renderTable = (items) => {

        return (
            <Table style={{marginTop: 10}} selectable={false}>
                <TableHead>
                    <TableCell>House Name/Number</TableCell>
                    <TableCell>Address</TableCell>
                    <TableCell>Postcode</TableCell>
                    <TableCell>&nbsp;</TableCell>
                </TableHead>
                {items.map((item, idx) => (
                    <TableRow key={idx}>
                        <TableCell>{item.housenumber}</TableCell>
                        <TableCell>{item.line1}, {item.line2}, {item.line3}, {item.line4}, {item.line5}, {item.line6}</TableCell>
                        <TableCell>{item.postcode1} {item.postcode2}</TableCell>
                        <ListButtons
                            onEditItem={onEditItem}
                            onDeleteItem={onDeleteItem}
                            item={item}
                            showEdit={true}
                            showDelete={true}
                            render={true}
                        />
                    </TableRow>
                ))}
            </Table>
        )
    };

    return (
        <div>
            { items.length ? renderTable(items) : <span>None</span>}
        </div>
    )
}


