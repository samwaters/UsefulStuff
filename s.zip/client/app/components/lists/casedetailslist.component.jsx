import React from 'react';
import {connect} from 'react-redux';
import EditableTableComponent from 'components/common/editabletable.component';
import {Error} from 'components/common/messages';
import * as editActions from 'actions/case/edit.actions';

class CaseDetailsList extends React.Component {
	constructor() {
		super();
		this.state = {}
	}

	handleRowEdit(field, value) {
		this.props.update(this.props.items.id, field, value, this.props.editreason);
	}

	render() {
		return <div>
			{this.props.error && <Error>{this.props.error}</Error>}
			<EditableTableComponent
				editable={this.props.editable}
				onEdit={() => this.setState({editing: true})}
				onSave={(f,v) => this.handleRowEdit(f, v)}
				rows={[
					{id: 'caseid', label: 'Case Reference', type: 'text', value: this.props.items.caseid},
					{
						id: 'source',
						label: 'Source',
						options: [
							{label: 'IFB', value:'ifb'},
							{label: 'SIRA', value:'sira'},
							{label: 'Phone', value:'phone'},
							{label: 'E-Mail', value:'email'}
						],
						type: 'dropdown',
						value: this.props.items.source
					},
					{
						id: 'nim',
						label: 'NIM Level',
						options: [
							{label: 'Level 1', value:1},
							{label: 'Level 3', value:3},
							{label: 'Level 5', value:5},
							{label: 'Level 10', value:10}
						],
						type: 'dropdown',
						value: this.props.items.nim
					},
					{id: 'document', label: 'Original Document', type: 'text', value: this.props.items.document},
					{id: 'notes', label: 'Notes', type: 'textarea', value: this.props.items.notes},
				]}
				saving={this.props.saving}
			/>
		</div>
	}
}

CaseDetailsList.propTypes = {
	editable: React.PropTypes.bool,
	editreason: React.PropTypes.string,
	items: React.PropTypes.object.isRequired
};

const CaseDetailsListComponent = connect(
	state => {
		return {
			error: state.caseedit.error,
			saving: state.caseedit.saving
		}
	},
	dispatch => {
		return {
			update: (caseid, field, value, reason) => dispatch(editActions.updateCaseDetails(caseid, field, value, reason))
		}
	}
)(CaseDetailsList);

export default CaseDetailsListComponent;