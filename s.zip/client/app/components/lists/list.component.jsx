import React from 'react';
import * as styles from 'components/lists/list.styles';
import {TableCell} from 'react-toolbox/lib/table';
import {Button} from 'react-toolbox';

export const ListButtons = props => {

	return props.render ? <TableCell className={styles.buttonColumn}>
		{
			props.showEdit && <Button onClick={() => props.onEditItem(props.item)} icon='edit' label='Edit' flat primary/>
		}
		{
			props.showDelete && <Button onClick={() => props.onDeleteItem(props.item)} icon='delete' label='Delete' flat primary/>
		}
	</TableCell> : <TableCell/>
};
