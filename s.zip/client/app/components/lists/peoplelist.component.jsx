import React from 'react';
import {Dialog, Table, TableHead, TableRow, TableCell} from 'react-toolbox';
import PersonForm from 'components/forms/person.form';
import {ListButtons} from 'components/lists/list.component';

class PeopleListComponent extends React.Component {
	constructor() {
		super();
		this.state = {
			editModalActive: false
		}
	}

	handleEditItem() {

	}

	render() {
		return <div>
			<Table style={{marginTop: 10}} selectable={false}>
				<TableHead>
					<TableCell>Title</TableCell>
					<TableCell>First Name</TableCell>
					<TableCell>Last Name</TableCell>
					<TableCell>&nbsp;</TableCell>
				</TableHead>
				{
					this.props.items.length === 0 && <TableRow><TableCell>None</TableCell></TableRow>
				}
				{
					this.props.items.length > 0 && this.props.items.map((item, idx) => (
						<TableRow key={idx}>
							<TableCell>{item.title}</TableCell>
							<TableCell>{item.firstName}</TableCell>
							<TableCell>{item.lastName}</TableCell>
							<ListButtons
								item={item}
								onDeleteItem={this.props.onDeleteItem}
								onEditItem={this.toggleEditModal}
								render={this.props.editable}
								showDelete
								showEdit
							/>
						</TableRow>
					))
				}
			</Table>
			<Dialog
				actions={[
					{label:'Cancel', onClick:this.toggleEditModal},
					{label:'Save', onClick:this.handleEditItem}
				]}
				active={this.state.editModalActive}
				onEscKeyDown={this.toggleEditModal}
				onOverlayClick={this.toggleEditModal}
				title="Edit"
			>
				<PersonForm
					id={this.state.editId}
					onSubmit="''"
					onCancel=""
					handleSubmit=""
					error
				/>
			</Dialog>
		</div>
	}

	toggleEditModal() {
		this.setState({
			editModalActive: !this.state.editModalActive
		});
	}
}

PeopleListComponent.propTypes = {
	editable: React.PropTypes.bool.isRequired,
	items: React.PropTypes.array.isRequired,
	onDeleteItem: React.PropTypes.func,
};

export default PeopleListComponent;
