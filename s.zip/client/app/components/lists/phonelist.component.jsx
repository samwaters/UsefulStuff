import React from 'react';
import {Table, TableHead, TableRow, TableCell} from 'react-toolbox/lib/table';
import {ListButtons} from 'components/lists/list.component';

export default (props) => {

    const {items, onEditItem, onDeleteItem} = props;

    const renderTable = (items) => {

        return (
            <Table style={{marginTop: 10}} selectable={false}>
                <TableHead>
                    <TableCell>Number</TableCell>
                    <TableCell>&nbsp;</TableCell>
                </TableHead>
                {items.map((item, idx) => (
                    <TableRow key={idx}>
                        <TableCell>{item.value || 'Not Provided'}</TableCell>
                        <ListButtons
                            onEditItem={onEditItem}
                            onDeleteItem={onDeleteItem}
                            item={item}
                            showEdit={true}
                            showDelete={true}
                            render={true}
                        />
                    </TableRow>
                ))}
            </Table>
        )
    };

    return (
        <div>
            { items.length ? renderTable(items) : <span>None</span>}
        </div>
    )
}


