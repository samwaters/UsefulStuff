import React from 'react';
import {connect} from 'react-redux';
import {AppBar, Button, Card, CardTitle, CardText, Input} from 'react-toolbox';
import {Error} from 'components/common/messages';
import {Row, Col} from 'components/common/grid';
import * as authActions from 'actions/auth/auth.actions';
import * as styles from 'components/login/login.styles.scss';

class Login extends React.Component {
	constructor() {
		super();
		this.state = {
			password: '',
			username: '',
			redirect: '/home'
		}
	}

	componentDidMount() {
		let redirect = '/home';
		if(this.props.location.query.returnTo) {
			// Need a local copy of this since setState happens async and we need it below
			redirect = this.props.location.query.returnTo;
			this.setState({redirect: this.props.location.query.returnTo});
		}
		if(/(^|;\s?)mkdbToken=/.test(document.cookie) && /(^|;\s?)mkdbUsername=/.test(document.cookie)) {
			// Got a token and username, grab the username value
			let usernameCookie = document.cookie.match(/(^|;\s?)mkdbUsername=([^;]+)/);
			if(usernameCookie && usernameCookie.length === 3) {
				let username = decodeURIComponent(usernameCookie[2]);
				this.props.verify(username, redirect);
			}
		}
	}

	handleChange(field, value) {
		this.setState({[field]: value});
	}

	render() {
		return <div>
			<AppBar title="Market Database" />
			<Row>
				<Col xs={12} md={6} mdOffset={3}>
					<Card style={{marginTop:'10px'}}>
						<CardTitle title="Log In" />
						<CardText>
							{
								this.props.error !== '' && <Error>{this.props.error}</Error>
							}
							<Input
								label="Username"
								onChange={v => this.handleChange('username', v)}
								type="text"
								value={this.state.username}
							/>
							<Input
								label="Password"
								onChange={v => this.handleChange('password', v)}
								type="password"
								value={this.state.password}
							/>
							<p className={styles.center}>
								<Button
									disabled={this.props.loggingIn}
									onClick={() => this.props.login(this.state.username, this.state.password, this.state.redirect)}
									primary raised
								>Log In</Button>
							</p>
							<p className={styles.footer}>
								Note: The login process uses your iSeries credentials for validation. Repeated failed login attempts may lock your account.
							</p>
						</CardText>
					</Card>
				</Col>
			</Row>
		</div>
	}
}

const LoginComponent = connect(
	state => {
		return {
			error: state.auth.error,
			loggingIn: state.auth.loggingIn
		}
	},
	dispatch => {
		return {
			login: (username, password, redirect) => dispatch(authActions.login(username, password, redirect)),
			verify: (username, redirect) => dispatch(authActions.verify(username, redirect))
		}
	}
)(Login);

export default LoginComponent;