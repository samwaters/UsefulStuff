import {ACTIONS} from '../../actions/auth/auth.actions';
const initialState = {
	authority: {
		edit: 0,
		view: 0
	},
	error: '',
	loggedIn: false,
	loggingIn: false,
	token: ''
};

const authReducer = (state = initialState, action) => {
	let mutatedState = Object.assign({}, state);
	switch(action.type) {
		case ACTIONS.LOGIN:
		case ACTIONS.VERIFY:
			mutatedState.error = '';
			mutatedState.loggingIn = true;
			return mutatedState;
		case ACTIONS.LOGIN_COMPLETE:
		case ACTIONS.VERIFY_COMPLETE:
			mutatedState.authority.edit = action.payload.edit;
			mutatedState.authority.view = action.payload.view;
			mutatedState.error = '';
			mutatedState.loggedIn = true;
			mutatedState.loggingIn = false;
			mutatedState.token = action.payload.token;
			return mutatedState;
		case ACTIONS.LOGIN_FAILED:
		case ACTIONS.VERIFY_FAILED:
			mutatedState.error = action.payload;
			mutatedState.loggedIn = false;
			mutatedState.loggingIn = false;
			return mutatedState;
		default:
			return state;
	}
};

export default authReducer;