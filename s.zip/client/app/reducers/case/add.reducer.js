import {ACTIONS} from "actions/case/add.actions";

const initialState = {
	details: {
		identifier: '',
		source: '',
		nim: '',
		document: '',
		notes: ''
	},
	error: '',
	people: [],
	addresses: [],
	vehicles: [],
	phones: [],
	emails: [],
	companies: [],
	custom: []
};

const caseReducer = (state = initialState, action) => {

    switch (action.type) {
		case ACTIONS.ADD_CASE_ADDRESS_DELETE:
			return {
				...state,
				addresses: [...state.addresses.filter(c => c.id !== action.id)]
			};
		case ACTIONS.ADD_CASE_ADDRESS_SAVE:
			return {
				...state,
				addresses: [...state.addresses.filter(c => c.id !== action.formValues.id), {
					id: action.formValues.id,
					housenumber: action.formValues.housenumber,
					line1: action.formValues.line1,
					line2: action.formValues.line2,
					line3: action.formValues.line3,
					line4: action.formValues.line4,
					line5: action.formValues.line5,
					line6: action.formValues.line6,
					postcode1: action.formValues.postcode1,
					postcode2: action.formValues.postcode2
				}]
			};
		case ACTIONS.ADD_CASE_CANCEL:
			return initialState;
		case ACTIONS.ADD_CASE_COMPANY_DELETE:
			return {
				...state,
				companies: [...state.companies.filter(c => c.id !== action.id)]
			};
		case ACTIONS.ADD_CASE_COMPANY_SAVE:
			return {
				...state,
				companies: [...state.companies.filter(c => c.id !== action.formValues.id), {
					id: action.formValues.id,
					value: action.formValues.value
				}]
			};
		case ACTIONS.ADD_CASE_CUSTOM_DELETE:
			return {
				...state,
				custom: [...state.custom.filter(c => c.id !== action.id)]
			};
		case ACTIONS.ADD_CASE_CUSTOM_SAVE:
			return {
				...state,
				custom: [...state.custom.filter(c => c.id !== action.formValues.id), {
					id: action.formValues.id,
					type: action.formValues.type,
					value: action.formValues.value
				}]
			};
		case ACTIONS.ADD_CASE_EMAIL_DELETE:
			return {
				...state,
				emails: [...state.emails.filter(c => c.id !== action.id)]
			};
		case ACTIONS.ADD_CASE_EMAIL_SAVE:
			return {
				...state,
				emails: [...state.emails.filter(c => c.id !== action.formValues.id), {
					id: action.formValues.id,
					value: action.formValues.value
				}]
			};
		case ACTIONS.ADD_CASE_PERSON_DELETE:
			return {
				...state,
				people: [...state.people.filter(c => c.id !== action.id)]
			};
		case ACTIONS.ADD_CASE_PERSON_SAVE:
			return {
				...state,
				people: [...state.people.filter(c => c.id !== action.formValues.id), {
					id: action.formValues.id,
					title: action.formValues.title,
					firstName: action.formValues.firstName,
					lastName: action.formValues.lastName,
					dateOfBirth: action.formValues.dateOfBirth,
					sensitivity: action.formValues.sensitivity,
					riskRating: action.formValues.riskRating,
					active: action.formValues.active
				}]
			};
		case ACTIONS.ADD_CASE_PHONE_DELETE:
			return {
				...state,
				phones: [...state.phones.filter(c => c.id !== action.id)]
			};

		case ACTIONS.ADD_CASE_PHONE_SAVE:
			return {
				...state,
				phones: [...state.phones.filter(c => c.id !== action.formValues.id), {
					id: action.formValues.id,
					value: action.formValues.value
				}]
			};
        case ACTIONS.ADD_CASE_SAVE:
            return initialState;
		case ACTIONS.ADD_CASE_SAVE_COMPLETE:
			return {
				...state,
				error: ''
			};
		case ACTIONS.ADD_CASE_SAVE_FAILED:
			return {
				...state,
				error: action.payload
			};
		case ACTIONS.ADD_CASE_VEHICLE_DELETE:
			return {
				...state,
				vehicles: [...state.vehicles.filter(c => c.id !== action.id)]
			};
		case ACTIONS.ADD_CASE_VEHICLE_SAVE:
			return {
				...state,
				vehicles: [...state.vehicles.filter(c => c.id !== action.formValues.id), {
					id: action.formValues.id,
					value: action.formValues.value,
					make: action.formValues.make,
					model: action.formValues.model
				}]
			};
		case ACTIONS.ADD_CASE_SET_DETAILS:
			return {
				...state,
				details: action.payload
			};
        default:
            return state;
    }
};

export default caseReducer;