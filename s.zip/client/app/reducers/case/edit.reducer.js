import {ACTIONS} from 'actions/case/edit.actions';
const initialState = {
	error: '',
	saving: false
};

const editCaseReducer = (state = initialState, action) => {
	switch(action.type) {
		case ACTIONS.UPDATE_CASE_DETAILS:
			return {...state, saving:true};
		case ACTIONS.UPDATE_CASE_DETAILS_COMPLETE:
			return {...state, error:'', saving:false};
		case ACTIONS.UPDATE_CASE_DETAILS_FAILED:
			return {...state, saving:false, error:action.payload};
		default:
			return state;
	}
};

export default editCaseReducer;