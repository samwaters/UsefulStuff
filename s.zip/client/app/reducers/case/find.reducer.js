import {
    PREVIEW_CASE,
    FIND_CASE,
    FIND_CASE_RESET,
    CLOSE_PREVIEW_CASE,
    ADD_CRITERIA_PEOPLE,
    DELETE_CRITERIA_PEOPLE,
    UPDATE_CRITERIA_PEOPLE,
    ADD_CRITERIA_ADDRESS,
    DELETE_CRITERIA_ADDRESS,
    UPDATE_CRITERIA_ADDRESS,
    ADD_CRITERIA_PHONE,
    DELETE_CRITERIA_PHONE,
    UPDATE_CRITERIA_PHONE,
    ADD_CRITERIA_EMAIL,
    DELETE_CRITERIA_EMAIL,
    UPDATE_CRITERIA_EMAIL,
    ADD_CRITERIA_VEHICLE,
    DELETE_CRITERIA_VEHICLE,
    UPDATE_CRITERIA_VEHICLE,
    ADD_CRITERIA_COMPANY,
    DELETE_CRITERIA_COMPANY,
    UPDATE_CRITERIA_COMPANY,
    ACTIVE_FORM_CRITERIA

} from "actions/case/find.actions";

const initialState = {
    results: [],
    preview: {},
    criteria: {
        activeFormCriteria: 0,
        people: [],
        addresses: [],
        phones: [],
        emails: [],
        vehicles: [],
        companies: [],
        custom: []
    }
};

const findCaseReducer = (state = initialState, action) => {

    switch (action.type) {

        case FIND_CASE_RESET:
            return initialState;

        case ACTIVE_FORM_CRITERIA:

            return {
                ...state,
                criteria: {
                    ...state.criteria,
                    activeFormCriteria: action.id
                }

            };

        case CLOSE_PREVIEW_CASE:

            return {
                ...state,
                preview: {}
            };

        case PREVIEW_CASE:

            return {
                ...state,
                preview: {id: action.id}
            };

        case FIND_CASE:

            return {
                ...state,
                results: [
                    {id: 111},
                    {id: 222}
                ]
            };

        case ADD_CRITERIA_PEOPLE:

            return {
                ...state,
                criteria: {
                    ...state.criteria,
                    people: [...state.criteria.people, {id: action.id, isNew: true}],
                    activeFormCriteria: action.id
                }
            };

        case UPDATE_CRITERIA_PEOPLE:
            return {
                ...state,
                criteria: {
                    ...state.criteria,
                    people: [
                        ...state.criteria.people.filter(p => p.id !== action.id),
                        {
                            id: action.id,
                            firstname: action.values.firstname,
                            firstnameOperator: action.values.firstnameOperator,
                            lastname: action.values.lastname,
                            lastnameOperator: action.values.lastnameOperator,
                            dateOfBirth: action.values.dateOfBirth,
                            isNew: false
                        }],
                    activeFormCriteria: 0
                }
            };

        case DELETE_CRITERIA_PEOPLE:

            return {
                ...state,
                criteria: {
                    ...state.criteria,
                    people: state.criteria.people.filter(p => p.id !== action.id),
                    activeFormCriteria: 0
                }

            };

        case ADD_CRITERIA_ADDRESS:

            return {
                ...state,
                criteria: {
                    ...state.criteria,
                    addresses: [...state.criteria.addresses, {id: action.id, isNew: true}],
                    activeFormCriteria: action.id
                }
            };

        case UPDATE_CRITERIA_ADDRESS:
            return {
                ...state,
                criteria: {
                    ...state.criteria,
                    addresses: [
                        ...state.criteria.addresses.filter(p => p.id !== action.id),
                        {
                            id: action.id,
                            line1: action.values.line1,
                            line1Operator: action.values.line1Operator,
                            line2: action.values.line2,
                            line2Operator: action.values.line2Operator,
                            line3: action.values.line3,
                            line3Operator: action.values.line3Operator,
                            line4: action.values.line4,
                            line4Operator: action.values.line4Operator,
                            line5: action.values.line5,
                            line5Operator: action.values.line5Operator,
                            line6: action.values.line6,
                            line6Operator: action.values.line6Operator,
                            isNew: false
                        }],
                    activeFormCriteria: 0
                }
            };

        case DELETE_CRITERIA_ADDRESS:

            return {
                ...state,
                criteria: {
                    ...state.criteria,
                    addresses: state.criteria.addresses.filter(p => p.id !== action.id),
                    activeFormCriteria: 0
                }

            };


        case ADD_CRITERIA_PHONE:

            return {
                ...state,
                criteria: {
                    ...state.criteria,
                    phones: [...state.criteria.phones, {id: action.id, isNew: true}],
                    activeFormCriteria: action.id
                }
            };

        case UPDATE_CRITERIA_PHONE:
            return {
                ...state,
                criteria: {
                    ...state.criteria,
                    phones: [
                        ...state.criteria.phones.filter(p => p.id !== action.id),
                        {
                            id: action.id,
                            number: action.values.number,
                            numberOperator: action.values.numberOperator,
                            isNew: false
                        }],
                    activeFormCriteria: 0
                }
            };

        case DELETE_CRITERIA_PHONE:

            return {
                ...state,
                criteria: {
                    ...state.criteria,
                    phones: state.criteria.phones.filter(p => p.id !== action.id),
                    activeFormCriteria: 0
                }

            };

        case ADD_CRITERIA_EMAIL:

            return {
                ...state,
                criteria: {
                    ...state.criteria,
                    emails: [...state.criteria.emails, {id: action.id, isNew: true}],
                    activeFormCriteria: action.id
                }
            };

        case UPDATE_CRITERIA_EMAIL:
            return {
                ...state,
                criteria: {
                    ...state.criteria,
                    emails: [
                        ...state.criteria.emails.filter(p => p.id !== action.id),
                        {
                            id: action.id,
                            email: action.values.email,
                            emailOperator: action.values.emailOperator,
                            isNew: false
                        }],
                    activeFormCriteria: 0
                }
            };

        case DELETE_CRITERIA_EMAIL:

            return {
                ...state,
                criteria: {
                    ...state.criteria,
                    emails: state.criteria.emails.filter(p => p.id !== action.id),
                    activeFormCriteria: 0
                }

            };

        case ADD_CRITERIA_VEHICLE:

            return {
                ...state,
                criteria: {
                    ...state.criteria,
                    vehicles: [...state.criteria.vehicles, {id: action.id, isNew: true}],
                    activeFormCriteria: action.id
                }
            };

        case UPDATE_CRITERIA_VEHICLE:
            return {
                ...state,
                criteria: {
                    ...state.criteria,
                    vehicles: [
                        ...state.criteria.vehicles.filter(p => p.id !== action.id),
                        {
                            id: action.id,
                            registration: action.values.registration,
                            registrationOperator: action.values.registrationOperator,
                            make: action.values.make,
                            makeOperator: action.values.makeOperator,
                            model: action.values.model,
                            modelOperator: action.values.modelOperator,
                            isNew: false
                        }],
                    activeFormCriteria: 0
                }
            };

        case DELETE_CRITERIA_VEHICLE:

            return {
                ...state,
                criteria: {
                    ...state.criteria,
                    vehicles: state.criteria.vehicles.filter(p => p.id !== action.id),
                    activeFormCriteria: 0
                }

            };

   case ADD_CRITERIA_COMPANY:

            return {
                ...state,
                criteria: {
                    ...state.criteria,
                    companies: [...state.criteria.companies, {id: action.id, isNew: true}],
                    activeFormCriteria: action.id
                }
            };

        case UPDATE_CRITERIA_COMPANY:
            return {
                ...state,
                criteria: {
                    ...state.criteria,
                    companies: [
                        ...state.criteria.companies.filter(p => p.id !== action.id),
                        {
                            id: action.id,
                            company: action.values.company,
                            companyOperator: action.values.companyOperator,
                            isNew: false
                        }],
                    activeFormCriteria: 0
                }
            };

        case DELETE_CRITERIA_COMPANY:

            return {
                ...state,
                criteria: {
                    ...state.criteria,
                    companies: state.criteria.companies.filter(p => p.id !== action.id),
                    activeFormCriteria: 0
                }

            };

        default:
            return state;
    }
};

export default findCaseReducer;