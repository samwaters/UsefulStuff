import {ACTIONS} from "actions/case/view.actions";

const initialState = {
	caseDetails: {
		details: {},
		people: [],
		addresses: [],
		vehicles: [],
		phones: [],
		emails: [],
		companies: [],
		custom: []
	},
	error: '',
	loading: false
};

const caseReducer = (state = initialState, action) => {

	switch(action.type) {

		case ACTIONS.CLOSE_CASE:
			return {caseDetails: {}, error: '', loading: false};
		case ACTIONS.LOAD_CASE:
			return {...state, loading: true};
		case ACTIONS.LOAD_CASE_COMPLETE:
			return {...state, caseDetails: action.payload, error: '', loading: false};
		case ACTIONS.LOGIN_FAILED:
			return {...state, caseDetails: {}, error: action.payload, loading: false};
		default:
			return state;
	}
};

export default caseReducer;