import {UPDATE_NAVIGATION_TAB} from "actions/home/headerbar.actions";


const initialState = {
    activetab: 99
};

const caseReducer = (state = initialState, action) => {

    switch (action.type) {

        case UPDATE_NAVIGATION_TAB:

            return {
                ...state,
                activetab: action.activeTab
            };

        default:
            return state;
    }
};

export default caseReducer;