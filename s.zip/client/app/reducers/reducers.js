import {combineReducers} from 'redux';
import authReducer from 'reducers/auth/auth.reducer';
import addCaseReducer from 'reducers/case/add.reducer';
import editCaseReducer from 'reducers/case/edit.reducer';
import findCaseReducer from 'reducers/case/find.reducer';
import viewCaseReducer from 'reducers/case/view.reducer';
import navigationReducer from 'reducers/home/headerbar.reducer';
import {routerReducer} from 'react-router-redux';
import {reducer as reduxFormReducer} from 'redux-form'

const appReducers = combineReducers(
	{
		auth: authReducer,
		caseadd: addCaseReducer,
		caseedit: editCaseReducer,
		casereview: viewCaseReducer,
		casefind: findCaseReducer,
		navigation: navigationReducer,
		routing: routerReducer,
		form: reduxFormReducer
	}
);

/**
 *
 * Nest reducers and look into selectors.  Check redux thunk and selector cachinf stuff
 *
 *
 */

export default appReducers;