import React from 'react';
import {IndexRedirect, Route, Router} from 'react-router';
import App from './app';
import LoginComponent from 'components/login/login.component';
import HomeComponent from 'components/home/home.component';
import AddCaseComponent from 'components/case/add/addcase.component';
import ViewCaseComponent from 'components/case/view/viewcase.component';
import FindCaseComponent from 'components/case/find/findcase.component';
import NotFoundComponent from 'components/common/notfound.component';
import * as authSelectors from 'selectors/auth/auth.selectors';

const getRoutes = (store) => {
    const requireAuth = (nextState, replace) => {
        const state = store.getState();
        if(!authSelectors.selectIsLoggedIn(state)) {
            replace({pathname: '/login', query: {returnTo:nextState.location.pathname}});
        }
    };
    const requireNoAuth = (nextState, replace) => {
        const state = store.getState();
        if(authSelectors.selectIsLoggedIn(state)) {
            replace({pathname: '/home'});
        }
    };
    return (
		<Router>
			<Route path="/login" component={LoginComponent} onEnter={(n, r) => requireNoAuth(n, r)}/>
            {/*Full screen display*/}
			<Route path="/case/:id" component={ViewCaseComponent}/>

            {/*Display with banner environment*/}
            <Route path="/" component={App} onEnter={(n, r) => requireAuth(n, r)}>
				<IndexRedirect to="/home"/>
				<Route path="/case/:id/view" components={{main: ViewCaseComponent}}/>
				<Route path="/home" components={{main: HomeComponent}}/>
				<Route path="/add" components={{main: AddCaseComponent}}/>
				<Route path="/find" components={{main: FindCaseComponent}}/>
				<Route path="*" components={{main: NotFoundComponent}}/>
			</Route>
		</Router>
    )
};

export default getRoutes;