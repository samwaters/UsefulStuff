const selectIsLoggedIn = state => state.auth.loggedIn;

export {selectIsLoggedIn};