const server = require('../server');

server.express.post('/api/auth/login', (req, res) => {
	if(!req.body || !req.body.username || !req.body.password) {
		server.respond(401, {ok: false, error: 'Incomplete Payload'}, res);
		return;
	}
	// 1. Validate user
	let user = req.body.username.toUpperCase();
	server.auth.verify(user, req.body.password).then(
		profile => {
			// 2. Look up user in db
			server.db.getUserPermissions(user).then(
				// 3. Return token and details to client
				permissions => {
					let token = server.crypt.rsa.encrypt(
						JSON.stringify({
							authority: {
								edit: permissions.KUEDIT,
								view: permissions.KUVIEW
							},
							expires: new Date().getTime() + 3600000, //1h
							generated: new Date().getTime(),
							username: req.body.username
						}),
						server.crypt.rsa.keyTypes.PUBLIC
					);
					res.cookie('mkdbToken', token, {expires: new Date(Date.now() + 604800000)});
					res.cookie('mkdbUsername', req.body.username, {expires: new Date(Date.now() + 604800000)})
					server.respond(200, {
						data: {
							edit: permissions.KUEDIT,
							token: token,
							view: permissions.KUVIEW
						},
						ok: true
					}, res);
				},
				err => {
					server.respond(401, {ok: false, error: err}, res);
				}
			);
		},
		err => {
			server.respond(401, {ok: false, error: err}, res);
		}
	);
});

server.express.post('/api/auth/verify', (req, res) => {
	if(!req.body.username || !req.cookies.mkdbToken) {
		server.respond(400, {ok: false, error: 'Incomplete Payload'}, res);
		return;
	}
	try {
		let decrypted = JSON.parse(server.crypt.rsa.decrypt(req.cookies.mkdbToken, server.crypt.rsa.keyTypes.PRIVATE));
		if(decrypted) {
			let currentTime = new Date().getTime();
			if(
				decrypted.username === req.body.username
				&& decrypted.expires > currentTime
				&& decrypted.generated < currentTime
			) {
				server.respond(200, {
					data: {
						edit: decrypted.authority.edit,
						token: req.cookies.mkdbToken,
						view: decrypted.authority.view
					},
					ok: true
				}, res);
			} else {
				server.respond(401, {ok: false, error: 'Invalid token'}, res);
			}
		} else {
			server.respond(400, {ok: false, error: 'Invalid token'});
		}
	} catch(e) {
		server.respond(401, {ok: false, error: 'Could not verify token'}, res);
	}
});