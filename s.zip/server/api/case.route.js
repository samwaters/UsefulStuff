const server = require('../server');

/*
 {
 case: {
 identifier:'',
 source:'',
 nim:'',
 documentLink:'',
 notes:''
 },
 people:[
 {firstName:'John', lastName:'Smith', dob:'01/01/1970'},
 {firstName:'Jane', lastName:'Smith', dob:'02/02/1970'},
 {existingId: 91723}
 ],
 addresses:[
 {number:'Flat 1a', line1:'Fraud Lane', line2:'FraudTown', line3:'', line4:'', line5:'', line6:'', postcode1:'FR4', postcode2:'UDY'}
 ],
 vehicles:[
 {registration:'DO16 DGY'}
 ],
 phones:[
 {type:'mobile', number:'07000000000'},
 {type:'landline', number:'0200000000'}
 ],
 custom:[
 {type:'ip', value:'12.34.56.78'},
 {type:'drivinglicence', value:'SMITH701010JO4TY'},
 {type:'drivinglicence', value:'SMITH702020JA1FP'},
 ]
 }
 */
server.express.get('/api/case/:id', (req, res) => {
	if(!req.params.id) {
		server.respond(400, {ok: false, error: 'Incomplete Payload'}, res);
		return;
	}
	server.db.case.loadCase(req.params.id).then(
		caseDetails => server.respond(200, {ok: true, data: caseDetails}, res),
		err => server.respond(500, {ok:false, error:err}, res)
	);
});

server.express.patch('/api/case/:id', (req, res) => {
	let actions = [];
	if(req.body.details) {
		req.body.details.id = req.params.id;
		actions.push(server.db.case.updateDetails(req.body.details));
	}
	if(req.body.people) {
		actions.push(server.db.case.updatePeople(req.body.people));
	}
	if(req.body.addresses) {
		actions.push(server.db.case.updatePeople(req.body.addresses));
	}
	if(req.body.companies) {
		actions.push(server.db.case.updateCompanies(req.body.companies));
	}
	if(req.body.emails) {
		actions.push(server.db.case.updateEmails(req.body.emails));
	}
	if(req.body.phones) {
		actions.push(server.db.case.updatePhones(req.body.phones));
	}
	if(req.body.vehicles) {
		actions.push(server.db.case.updateVehicles(req.body.vehicles));
	}
	if(req.body.custom) {
		actions.push(server.db.case.updateCustom(req.body.custom));
	}
	if(actions.length === 0) {
		server.respond(400, {ok: false, error:'No updates to perform'}, res);
		return;
	}
	Promise.all(actions).then(
		() => server.respond(200, {ok: true, data: {caseId: req.params.id}}, res),
		err => server.respond(500, {ok: false, error: err}, res)
	);
});

server.express.post('/api/case', (req, res) => {
	if(!req.body.details) {
		server.respond(400, {ok: false, error: 'Incomplete Payload'}, res);
		return;
	}
	server.db.case.createCase(req.body.details).then(
		ids => {
			// {auditId:3, caseId:1}
			Promise.all([
				server.db.case.addPeople(ids.caseId, req.body.people),
				server.db.case.addAddresses(ids.caseId, req.body.addresses),
				server.db.case.addGeneric(ids.caseId, req.body.companies, 'COM'),
				server.db.case.addGeneric(ids.caseId, req.body.emails, 'EMA'),
				server.db.case.addGeneric(ids.caseId, req.body.phones, 'PHO'),
				server.db.case.addGeneric(ids.caseId, req.body.vehicles, 'REG'),
				server.db.case.addGeneric(ids.caseId, req.body.custom)
			]).then(
				() => server.respond(200, {ok: true, data: {caseId: ids.caseId}}, res),
				err => server.respond(500, {ok: false, error: err}, res)
			);
		},
		err => server.respond(500, {ok: false, error: err}, res)
	)
});