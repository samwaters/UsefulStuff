const server = require('../../server');

server.express.post('/api/case/create', (req, res) => {

});