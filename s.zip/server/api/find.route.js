const server = require('../server');

/*
  REQUEST
 {
	 people:[
		 [
		 	{field: 'firstName', operator: 'equals', value: 'john'},
		 	{field: 'lastName', operator: 'startsWith', value: 'smi'},
		 	{field: 'dateOfBirth', operator: 'equals', value: '01/01/1970'}
		 ],
		 [
			{field: 'lastName', operator: 'startsWith', value: 'smi'},
		 ]
	 ],
	 addresses: [
		 {field: 'postcode1', operator: 'equals', value: 'PO15'},
		 {field: 'postcode2', operator: 'equals', value: '7FN'}
	 ],
	 vehicles: [
	 	{field: 'registration', operator: 'equals', value: 'TE15LAA'}
	 ],
	 phones: [],
	 companies: [],
	 custom: [
	 	{field: 'ninumber', operator: 'endsWith', value: '99A'}
	 ]
 }

 RESPONSE
 [
	 {id: 137, reference: 'IFB0001', nim: 3, notes: 'Notes'},
	 {id: 139, reference: 'IFB0002', nim: 3, notes: 'Notes 2'}
 ]
 */
server.express.post('/api/find', (req, res) => {

});