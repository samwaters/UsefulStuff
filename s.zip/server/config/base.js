module.exports = {
	crypto: {
		digest: 'sha512',
		hashSize: 32,
		iterations: 100000,
		saltSize: 16
	},
	port: 9001
};