const path = require('path');

module.exports = {
	auth: {
		table: 'users',
		type: 'DB'
	},
	database: {
		path: path.resolve(__dirname, '..', '..', 'data', 'db.sql'),
		type: 'SQLite'
	},
	environment: 'Development',
	toolkit: ''
};