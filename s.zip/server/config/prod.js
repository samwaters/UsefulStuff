module.exports = {
	auth: {
		table: '*LOCAL',
		type: 'iSeries'
	},
	database: {
		host: '',
		password: '',
		type: 'DB2',
		username: ''
	},
	environment: 'Production',
	toolkit: '/QOpenSys/QIBM/ProdData/OPS/Node6/os400/xstoolkit/lib/itoolkit'
};