const authentication = require('./lib/auth/auth');
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const compression = require('compression');
const express = require('express');
const database = require('./lib/db/db');
const fs = require('fs');
const passwordcrypt = require('./lib/crypt/password');
const path = require('path');
const rsacrypt = require('./lib/crypt/rsa');

// Container class
class Server {}

// Configs
let config;
if(process.env === 'prod') {
	config = Object.assign({}, require('./config/base'), require('./config/prod'));
} else {
	config = Object.assign({}, require('./config/base'), require('./config/dev'));
}

//Auth
Server.auth = new authentication(config.auth, config.toolkit);

// Crypt
Server.crypt = {
	password: new passwordcrypt(config.crypto),
	rsa: new rsacrypt()
};

// Database
Server.db = new database(config.database);

// Express configuration
Server.express = express();
Server.express.use(bodyParser.json());
Server.express.use(cookieParser());
Server.express.use(compression());
// Route loading
let folders = ['api', 'api/case'];
folders.forEach(folder => {
	let routePath = path.join(__dirname, folder);
	fs.readdir(routePath, function(err, files) {
		files.forEach(function(file) {
			if(file.endsWith('.route.js')) {
				console.log('Loading routes from', file);
				require(path.join(routePath, file));
			}
		});
	});
});

Server.express.use('/', express.static('dist'));
// Middleware
Server.express.use(function(req, res, next) {
	res.setHeader('Access-Control-Allow-Origin', '*');
	res.setHeader('Access-Control-Allow-Headers', 'origin, content-type, accept');
	res.setHeader('Cache-Control', 'no-cache, no-store, max-age=0, must-revalidate');
	next();
});
Server.express.all(/api/, function(req, res, next) {
	res.setHeader('Access-Control-Allow-Methods', 'DELETE, GET, OPTIONS, PATCH, POST, PUT');
	res.setHeader('Content-Type', 'application/json');
	next();
});


// Response helper
Server.respond = (status, response, res) => {
	res.status(status);
	res.send(JSON.stringify(response));
	res.end();
};

// Start server
Server.express.listen(config.port);
console.log(config.environment, 'Server running on port', config.port);

// Export container
module.exports = Server;
