import ajax from '../utils/ajax';

export function ajaxCall(url, method, data, nextAction) {
    return (dispatch) => {
        ajax(url, method, data).then(
            res => {
                switch (typeof nextAction) {
                    case 'object':
                        nextAction.payload.data = JSON.parse(res);
                        dispatch(nextAction);
                        break;
                    case 'function':
                        nextAction(dispatch, JSON.parse(res));
                        break;
                    case 'string':
                        dispatch({type: nextAction, payload: JSON.parse(res)});
                        break;
                    default:
                        throw new Error('Unknown action type passed to ajaxCall');
                }
            },
            err => console.error('Ajax error', err)
        );
    }
}