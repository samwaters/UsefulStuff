import ajax from '../utils/ajax';

export function ajaxCall(url, method, data, nextAction, loadAction=null) {
    return (dispatch, getState) => {
        let state = getState();
        let headers = [];
        if(state.authReducer.loggedInUser) {
            headers.push({name:'username', value:state.authReducer.loggedInUser});
        }
        if(state.authReducer.token) {
            headers.push({name:'token', value:state.authReducer.token});
        }
        if(loadAction) {
			dispatch({type: loadAction});
        }
        ajax(url, method, data, headers).then(
            res => {
                switch (typeof nextAction) {
                    case 'object':
                        nextAction.payload.data = JSON.parse(res);
                        dispatch(nextAction);
                        break;
                    case 'function':
                        nextAction(dispatch, JSON.parse(res));
                        break;
                    case 'string':
                        dispatch({type: nextAction, payload: JSON.parse(res)});
                        break;
                    default:
                        throw new Error('Unknown action type passed to ajaxCall');
                }
            },
            err => console.error('Ajax error', err)
        );
    }
}
