import {ajaxCall} from './ajax.actions';
import {push} from 'react-router-redux';

export const ACTIONS = {
    LOGIN: 'LOGIN',
    LOGIN_COMPLETE: 'LOGIN_COMPLETE',
    LOGIN_FAILED: 'LOGIN_FAILED',
    LOGOUT: 'LOGOUT',
    LOGOUT_COMPLETE: 'LOGOUT_COMPLETE',
    REGISTER: 'REGISTER',
    REGISTER_COMPLETE: 'REGISTER_COMPLETE',
    REGISTER_FAILED: 'REGISTER_FAILED'
};

const login = (username, password) => {
    return ajaxCall(
        '/api/auth/login',
        'POST',
        {username: username, password: password},
        loginComplete()
    );
};

const loginComplete = () => {
    return (dispatch, res) => {
        if (res.ok) {
            dispatch({
                type: ACTIONS.LOGIN_COMPLETE,
                payload: {
                    token:res.token,
                    username:res.username
                }
            });
            dispatch(push('/home'));
        } else {
            dispatch({type: ACTIONS.LOGIN_FAILED});
        }
    }
};

const logout = (username) => {
    return ajaxCall(
        '/api/auth/logout',
        'POST',
        {username: username},
        logoutComplete()
    );
};

const logoutComplete = () => {
    return (dispatch, res) => {
        if(res.ok) {
            dispatch({type: ACTIONS.LOGOUT_COMPLETE});
            dispatch(push('/login'));
        }
    }
};

const register = (username, password) => {
    return ajaxCall(
        '/api/auth/register',
        'POST',
        {username: username, password: password},
        registerComplete()
    );
};

const registerComplete = () => {
    return (dispatch, res) => {
        if (res.ok) {
            dispatch({
                type: ACTIONS.REGISTER_COMPLETE,
                payload: {
                    token:res.token,
                    username:res.username
                }
            });
            dispatch(push('/home'));
        } else {
            dispatch({type: ACTIONS.REGISTER_FAILED});
        }
    }
};

export {login, logout, register};

