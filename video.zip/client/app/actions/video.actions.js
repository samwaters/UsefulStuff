import {push} from 'react-router-redux';

export const ACTIONS = {
    STORE_VIDEO: 'STORE_VIDEO',
};

const storeVideo = (key, security) => {
    return dispatch => {
        dispatch({
            type: ACTIONS.STORE_VIDEO,
            payload: {
                key: key,
                security: security
            }
        });
        dispatch(push('/view/' + key));
    }
};

export {storeVideo};