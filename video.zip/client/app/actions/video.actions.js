import {ajaxCall} from './ajax.actions';

export const ACTIONS = {
    LOAD_VIDEOS_START: 'LOAD_VIDEO_START',
    LOAD_VIDEOS: 'LOAD_VIDEOS',
    STORE_VIDEOS: 'STORE_VIDEOS',
};

const loadVideos = () => {
    return ajaxCall('/api/video/list', 'GET', '', storeVideos(), ACTIONS.LOAD_VIDEOS_START);
};

const storeVideos = () => {
    return (dispatch, res) => {
        dispatch({
            type: ACTIONS.STORE_VIDEOS,
            payload: res.videos
        });
    }
};

export {loadVideos};
