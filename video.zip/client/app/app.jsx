// React
import React from 'react';
import {AppBar, Layout, Panel} from 'react-toolbox';

class AppComponent extends React.Component {
    constructor() {
        super();
        this.state = {
            sidebarActive: false
        }
    }

    render() {
        const {main} = this.props;
        return (
            <Layout>
                <Panel>
                    <AppBar leftIcon="menu" title="Video Upload" />
                    {main}
                </Panel>
            </Layout>
        );
    }
}

export default AppComponent;