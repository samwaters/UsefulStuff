// React
import React from 'react';
import {connect} from 'react-redux';
import * as authActions from './actions/auth.actions';
import {AppBar, Button, Layout, Panel, Navigation} from 'react-toolbox';

class App extends React.Component {
    constructor() {
        super();
        this.state = {
            sidebarActive: false
        }
    }

    render() {
        const {main} = this.props;
        return (
            <Layout>
                <Panel>
                    <AppBar leftIcon="menu" title="Video Upload">
                        <Navigation type="horizontal">
                            {
                                this.props.loggedIn &&
                                <Button primary raised onClick={() => this.props.logOut(this.props.loggedInUser)}>Log Out {this.props.loggedInUser}</Button>
                            }
                        </Navigation>
                    </AppBar>
                    {main}
                </Panel>
            </Layout>
        );
    }
}

const AppComponent = connect(
    state => {
        return {
            loggedIn: state.authReducer.loggedIn,
            loggedInUser: state.authReducer.loggedInUser
        }
    },
    dispatch => {
        return {
            logOut: (username) => {
                dispatch(authActions.logout(username))
            }
        }
    }
)(App);

export default AppComponent;