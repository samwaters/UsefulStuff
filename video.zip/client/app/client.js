var targets = document.getElementsByClassName('drop-target');
$('.drop-target').each(function(idx, target) {
    console.log(target);
    target.addEventListener('dragover', function(e) {
        e.preventDefault();
        this.className = 'drop-target dropping';
    });
    target.addEventListener('dragleave', function(e) {
        this.className = 'drop-target';
        e.dataTransfer.clearData();
    });
    target.addEventListener('drop', function(e) {
        e.preventDefault();
        this.className = 'drop-target';
        if(!e.dataTransfer.files || e.dataTransfer.files.length !== 1) {
            // Multiple files error
            error('Upload one file at a time');
            return;
        }
        let file = e.dataTransfer.files[0];
        if(!/(avi|mkv|mov|mpg|mpeg|mp4|webm)$/i.test(file.name)) {
            //Invalid type error
            error('That doesn\'t look like a video!');
            return;
        }
        if(file.size > 25 * 1024 * 1024) {
            error('Upload a smaller file');
            return;
        }
        var xhr = new XMLHttpRequest();
        xhr.open('POST', '/api/upload', true);
        xhr.setRequestHeader('X-File-Name', file.name);
        xhr.addEventListener('progress', function(e) {
            if(e.lengthComputable) {
                $('.uploading .progress-bar').css('width', (e.loaded / e.total) + '%');
                $('.uploading span').text(e.loaded + ' of ' + e.total);
            } else {
                $('.uploading .progress-bar').css('width', '50%');
                $('.uploading span').text('Unknown of Unknown bytes');
            }
        });
        xhr.addEventListener('load', function(e) {
            // Done :)
            console.log(e);
            gotoScreen(3);
        });
        xhr.addEventListener('error', function(e) {
            error('Upload failed');
            console.log(e);
            gotoScreen(1);
        });
        xhr.addEventListener('abort', function(e) {
            // Canceled it - page navigation?
        });
        xhr.send(file);
        gotoScreen(2);
    });
});

function clearErrors() {
    $('.error').remove();
}

function error(text) {
    $('.panel-body').prepend('<div class="error">' + text + '</div>');
}

function gotoScreen(id) {
    clearErrors();
    switch(id) {
        case 1:
            $('.uploading, .post-upload').hide();
            $('.pre-upload').show();
            break;
        case 2:
            $('.pre-upload, .post-upload').hide();
            $('.uploading').show();
            break;
        case 3:
            $('.pre-upload, .uploading').hide();
            $('.post-upload').show();
            break;
        default:
            throw new Error('Unknown screen');
    }
}