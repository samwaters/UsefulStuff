import React from 'react';
import {connect} from 'react-redux';
import * as authActions from '../../actions/auth.actions';
import {FlexContainer, FlexItem} from '../layout/flex';
import LoginComponent from './login';
import RegisterComponent from './register';
import {Tab, Tabs} from 'react-toolbox';

class Auth extends React.Component {
    constructor() {
        super();
        this.state = {
            tabIndex: 0
        };
    }

    render() {
        return <div style={{flex:1}}>
            <FlexContainer direction="row">
                <FlexItem width="15%"/>
                <FlexItem width="70%">
                    <Tabs fixed index={this.state.tabIndex} onChange={i => this.tabChange(i)}>
                        <Tab label="Log In"><LoginComponent loginFailed={this.props.loginFailed} onLogin={this.props.onLogin} /></Tab>
                        <Tab label="Register"><RegisterComponent onRegister={this.props.onRegister} registrationFailed={this.props.registrationFailed}/></Tab>
                    </Tabs>
                </FlexItem>
                <FlexItem width="15%"/>
            </FlexContainer>
        </div>
    }

    tabChange(index) {
        this.setState({tabIndex:index})
    }
}

const mapStateToProps = state => {
    return {
        loginFailed: state.authReducer.loginFailed,
        registrationFailed: state.authReducer.registrationFailed
    }
};

const mapDispatchToProps = dispatch => {
    return {
        onLogin: (username, password) => dispatch(authActions.login(username, password)),
        onRegister: (username, password) => dispatch(authActions.register(username, password))
    }
};

const AuthComponent = connect(mapStateToProps, mapDispatchToProps)(Auth);

export default AuthComponent;
