import React from 'react';
import {Button, Input} from 'react-toolbox';
import {Warning} from '../common/messages'

class LoginComponent extends React.Component {
    constructor() {
        super();
        this.state = {
            email: '',
            password: ''
        };
    }

    inputChange(name, value) {
        this.setState(Object.assign({}, this.state, {[name]: value}));
    }

    render() {
        return <div>
            {
                this.props.loginFailed && <Warning>Incorrect username or password</Warning>
            }
            <Input type="text" label="E-Mail" name="email" value={this.state.email} onChange={v => this.inputChange('email', v)} />
            <Input type="password" label="Password" name="password" value={this.state.password} onChange={v => this.inputChange('password', v)} />
            <Button
                raised primary disabled={this.state.email.length < 2 || this.state.password.length < 2}
                onClick={() => this.props.onLogin(this.state.email, this.state.password)}
            >Log In</Button>
        </div>
    }
}

LoginComponent.propTypes = {
    loginFailed: React.PropTypes.bool.isRequired,
    onLogin: React.PropTypes.func.isRequired
};

export default LoginComponent;