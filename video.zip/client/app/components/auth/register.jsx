import React from 'react';
import {Button, Checkbox, Dialog, Input} from 'react-toolbox';
import {Warning} from '../common/messages'

class RegisterComponent extends React.Component {
    constructor() {
        super();
        this.state = {
            email: '',
            password: '',
            password2: '',
            tcs: false,
            tcsDialog: false
        };
    }

    inputChange(name, value) {
        this.setState(Object.assign({}, this.state, {[name]: value}));
    }

    render() {
        return <div>
            {
                this.props.registrationFailed && <Warning>Registration failed</Warning>
            }
            <Input type="text" label="E-Mail" name="email" value={this.state.email} onChange={v => this.inputChange('email', v)} />
            <Input type="password" label="Password" name="password" value={this.state.password} onChange={v => this.inputChange('password', v)} />
            <Input type="password" label="Confirm Password" name="password2" value={this.state.password2} onChange={v => this.inputChange('password2', v)} />
            <p>Please read the <a href="#" onClick={e => this.toggleDialog(e)}>Terms &amp; Conditions</a> before registering</p>
            <Checkbox label="I have read and agree to the terms and conditions" checked={this.state.tcs} onChange={v => this.inputChange('tcs', v)} />
            <Button
                raised primary
                disabled={
                    this.state.email.length < 2
                    || this.state.password.length < 2
                    || this.state.password != this.state.password2
                    || !this.state.tcs
                }
                onClick={() => this.props.onRegister(this.state.email, this.state.password)}
            >Register</Button>
            <Dialog
                actions={[{label: 'Ok', onClick: () => this.toggleDialog()}]}
                active={this.state.tcsDialog}
                onEscKeyDown={() => this.toggleDialog()}
                onOverlayClick={() => this.toggleDialog()}
            >
                <p>Terms and conditions here</p>
                <p>The usual stuff</p>
            </Dialog>
        </div>
    }

    toggleDialog(e) {
        if(e) {
            e.preventDefault();
        }
        this.setState({tcsDialog: !this.state.tcsDialog});
    }
}

RegisterComponent.propTypes = {
    onRegister: React.PropTypes.func.isRequired,
    registrationFailed: React.PropTypes.bool.isRequired
};

export default RegisterComponent;