import React from 'react';
import {Error, Information} from '../common/messages';
import {FlexContainer, FlexItem} from '../layout/flex';
import SeekBar from './seekbar';

class EditComponent extends React.Component {
    constructor() {
        super();
        this.state = {
            checkedState: false,
            currentState: 0,
            lastError: '',
            timerId: 0,
            videoDuration: 0,
            videoLoaded: false,
        };
    }

    checkVideoStatus() {
        let xhr = new XMLHttpRequest();
        xhr.open('GET', '/api/view/' + this.props.params.key + '/status', true);
        xhr.addEventListener('load', e => {
            let response = JSON.parse(e.currentTarget.responseText);
            if(!response || !response.ok) {
                this.setState({lastError: 'Could not load video'});
            } else {
                this.setState({checkedState: true, currentState: response.status, lastError: ''});
                if(response.status === 2) {
                    clearInterval(this.state.timerId);
                }
            }
        });
        xhr.addEventListener('error', e => {
            this.setState({lastError: e});
        });
        xhr.send();
    }

    componentDidMount() {
        this.checkVideoStatus();
        let id = setInterval(() => this.checkVideoStatus(), 10000);
        this.setState({timerId: id});
    }

    render() {
        return <FlexContainer direction="row">
            <FlexItem width="15%"/>
            <FlexItem width="70%">
                {
                    this.state.lastError !== '' && <Error>{this.state.lastError}</Error>
                }
                {
                    !this.state.checkedState && <p>Checking video status, please wait</p>
                }
                {
                    this.state.currentState < 2 && <div>
                        {this.state.currentState === -1 && <Error>Your video failed to process, please contact us or try again</Error>}
                        {this.state.currentState === 0 && <Information>Your video is currently in a queue to be processed</Information>}
                        {this.state.currentState === 1 && <Information>Your video is currently being processed</Information>}
                        <p>This status automatically updates every 10 seconds</p>
                    </div>
                }
                {
                    this.state.currentState === 2 && <div style={{textAlign:'center'}}>
                        <video muted style={{height:'480px', width:'640px'}} onLoadedData={e => this.videoLoaded(e)}>
                            <source
                                src={`/api/view/${this.props.params.key}/watch`}
                                type="video/mp4"
                            />
                            Your browser does not support the &lt;video&gt; tag
                        </video>
                    </div>
                }
                {
                    this.state.videoLoaded && <SeekBar duration={this.state.videoDuration} />
                }
            </FlexItem>
            <FlexItem width="15%"/>
        </FlexContainer>
    }

    videoLoaded(e) {
        this.setState({
            videoDuration: e.currentTarget.duration,
            videoLoaded: true
        });
    }
}

export default EditComponent;