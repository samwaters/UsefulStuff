import React from 'react';
import * as styles from './seekbar.styles.scss';
import {Checkbox} from 'react-toolbox';

class SeekBar extends React.Component {
    constructor() {
        super();
        this.state = {
            cropBarCursor: 'default',
            end: Infinity,
            removeAudio: false,
            start: 0
        };
    }

    cropBarMouseMove(e) {
        let offset = this.getOffset(e.currentTarget);
        if(e.clientX - offset < 2) {
            this.setState({cropBarCursor: 'w-resize'});
        } else if(offset + e.currentTarget.clientWidth - e.clientX < 2) {
            this.setState({cropBarCursor: 'e-resize'});
        } else {
            this.setState({cropBarCursor: 'default'});
        }
    }

    getOffset(el) {
        let offset = el.offsetLeft ? parseInt(el.offsetLeft) : 0;
        while(el.offsetParent) {
            el = el.offsetParent;
            offset += el.offsetLeft ? parseInt(el.offsetLeft) : 0;
        }
        return offset;
    }

    render() {
        return <div className={styles.processingOptions}>
            <div className={styles.time}>
                <div className={styles.cropBar} onMouseMove={e => this.cropBarMouseMove(e)} style={{cursor:this.state.cropBarCursor}}></div>
                <div className={styles.timeline}></div>
                <div className={styles.clipStart}>0</div>
                <div className={styles.clipDuration}>{this.props.duration}</div>
            </div>
            <Checkbox checked={this.state.removeAudio} label="Remove Audio" onChange={() => this.toggleRemoveAudio() } />
        </div>;
    }

    toggleRemoveAudio() {
        this.setState({removeAudio: !this.state.removeAudio})
    }
}
SeekBar.propTypes = {
    duration: React.PropTypes.number.isRequired
};

export default SeekBar;