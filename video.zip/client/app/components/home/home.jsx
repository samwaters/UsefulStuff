import React from 'react';
import {FlexContainer, FlexItem} from '../layout/flex';
import {Link} from 'react-router';
import {List, ListItem} from 'react-toolbox';
import * as styles from './home.styles';

class HomeComponent extends React.Component {
    render() {
        const {page} = this.props;
        return <FlexContainer className={styles.homeContainer} direction="row">
            <FlexItem className={styles.navigation} width="10%">
                <List ripple className={styles.navigationList}>
                    <ListItem><Link to="/home">Home</Link></ListItem>
                    <ListItem><Link to="/upload">Upload Video</Link></ListItem>
                    <ListItem><Link to="/help">Help</Link></ListItem>
                </List>
                <div className={styles.footer}>&copy; 2017</div>
            </FlexItem>
            <FlexItem width="90%" className={styles.scrollable}>
                {page}
            </FlexItem>
        </FlexContainer>
    }
}

export default HomeComponent;
