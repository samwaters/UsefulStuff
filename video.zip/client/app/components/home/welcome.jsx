import React from 'react';

const WelcomeComponent = () => {
    return <p>Welcome</p>
};

export default WelcomeComponent;