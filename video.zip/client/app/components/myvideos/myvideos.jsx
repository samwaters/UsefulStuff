import React from 'react';
import {connect} from 'react-redux';
import * as videoActions from '../../actions/video.actions';
import {Button, Card, CardMedia, CardTitle, CardText, CardActions} from 'react-toolbox';

class MyVideos extends React.Component {
	constructor() {
		super();
		this.state = {};
	}

	componentDidMount() {
		this.props.loadVideos();
	}

	render() {
		let videos = this.props.videos.map(v => {
			let token = btoa(JSON.stringify({username:this.props.username, token:this.props.token}));
			let thumbnail = '/api/video/' + v.key + '/thumbnail?token=' + token;
			return <Card key={v.key} style={{float:'left', margin:'5px', width:'350px'}}>
				<CardMedia aspectRatio="wide" image={thumbnail} />
				<CardTitle title={v.name} />
				<CardText>
					<p>{v.description}</p>
					<p>Added: {v.added}</p>
				</CardText>
				<CardActions>
					<Button raised primary>View Video</Button>
				</CardActions>
			</Card>});
		return <div>
			{
				this.props.loading && <p>Loading videos, please wait</p>
			}
			{
				!this.props.loading && videos
			}
		</div>
	}
}

const MyVideosComponent = connect(
	state => {
		return {
			loading: state.videoReducer.isLoading,
			token: state.authReducer.token,
			username: state.authReducer.loggedInUser,
			videos: state.videoReducer.videos
		}
	},
	dispatch => {
		return {
			loadVideos: () => dispatch(videoActions.loadVideos())
		}
	}
)(MyVideos);

export default MyVideosComponent;
