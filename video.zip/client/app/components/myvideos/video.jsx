import React from 'react';
import {FlexContainer, FlexItem} from '../layout/flex';
import {Button} from 'react-toolbox';

class VideoComponent extends React.Component {
	constructor() {
		super();
		this.state = {};
	}

	render() {
		return <div>
			<h3>{this.props.title}</h3>
			<FlexContainer direction="row">
				<FlexItem width="20%">
					<img src="https://placeholdit.imgix.net/~text?txtsize=33&txt=Video&w=160&h=90" />
				</FlexItem>
				<FlexItem width="70%">
					<p>{this.props.description}</p>
					<p>Added: {this.props.added}</p>
					<p>Video Status: {this.props.status}</p>
					<p>Shared: {this.props.shared}</p>
				</FlexItem>
				<FlexItem width="10%">
					<Button raised primary>View Video</Button>
				</FlexItem>
			</FlexContainer>
		</div>
	}
}

VideoComponent.propTypes = {
	title: React.PropTypes.string.isRequired,
	description: React.PropTypes.string.isRequired,
	added: React.PropTypes.string.isRequired,
	status: React.PropTypes.number.isRequired,
	shared: React.PropTypes.bool.isRequired
};

export default VideoComponent;
