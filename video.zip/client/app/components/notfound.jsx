import React from 'react';

const NotFoundComponent = () => {
    return (
        <div>
            <h3>Not Found</h3>
            <p>The page you are looking for was not found</p>
        </div>
    );
};
export default NotFoundComponent;