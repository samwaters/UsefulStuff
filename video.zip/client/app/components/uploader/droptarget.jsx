import React, {PropTypes} from 'react';
import * as styles from './droptarget.styles.scss';
import classNames from 'classnames';

class DropTarget extends React.Component {
    constructor() {
        super();
        this.state = {
            dropping: false
        };
    }

    handleDrop(e) {
        e.preventDefault();
        this.setState({dropping: false});
        if(!e.dataTransfer.files || e.dataTransfer.files.length > this.props.maxFileCount) {
            // Multiple files error
            this.props.onDropError('Upload files one at a time');
            return;
        }
        for(let i=0; i<e.dataTransfer.files.length; i++) {
            // Check extension here
            let ext = /.*\.(.{3})/.exec(e.dataTransfer.files[i].name);
            if(!ext || this.props.allowedFileTypes.indexOf(ext[1].toLowerCase()) === -1) {
                this.props.onDropError('That type of file is not permitted');
                return;
            }
            if(e.dataTransfer.files[i].size > this.props.maxFileSize) {
                this.props.onDropError('Upload a smaller file');
                return;
            }
        }
        this.props.onFileDropped(e.dataTransfer.files);
    }

    startDrop(e) {
        e.preventDefault();
        this.setState({dropping: true});
    }

    stopDrop() {
        this.setState({dropping: false});
    }

    render() {
        let classes = classNames(
            styles.dropTarget,
            {
                'dropping': this.state.dropping
            }
        );
        return <div className={classes} onDragOver={(e) => this.startDrop(e) } onDragLeave={(e) => this.stopDrop(e) } onDrop={(e) => this.handleDrop(e) }>
            <p>{this.props.text}</p>
        </div>
    }
}

DropTarget.propTypes = {
    allowedFileTypes: PropTypes.array.isRequired,
    onDropError: PropTypes.func.isRequired,
    onFileDropped: PropTypes.func.isRequired,
    maxFileCount: PropTypes.number.isRequired,
    maxFileSize: PropTypes.number.isRequired,
    text: PropTypes.string.isRequired
};

export default DropTarget;