import * as actions from '../actions/auth.actions';

const initialState = {
    loggedIn: false,
    loggedInUser: '',
    loginFailed: false,
    registrationFailed: false
};

const authReducer = (state = initialState, action) => {
    let mutatedState = Object.assign({}, state);
    switch(action.type) {
        case actions.ACTIONS.LOGIN_COMPLETE:
            mutatedState.loggedIn = true;
            mutatedState.loggedInUser = action.payload.username;
            mutatedState.loginFailed = false;
            return mutatedState;
        case actions.ACTIONS.LOGIN_FAILED:
            mutatedState.loggedIn = false;
            mutatedState.loginFailed = true;
            return mutatedState;
        case actions.ACTIONS.LOGOUT_COMPLETE:
            mutatedState.loggedIn = false;
            mutatedState.loggedInUser = '';
            mutatedState.loginFailed = false;
            return mutatedState;
        case actions.ACTIONS.REGISTER_COMPLETE:
            mutatedState.loggedIn = true;
            mutatedState.loggedInUser = action.payload.username;
            mutatedState.loginFailed = false;
            mutatedState.registrationFailed = false;
            return mutatedState;
        case actions.ACTIONS.REGISTER_FAILED:
            mutatedState.loggedIn = false;
            mutatedState.registrationFailed = true;
            return mutatedState;
        default:
            return state;
    }
};

export default authReducer;