import * as video from '../actions/video.actions';

const initialState = {
    videos: {}
};

const videoReducer = (state = initialState, action) => {
    let mutatedState = Object.assign({}, state);
    switch(action.type) {
        case video.ACTIONS.STORE_VIDEO:
            mutatedState[action.payload.key] = action.payload.security;
            return mutatedState;
        default:
            return state;
    }
};

export default videoReducer;
