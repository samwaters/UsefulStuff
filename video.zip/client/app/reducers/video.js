import * as video from '../actions/video.actions';

const initialState = {
    isLoading: false,
    videos: []
};

const videoReducer = (state = initialState, action) => {
    let mutatedState = Object.assign({}, state);
    switch(action.type) {
        case video.ACTIONS.LOAD_VIDEOS_START:
            mutatedState.isLoading = true;
            return mutatedState;
        case video.ACTIONS.STORE_VIDEOS:
            mutatedState.isLoading = false;
            mutatedState.videos = [...action.payload];
            return mutatedState;
        default:
            return state;
    }
};

export default videoReducer;
