import React from 'react';
import {IndexRedirect, IndexRoute, Route} from 'react-router';
import App from './app';
import EditComponent from './components/editor/edit';
import HomeComponent from './components/home/home';
import AuthComponent from './components/auth/auth';
import NotFoundComponent from './components/notfound';
import UploadComponent from './components/uploader/upload';
import WelcomeComponent from './components/home/welcome';
import * as s from './selectors/auth';

export const getRoutes = store => {
    const requireAuth = (nextState, replace) => {
        const state = store.getState();
        if(!s.selectIsLoggedIn(state)) {
            replace({
                pathname: '/login',
                state: {}
            });
        }
    };
    const requireNoAuth = (nextState, replace) => {
        const state = store.getState();
        if(s.selectIsLoggedIn(state)) {
            replace({
                pathname: '/home',
                state: {}
            });
        }
    };

    return <Route path="/" component={App}>
        <IndexRedirect to="/home" />
        <Route path="/home" components={{main: HomeComponent}} onEnter={(n, r) => requireAuth(n, r)}>
            <IndexRoute components={{page: WelcomeComponent}} />
            <Route path="/edit/:key" components={{page: EditComponent}} />
            <Route path="/upload" components={{page: UploadComponent}} />
        </Route>
        <Route path="/login" components={{main: AuthComponent}} onEnter={(n, r) => requireNoAuth(n, r)} />
        <Route path="*" components={{main: NotFoundComponent}} />
    </Route>
};