const server = require('../server');
const validator = require('validator');

server.post('/api/auth/login', function(req, res) {
    if(!req.body || !req.body.username || !req.body.password) {
        res.status(400);
        res.send(JSON.stringify({ok: false, error: 'Incomplete payload'}));
        res.end();
        return;
    }
    if(
        !validator.isEmail(req.body.username)
        || req.body.password.length < 8
    ) {
        res.status(400);
        res.send(JSON.stringify({ok: false, error: 'Invalid username or password'}));
        res.end();
        return;
    }
    server.db.verifyUser(req.body.username, req.body.password).then(
        user => {
			server.db.generateToken(user.id, req.connection.remoteAddress).then(
			  token => {
			      res.cookie('token', token);
				  res.send(JSON.stringify({ok: true, token:token, username: user.username}));
				  res.end();
			  },
			  err => {
			  	res.status(500);
			  	res.send(JSON.stringify({ok: false, error: err}));
			  	res.end();
			  }
			);
        },
        err => {
            res.status(401);
            res.send(JSON.stringify({ok: false, error: err}));
            res.end();
        }
    )
});

server.post('/api/auth/logout', function(req, res) {
    if(!req.body || !req.body.username || !req.header('token')) {
        res.status(400);
        res.send(JSON.stringify({ok: false, error: 'Incomplete payload'}));
        res.end();
        return;
    }
    server.db.getUserId(req.body.username).then(
        id => {
            server.db.removeToken(req.header('token'), id, req.connection.remoteAddress).then(
                ok => {
                    res.cookie('token', '');
                    res.send(JSON.stringify({ok: true}));
                    res.end();
                },
                err => {
                    res.status(400);
                    res.send(JSON.stringify({ok:false, error:'Not logged in'}));
                    res.end();
                }
            )
        },
        err => {
            res.status(400);
            res.send(JSON.stringify({ok:false, error:'Not logged in'}));
            res.end();
        }
    );
});

server.post('/api/auth/register', function(req, res) {
    if(!req.body || !req.body.username || !req.body.password) {
        res.status(400);
        res.send(JSON.stringify({ok: false, error: 'Incomplete payload'}));
        res.end();
        return;
    }
    if(
        !validator.isEmail(req.body.username)
        || req.body.password.length < 8
    ) {
        res.status(400);
        res.send(JSON.stringify({ok: false, error: 'Invalid payload'}));
        res.end();
        return;
    }
    server.db.userExists(req.body.username).then(
        user => {
            res.status(400);
            res.send(JSON.stringify({ok: false, error:'User already exists'}));
            res.end();
        },
        err => {
            console.log('Register creating user');
            server.db.createUser(req.body.username, req.body.password).then(
                id => {
                    console.log('Register created user', id);
                    server.db.generateToken(id, req.connection.remoteAddress).then(
                        token => {
                            res.cookie('token', token);
                            res.send(JSON.stringify({ok: true, token:token, username: req.body.username}));
                            res.end();
                        },
                        err => {
                            res.status(500);
                            res.send(JSON.stringify({ok: false, error: err}));
                            res.end();
                        }
                    );
                },
                err => {
                    res.status(400);
                    res.send(JSON.stringify({ok: false, error: err}));
                    res.end();
                }
            )
        }
    );
});
