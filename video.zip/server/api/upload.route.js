const crypt = require('crypto');
const fs = require('fs');
const path = require('path');
const server = require('../server');

server.use('/api/upload', function(req, res) {
    const key = crypt.randomBytes(20).toString('hex');
    const security = crypt.randomBytes(20).toString('hex');
    fs.writeFile(path.join(__dirname, '..', 'upload', key), req.body, "binary", function(e) {
        if(e) {
            res.send(JSON.stringify({
                message: e,
                status: 'error'
            }))
        } else {
            server.db.queueVideo(key, security);
            res.cookie('security-key', security);
            res.send(JSON.stringify({
                size: req.body.length,
                status: 'ok',
                viewKey: key
            }));
        }
        res.end();
    });

});