const fs = require('fs');
const path = require('path');
const server = require('../server');

server.use('/api/upload', function(req, res) {
    if(!req.header('token') || !req.header('username')) {
        res.status(403);
        res.send(JSON.stringify({ok:false, error:'Not Authorised'}));
        return;
    }
    server.db.verifyToken(req.header('token'), req.header('username'), req.connection.remoteAddress).then(
        data => {
            server.db.createVideo(data.userId, '').then(
                video => {
                    fs.writeFile(path.join(__dirname, '..', 'upload', video.key), req.body, "binary", function(e) {
                        if(e) {
                            res.send(JSON.stringify({
                                message: e,
                                status: 'error'
                            }));
                            res.end();
                        } else {
                            server.db.queueVideo(video.id);
                            res.send(JSON.stringify({
                                size: req.body.length,
                                status: 'ok',
                                securityKey: video.security,
                                viewKey: video.key
                            }));
                            res.end();
                        }
                    });
                },
                err => {
                    res.status(500);
                    res.send(JSON.stringify({ok:false, error:err}));
                    res.end();
                }
            );
        },
        err => {
            res.status(401);
            res.send(JSON.stringify({ok:false, error:'Not Authorised'}));
            res.end();
        }
    )

});