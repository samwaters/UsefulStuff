const b64 = require('base-64');
const fs = require('fs');
const path = require('path');
const send = require('send');
const server = require('../server');
const config = require('../server.config');

/*
    TODO: IMPORTANT!!!!
    Currently there is no video or thumbnail ownership verification
    This needs to be checked based on the validated token before sending the video or thumbnail
 */

server.get('/api/video/list', (req, res) => {
	if(!req.header('token') || !req.header('username')) {
		res.status(403);
		res.send(JSON.stringify({ok:false, error:'Not Authorised'}));
		return;
	}
	server.db.verifyToken(req.header('token'), req.header('username'), req.connection.remoteAddress).then(
	    data => {
            server.db.listVideos(req.header('username')).then(
                videos => {
                    res.send(JSON.stringify({ok: true, videos: videos}));
                    res.end();
                },
                err => {
                    res.status(404);
                    res.send(JSON.stringify({error: 'Could not load videos', ok: false, e:err}));
                    res.end();
                }
            );
	  });
});

server.get('/api/video/:key/status', (req, res) => {
    if(!req.query.token) {
        res.status(403);
        res.send(JSON.stringify({ok:false, error:'Not Authorised'}));
        res.end();
        return;
    }
    let decodedToken;
    try {
        decodedToken = JSON.parse(b64.decode(req.query.token));
    } catch(e) {
        res.status(401);
        res.send(JSON.stringify({ok:false, error:'Not Authorised'}));
        res.end();
        return;
    }
    server.db.verifyToken(decodedToken.token, decodedToken.username, req.connection.remoteAddress).then(
        data => {
            server.db.videoStatus(req.params.key, decodedToken.username).then(
                status => {
                    res.send(JSON.stringify({
                        ok: true,
                        status: status,
                    }));
                    res.end();
                },
                error => {
                    res.send(JSON.stringify({
                        error: error,
                        ok: false
                    }));
                    res.end();
                }
            );
        },
        err => {
            res.status(401);
            res.send(JSON.stringify({ok:false, error:'Not Authorised'}));
            res.end();
        }
    );
});

server.get('/api/video/:key/thumbnail', (req, res) => {
	if (!req.query.token) {
		res.status(403);
		res.send(JSON.stringify({ok: false, error: 'Not Authorised'}));
		res.end();
		return;
	}
	let decodedToken;
	try {
		decodedToken = JSON.parse(b64.decode(req.query.token));
	} catch (e) {
		res.status(401);
		res.send(JSON.stringify({ok: false, error: 'Not Authorised'}));
		res.end();
		return;
	}
	server.db.verifyToken(decodedToken.token, decodedToken.username, req.connection.remoteAddress).then(
	  data => {
		  let thumbPath = path.join(config.thumbnails, req.params.key);
		  if(fs.existsSync(thumbPath)) {
		      res.header('Content-type', 'image/png');
		      res.send(fs.readFileSync(thumbPath));
          } else {
		      res.status(404);
			  res.send(JSON.stringify({error: 'Thumbnail could not be found', ok: false}));
          }
          res.end();
	  }
	)
});

server.get('/api/video/:key/watch', (req, res) => {
    if(!req.query.token) {
        res.status(403);
        res.send(JSON.stringify({ok:false, error:'Not Authorised'}));
        res.end();
        return;
    }
    let decodedToken;
    try {
        decodedToken = JSON.parse(b64.decode(req.query.token));
    } catch(e) {
        res.status(401);
        res.send(JSON.stringify({ok:false, error:'Not Authorised'}));
        res.end();
        return;
    }
    server.db.verifyToken(decodedToken.token, decodedToken.username, req.connection.remoteAddress).then(
        data => {
            server.db.videoStatus(req.params.key, decodedToken.username).then(
                status => {
                    if(status === 2) {
                        let videoPath = path.join(config.processed, req.params.key);
                        if(fs.existsSync(videoPath)) {
                            res.header('Content-type', 'video/mp4');
                            if(req.header('Range')) {
                                sendVideoRange(videoPath, parseRangeHeader(req.header('Range')), res);
                            } else {
                                res.send(fs.readFileSync(videoPath));
                            }
                        } else {
                            res.status(404);
                            res.send(JSON.stringify({error: 'Video could not be found', ok: false}));
                        }
                    } else {
                        res.status(400);
                        res.send(JSON.stringify({error: 'Video is not processed', ok: false}));
                    }
                    res.end();
                },
                error => {
                    res.send(JSON.stringify({error: error, ok: false}));
                    res.end();
                }
            );
        },
        err => {
            res.status(401);
            res.send(JSON.stringify({ok:false, error:'Not Authorised'}));
            res.end();
        }
    );
});

function parseRangeHeader(header) {
    let headerData = header.split('=');
    if(headerData[0] === 'bytes') {
        if(!headerData[1]) {
            return null;
        }
        let byteRange = headerData[1].split('-');
        return {
            start: parseInt(byteRange[0]),
            end: byteRange[1] ? parseInt(byteRange[1]) : Infinity
        }
    } else {
        return null; // No idea what to do with this one
    }
}

function sendVideoRange(videoPath, range, res) {
    if(!range) {
        res.status(406);
    } else {
        try {
            // Check the length
            let completeVideo = fs.readFileSync(videoPath);
            if(range.start > completeVideo.length || (range.end < Infinity && range.end > completeVideo.length)) {
                res.status(406); // Unsatisfiable range
                return;
            }
            res.status(206); // Partial content
            res.header('Accept-Ranges', 'bytes');
            if(range.end === Infinity) {
                res.header('Content-Length', completeVideo.length - range.start);
                res.header('Content-Range', 'bytes ' + range.start + '-' + (completeVideo.length-1) + '/' + completeVideo.length);
                let buf = new Buffer(completeVideo.length - range.start);
                completeVideo.copy(buf, 0, range.start, completeVideo.length);
                res.send(buf);
            } else {
                res.header('Content-Length', range.end - range.start);
                res.header('Content-Range', 'bytes ' + range.start + '-' + range.end + '/' + completeVideo.length);
                let buf = new Buffer(range.end - range.start + 1);
                completeVideo.copy(buf, 0, range.start, range.end + 1);
                res.send(buf);
            }
        } catch(e) {
            console.log('File read error', e);
            res.status(406);
        }
    }
}
