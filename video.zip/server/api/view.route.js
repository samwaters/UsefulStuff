const fs = require('fs');
const path = require('path');
const send = require('send');
const server = require('../server');

server.get('/api/view/:key/status', function(req, res) {
    server.db.videoStatus(req.params.key, req.cookies['security-key']).then(
        status => {
            res.send(JSON.stringify({
                ok: true,
                status: status,
            }));
            res.end();
        },
        error => {
            res.send(JSON.stringify({
                error: error,
                ok: false
            }));
            res.end();
        }
    );
});

server.get('/api/view/:key/watch', function(req, res) {
    server.db.videoStatus(req.params.key, req.cookies['security-key']).then(
        status => {
            if(status === 2) {
                let videoPath = path.join(__dirname, '..', 'upload', 'processed', req.params.key);
                if(fs.existsSync(videoPath)) {
                    res.header('Content-type', 'video/mp4');
                    if(req.header('Range')) {
                        sendVideoRange(videoPath, parseRangeHeader(req.header('Range')), res);
                    } else {
                        res.send(fs.readFileSync(videoPath));
                    }
                } else {
                    res.status(404);
                    res.send(JSON.stringify({error: 'Video could not be found', ok: false}));
                }
            } else {
                res.status(400);
                res.send(JSON.stringify({error: 'Video is not processed', ok: false}));

            }
            res.end();
        },
        error => {
            res.send(JSON.stringify({error: error, ok: false}));
            res.end();
        }
    );
});

function parseRangeHeader(header) {
    let headerData = header.split('=');
    if(headerData[0] === 'bytes') {
        if(!headerData[1]) {
            return null;
        }
        let byteRange = headerData[1].split('-');
        return {
            start: parseInt(byteRange[0]),
            end: byteRange[1] ? parseInt(byteRange[1]) : Infinity
        }
    } else {
        return null; // No idea what to do with this one
    }
}

function sendVideoRange(videoPath, range, res) {
    if(!range) {
        res.status(406);
    } else {
        try {
            // Check the length
            let completeVideo = fs.readFileSync(videoPath);
            if(range.start > completeVideo.length || (range.end < Infinity && range.end > completeVideo.length)) {
                res.status(406); // Unsatisfiable range
                return;
            }
            res.status(206); // Partial content
            res.header('Accept-Ranges', 'bytes');
            if(range.end === Infinity) {
                res.header('Content-Length', completeVideo.length - range.start);
                res.header('Content-Range', 'bytes ' + range.start + '-' + (completeVideo.length-1) + '/' + completeVideo.length);
                let buf = new Buffer(completeVideo.length - range.start);
                completeVideo.copy(buf, 0, range.start, completeVideo.length);
                res.send(buf);
            } else {
                res.header('Content-Length', range.end - range.start);
                res.header('Content-Range', 'bytes ' + range.start + '-' + range.end + '/' + completeVideo.length);
                let buf = new Buffer(range.end - range.start + 1);
                completeVideo.copy(buf, 0, range.start, range.end + 1);
                res.send(buf);
            }
        } catch(e) {
            console.log('File read error', e);
            res.status(406);
        }
    }
}
