const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const sql = require('sqlite3');
const dbPath = path.join(__dirname, 'db.sql');
const salt = 'agVideo';

class Db {
	constructor() {
		let _this = this;
		this._db = new sql.Database(dbPath);
		this._db.get('SELECT name FROM sqlite_master WHERE type="table" AND name="queue"', (err, row) => {
			if (!row) {
				_this.initialiseDb();
			}
		});
	}

	initialiseDb() {
		console.log('Initialising DB');
		this._db.run('CREATE TABLE tokens(token string(32) primary key, userId references users(id) not null, ip string(45) not null, expiry timestamp not null)');
		this._db.run('CREATE TABLE queue(videoId integer references videos(id), added timestamp default CURRENT_TIMESTAMP, status integer, lockedBy string(32))');
		this._db.run('CREATE TABLE users(id integer primary key, username string(32) unique not null, password string(255) not null, added timestamp default CURRENT_TIMESTAMP)');
		this._db.run('CREATE TABLE videos(id integer primary key, owner integer references users(id), key string(32) unique not null, security string(32) not null, added timestamp default CURRENT_TIMESTAMP, description text, processing boolean default false)');
	}

	createUser(username, password) {
		const hmac = crypto.createHmac('sha512', salt);
		hmac.update(password);
		return new Promise((resolve, reject) => {
			try {
				this._db.run('INSERT INTO users VALUES(null, ?, ?, ?)', username, hmac.digest('hex'), new Date().getTime(), err => {
					if (err) {
						reject(err);
					} else {
						resolve(this.lastID);
					}
				});
			} catch (err) {
				reject(err);
			}
		});
	}

	createVideo(userId, key, security, description) {
		let _this = this;
		return new Promise((resolve, reject) => {
			_this._db.run('INSERT INTO videos VALUES(?, ?, ?, ?, ?, ?, ?)', null, userId, key, security, new Date().getTime(), description, true, err => {
				if (err) {
					reject('Could not create video')
				} else {
					resolve(this.lastID);
				}
			});
		});
	}

	generateToken(userId, ip) {
		let token = crypto.randomBytes(32).toString('hex');
		let expiry = new Date().getTime() + 900000; //15m
		let _this = this;
		return new Promise((resolve, reject) => {
			_this._db.run('INSERT INTO tokens VALUES(?, ?, ?, ?)', token, userId, ip, expiry, err => {
				if (err) {
					reject(err);
				} else {
					resolve(token);
				}
			});
		});

	}

	queueVideo(id) {
		this._db.run('INSERT INTO queue VALUES(?, ?, 0, null)', id, new Date().getTime());
	}

	renewToken(token, userId, ip) {
		let _this = this;
		return new Promise((resolve, reject) => {
			this.verifyToken(token, userId, ip).then(
				token => {
					let newExpiry = new Date().getTime() + 900000;
				  	_this._db.run('UPDATE token SET expiry=? WHERE token=?', newExpiry, token, err => {
						if(err) {
							reject('Cannot update token');
						} else {
							resolve(newExpiry);
						}
				 	});
				},
				err => {
					reject('Token not found');
				}
			);
		});
	}

	userExists(username) {
		let _this = this;
		return new Promise((resolve, reject) => {
			_this._db.get('SELECT username FROM users WHERE username=?', username, (err, row) => {
				if (err || typeof row === 'undefined') {
					reject('User not found');
				} else {
					resolve(row.username);
				}
			});
		});
	}

	verifyUser(username, password) {
		let _this = this;
		return new Promise((resolve, reject) => {
			_this._db.get('SELECT id, username FROM users WHERE username=? AND password=?', username, password, (err, row) => {
				if (err || typeof row === 'undefined') {
					reject('User not found');
				} else {
					resolve({id: row.id, username: row.username});
				}
			});
		});
	}

	verifyToken(token, userId, ip) {
		let _this = this;
		return new Promise((resolve, reject) => {
			_this._db.get('SELECT token FROM tokens WHERE token=? AND userId=? AND ip=?', token, userId, ip, (err, row) => {
				if (err || typeof row === 'undefined') {
					reject('Token not found');
				} else {
					resolve(token);
				}
			});
		});
	}

	videoStatus(key, security) {
		let _this = this;
		return new Promise((resolve, reject) => {
			_this._db.get('SELECT security, status FROM queue WHERE key=?', key, (err, row) => {
				if (err || typeof row === 'undefined') {
					reject('Video not found');
				} else {
					if (row.security === security) {
						resolve(row.status);
					} else {
						reject('Not authorized');
					}
				}
			});
		});
	}
}

module.exports = Db;
