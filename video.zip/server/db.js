const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const sql = require('sqlite3');
const dbPath = path.join(__dirname, 'db.sql');
const salt = 'agVideo';

class Db {
    constructor() {
        let _this = this;
        this._db = new sql.Database(dbPath);
        this._db.get('SELECT name FROM sqlite_master WHERE type="table" AND name="queue"', (err, row) => {
            if(!row) {
                _this.initialiseDb();
            }
        });
    }

    initialiseDb() {
        console.log('Initialising DB');
        this._db.run('CREATE TABLE tokens(token string(32) primary key, userId references users(id) not null, ip string(45) not null, expiry timestamp not null)');
        this._db.run('CREATE TABLE queue(videoId integer references videos(id), added timestamp default CURRENT_TIMESTAMP, status integer, lockedBy string(32))');
        this._db.run('CREATE TABLE users(id integer primary key, username string(32) unique not null, password string(255) not null, added timestamp default CURRENT_TIMESTAMP)');
        this._db.run('CREATE TABLE videos(id integer primary key, owner integer references users(id), key string(32) unique not null, added timestamp default CURRENT_TIMESTAMP, name string(50), description text, processing boolean default false)');
    }

    createUser(username, password) {
        const hmac = crypto.createHmac('sha512', salt);
        hmac.update(password);
        let _this = this;
        return new Promise((resolve, reject) => {
            try {
                _this._db.run('INSERT INTO users VALUES(null, ?, ?, ?)', username, hmac.digest('hex'), new Date().getTime(), function(err) {
                    if(err) {
                        reject(err);
                    } else {
                        console.log('Created user', this);
                        resolve(this.lastID);
                    }
                });
            } catch(err) {
                reject(err);
            }
        });
    }

    createVideo(userId, name, description) {
        let _this = this;
        const key = crypto.randomBytes(20).toString('hex');
        return new Promise((resolve, reject) => {
            _this._db.run('INSERT INTO videos VALUES(?, ?, ?, ?, ?, ?, ?)', null, userId, key, new Date().getTime(), name, description, true, function(err) {
                if(err) {
                    reject('Could not create video')
                } else {
                    resolve({id:this.lastID, key:key});
                }
            });
        });
    }

    generateToken(userId, ip) {
        let token = crypto.randomBytes(32).toString('hex');
        let expiry = new Date().getTime() + 900000; //15m
        let _this = this;
        return new Promise((resolve, reject) => {
            _this._db.run('INSERT INTO tokens VALUES(?, ?, ?, ?)', token, userId, ip, expiry, err => {
                if(err) {
                    reject(err);
                } else {
                    resolve(token);
                }
            });
        });
    }

    getUserId(userName) {
        let _this = this;
        return new Promise((resolve, reject) => {
            _this._db.get('SELECT id FROM users WHERE username=?', userName, (err, row) => {
                if(err || typeof row === 'undefined') {
                    reject('User not found');
                } else {
                    resolve(row.id);
                }
            });
        });
    }

    listVideos(userName) {
        let _this = this;
        return new Promise((resolve, reject) => {
            _this.getUserId(userName).then(
              id => {
                  _this._db.all('SELECT key, videos.added as added, name, description, processing, queue.status as status FROM videos INNER JOIN queue ON videos.id=queue.videoId WHERE owner=?', id, (err, rows) => {
                      if(err || rows.length === 0) {
                          console.log(err, rows);
                          reject('Could not load videos');
                      } else {
                          console.log(rows);
                          resolve(rows);
                      }
                  });
              },
              err => {
                  reject(err);
              }
            )
		});
    }

    queueVideo(id) {
        this._db.run('INSERT INTO queue VALUES(?, ?, 0, null)', id, new Date().getTime());
    }

    removeToken(token) {
        let _this = this;
        return new Promise((resolve, reject) => {
            _this._db.run('DELETE FROM tokens WHERE token=?', token, err => {
                if(err) {
                    reject('Cannot remove token');
                } else {
                    resolve(true);
                }
            });
        });
    };

    renewToken(token) {
        let _this = this;
        return new Promise((resolve, reject) => {
            let newExpiry = new Date().getTime() + 900000;
            _this._db.run('UPDATE token SET expiry=? WHERE token=?', newExpiry, token, err => {
                if(err) {
                    reject('Cannot update token');
                } else {
                    resolve(newExpiry);
                }
            });
        });
    }

    userExists(username) {
        let _this = this;
        return new Promise((resolve, reject) => {
            _this._db.get('SELECT username FROM users WHERE username=?', username, (err, row) => {
                if(err || typeof row === 'undefined') {
                    reject('User not found');
                } else {
                    resolve(row.username);
                }
            });
        });
    }

    verifyToken(token, userName, ip) {
        let _this = this;
        return new Promise((resolve, reject) => {
            _this.getUserId(userName).then(
                userId => {
                    _this._db.get('SELECT token FROM tokens WHERE token=? AND userId=? AND ip=?', token, userId, ip, (err, row) => {
                        if(err || typeof row === 'undefined') {
                            reject('Token not found');
                        } else {
                            resolve({userId: userId, token: token});
                        }
                    });
                },
                err => {
                    reject('Cannot find user');
                }
            );
        });
    }

    verifyUser(username, password) {
        let _this = this;
        const hmac = crypto.createHmac('sha512', salt);
        hmac.update(password);
        return new Promise((resolve, reject) => {
            _this._db.get('SELECT id, username FROM users WHERE username=? AND password=?', username, hmac.digest('hex'), (err, row) => {
                if(err || typeof row === 'undefined') {
                    reject('User not found');
                } else {
                    resolve({id: row.id, username: row.username});
                }
            });
        });
    }

    videoStatus(key, userName) {
        let _this = this;
        return new Promise((resolve, reject) => {
            _this.getUserId(userName).then(
                id => {
                    _this._db.get('SELECT processing, queue.status as status FROM videos inner join queue on videos.id = queue.videoId WHERE owner=? AND key=?', id, key, (err, row) => {
                        if(err || typeof row === 'undefined') {
                            reject('Video not found');
                        } else {
                            resolve({processing:row.processing, status:row.status});
                        }
                    });
                },
                err => {
                    reject('User not found');
                }
            );
        });
    }
}

module.exports = Db;
