const child = require('child_process');
const path = require('path');
const sql = require('sqlite-sync');

let nameArg = process.argv.indexOf('--name');
let ffmpeg = path.join('c:', 'ffmpeg', 'bin', 'ffmpeg.exe');
let processName;
if(nameArg >= 0 && process.argv.length > nameArg) {
    processName = process.argv[nameArg + 1];
} else {
    processName = "proc-" + new Date().getTime();
}
console.log('---Transcode Processor---');
console.log('Process name:', processName);
sql.connect(path.join(__dirname, '..', 'db.sql'));
while(true) {
    console.log('Trying to find a job locked by this process');
    let lockedJob = sql.run('SELECT videoId, videos.key as key FROM queue inner join videos on videoId = videos.id WHERE status=0 AND lockedBy=? LIMIT 1', processName);
    if(lockedJob.length > 0) {
        // Do the job
        console.log('Processing', lockedJob[0].videoId, lockedJob[0].key);
        child.spawnSync(ffmpeg, [
            '-i ' + path.join(__dirname, lockedJob[0].key),
            '-vcodec h264',
            '-acodec aac',
            '-strict',
            '-2',
            path.join(__dirname, 'processed', lockedJob[0].key)
        ]);
    } else {
        console.log('Trying to find a new job to process');
        let newJob = sql.run('SELECT videoId FROM queue WHERE status=0 AND lockedBy is null LIMIT 1');
        if(newJob.length == 1) {
            console.log(newJob);
            console.log('Found and locking video', newJob[0].videoId);
            sql.run('UPDATE queue SET lockedBy=? WHERE videoId=? AND lockedBy is null', processName, newJob[0].videoId);
        } else {
            console.log('Nothing to do, sleeping');
            let until = new Date().getTime() + 5000;
            while(until > new Date().getTime()) {} // Sorry :(
        }
    }
}