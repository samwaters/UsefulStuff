const webpack = require('webpack');
const path = require('path');
const ExtractTextPlugin = require('extract-text-webpack-plugin');

const BUILD_DIR = path.resolve(__dirname, 'dist');
const APP_DIR = path.resolve(__dirname, 'client/app');

// Util functions
function env() {
    return process.argv.indexOf('--prod') >= 0 ? 'prod' : 'dev';
}

// Loaders
let loaders = env() === 'prod'
    ? [{
        test: /\.(css|scss)$/,
        loader: ExtractTextPlugin.extract('style', 'css?sourceMap&modules&importLoaders=1&localIdentName=[name]__[local]___[hash:base64:5]!sass')
    }]
    : [{
        test: /\.(css|scss)$/,
        loader: 'style!css?sourceMap&modules&importLoaders=1&localIdentName=[name]__[local]___[hash:base64:5]!sass?sourceMap'
    }];
loaders.push({
    test: /\.jsx?/,
    exclude: /(node_modules)/,
    include: APP_DIR,
    loader: 'babel'
});

const config = {
    entry: APP_DIR + '/index.jsx',
    output: {
        path: BUILD_DIR,
        filename: env() === 'prod' ? 'bundle.prod.js' : 'bundle.dev.js'
    },
    resolve: {
        extensions: ['', '.scss', '.css', '.js', '.jsx', '.json'],
        modulesDirectories: [
            'node_modules',
            path.resolve(__dirname, './node_modules')
        ]
    },
    module: {
        preLoaders: [
            {
                test: /\.jsx?/,
                exclude: /(node_modules)/,
                loader: 'eslint'
            }
        ],
        loaders: loaders
    },
    eslint: {
        failOnWarning: false,
        failOnError: true
    },
    plugins: env() === 'prod'
        ? [
            new webpack.optimize.OccurrenceOrderPlugin(true),
            new webpack.optimize.DedupePlugin(),
            new webpack.optimize.UglifyJsPlugin({
                compress: { warnings: false, unused: true, dead_code: true },
                output: { comments: false }
            }),
            new webpack.DefinePlugin({"process.env": {NODE_ENV: JSON.stringify('production')}}),
            new ExtractTextPlugin('bundle.prod.css', {allChunks: true})
        ]
        : [
            new webpack.DefinePlugin({"process.env": {NODE_ENV: JSON.stringify('development')}})
        ],
    sassLoader: {
        data: '@import "client/theme/_theme.scss";',
        includePaths: [path.resolve(__dirname, './src/client/app')]
    }
};

module.exports = config;